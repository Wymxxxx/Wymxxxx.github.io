package kolokwium;

public class Kolokwium {
    
public static void main(String[] args) {
        Tablet pierwszy = new Tablet("LG", "AMD", 12.3);
        Tablet drugi = new Tablet("SAMSUNG", "Intel");
        Tablet trzeci = new Tablet("Google", "IBM");
        trzeci.wlaczGPS();
        System.out.println(pierwszy.toString());
        pierwszy.obroc();
        drugi.setJasnoscEkranu(100);
    }
}

interface Wlaczalny {
    public boolean wlacz(String start);
    public boolean wylacz(String koniec);
}

interface GPS {
    public boolean wlaczGPS();
    public boolean wylaczGPS();
    public double pobierzWspolrzedne();
}
          
class Komputer {
    private String procesor;
    
    public Komputer(String procesor) { 
    } 

    public void setUstawProcesor(String procesor) {
        this.procesor = procesor;
    }

    public String getPobierzProcesor() {
        return procesor;
    }

    @Override
    public String toString() {
        return "Komputer{" + "procesor=" + procesor + '}';
    }
} 
        
class Tablet extends Komputer implements Wlaczalny,GPS {
    
    private String nazwa;
    private double waga;
    private int jasnoscEkranu;
    private static int liczbaTabletow;

    public Tablet(String nazwa, String procesor, double waga) {
        super(procesor);
        this.nazwa = nazwa;
        this.waga = waga;
    }

    public Tablet(String nazwa, String procesor) {
        super(procesor);
        this.nazwa = nazwa;
    }

    
    private boolean resetuj() {
        System.out.println("Resetuje urzadzenie... ");
        return true;
    }
    
    public boolean setJasnoscEkranu(int jasnoscEkranu) {
        this.jasnoscEkranu = jasnoscEkranu;
        return true;
    }
    
    public boolean obroc() {
        System.out.println("Obracam urzadzenie... ");
        return false;
    }
    
    public int pobierzLiczbeTabletow() {
        return 100;
    }
    
    @Override
    public String toString() {
        return "Tablet{" + "nazwa=" + nazwa + '}';
    }
    
    @Override
    public boolean wlaczGPS() {
        System.out.println("wlaczGPS");
        return true;
    }
    
    @Override
    public boolean wylaczGPS() {
        System.out.println("wylaczGPS");
        return false;
    }
    
    @Override
    public double pobierzWspolrzedne() {
        return 2.5;
    }
    
    @Override
    public boolean wlacz(String start) {
        return true;
    }
    
    @Override
    public boolean wylacz(String koniec) {
        return false;
    }

}