package kolokwium;

public class Kolokwium {


    public static void main(String[] args) {
        EkranLCD pierwszy = new EkranLCD("LG");
        EkranLCD drugi = new EkranLCD("SAMSUNG", "TFT");
        EkranLCD trzeci = new EkranLCD("benq");
        System.out.println(pierwszy.toString());
        drugi.setNazwa("Asus");
        trzeci.setModel("ERROR");
    }
}

interface Wyswietlaj {
    public boolean wyswietl(String cokolwiek);
    public boolean wyswietl(String x, String y);
}

class EkranLCD implements Wyswietlaj  {
    
    private String nazwa;
    private String model;
    public static int iloscEkranow;

    /*************** public EkranLCD getEkran(){
        return pomidor;
    }
    **************88*/
    
    public EkranLCD(String nazwa) {
        this.nazwa = nazwa;
        iloscEkranow++;
    }

    public EkranLCD(String nazwa, String model) {
        this.nazwa = nazwa;
        this.model = model;
        iloscEkranow++;
    }

    public String getNazwa() {
        return nazwa;
    }

    public boolean setNazwa(String nazwa) {
        this.nazwa = nazwa;
        return true;
    }

    public boolean setModel(String model) {
        this.model = model;
        return true;
    }
    
    private boolean wykonajKalibracje() {
        System.out.println("Wykonuje kalibracje... ");
        return true;
    }
    
    public static int getLiczbeEkranowLCD() {
        return iloscEkranow;
}

    @Override
    public boolean wyswietl(String cokolwiek){
        return true;
    }
    
    @Override
    public boolean wyswietl(String x, String y){
        return false;
    }
    
    @Override
    public String toString() {
        return "EkranLCD{" + "nazwa=" + nazwa + ", model=" + model + '}';
    }
    

    
}
