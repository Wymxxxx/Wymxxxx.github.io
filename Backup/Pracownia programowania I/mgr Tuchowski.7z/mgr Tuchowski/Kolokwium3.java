
package kolokwium;


public class Kolokwium {


public static void main(String[] args) {
        Smok pierwszy = new Smok("Zielony Smok", 500, 150, 100);
        Smok drugi = new Smok("Zloty Smok", 300, 200, 50);
        Smok trzeci = new Smok("Czarny Smok", 400, 300, 200);
        System.out.println(pierwszy.toString());
        System.out.println(drugi.toString());
        System.out.println(trzeci.toString());
        pierwszy.ustawPozycje(300, 400);
        drugi.patroluj();
        trzeci.strzelDo();
        pierwszy.idzDo();
    }
}

interface Chodzi {
    public boolean idzDo();
}

interface Strzela {
    public boolean strzelDo();
}

interface Patroluje {
    public boolean lecDo();
    public boolean patroluj();
}

class Gad {
    private String rodzina;
    
    public Gad(String rodzina) {   
    }

    public String pobierzRodzine() {
        return rodzina;
    }

    public void ustawRodzine(String rodzina) {
        this.rodzina = rodzina;
    }

    @Override
    public String toString() {
        return "Gad {" + "rodzina=" + rodzina + '}';
    }
}


class Smok extends Gad implements Chodzi,Strzela,Patroluje {
    
    private int polozenieX;
    private int polozenieY;
    private double zdrowie;

    public Smok(String rodzina, int polozenieX, int polozenieY, double zdrowie) {
        super(rodzina);
        this.polozenieX = polozenieX;
        this.polozenieY = polozenieY;
        this.zdrowie = zdrowie;
    }
    
    public Smok(String rodzina, double zdrowie) {
        super(rodzina);
        this.zdrowie = zdrowie;
    }
    
    public int podajPozycje(){
        return 666;
    }
    
    public boolean ustawPozycje(int polozenieY, int polozenieX){
        return true;
    }
    
    
    private boolean regeneruj() {
    System.out.println("Regeneruj smoka... ");
    return true;
    }
    
  @Override
    public boolean idzDo() {
        System.out.println("Smok idzie do jamy...");
        return true;
    }
  
  @Override
    public boolean strzelDo() {
        System.out.println("Smok zastrzelony...");
        return true;
    }
    
  @Override
    public boolean lecDo() {
        System.out.println("Smok leci...");
        return true;
    }
  
    @Override
    public boolean patroluj() {
        System.out.println("Smok obczaja teren...");
        return true;
    }

    @Override
    public String toString() {
        return "Smok{" + "polozenieX=" + polozenieX + ", polozenieY=" + polozenieY + ", zdrowie=" + zdrowie + '}';
    }
    
    
}