import java.util.Scanner;

public class BMI 
{
    public static void main(String[] args) 
    {
        Scanner podane = new Scanner(System.in);
        System.out.println("Podaj sw�j wzrost w metrach: ");
        Double wzrost = podane.nextDouble();
        System.out.println("Podaj swoj� wage w kilogramach: ");
        Double waga = podane.nextDouble();
        
        Double bmi = waga/(wzrost*wzrost);
        System.out.println("Tw�j wska�nik BMI wynosi: " + bmi);
    }
}
