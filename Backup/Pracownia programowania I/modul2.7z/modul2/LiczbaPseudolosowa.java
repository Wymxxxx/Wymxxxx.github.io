/*
 * Nazwa: LiczbaPseudolosowa
 * 
 * Uruchomienie: 
 *
 * cmd.exe:
 * Przejd� do katalogu zawieraj�cego kod programu
 * U�yj komendy javac LiczbaPseudolosowa.java w celu skompilowania
 * Uruchom program poleceniem java LiczbaPseudolosowa
 *
 * IDE:
 * U�yj opcji 'Build File', a nast�pnie opcji 'Run File'
 */
public class LiczbaPseudolosowa {
	
    public static void main(String[] args) {
    	/*
    	 * Wy�wietlenie liczby pseudolosowej z zakresu od 0.0 do 1.0 korzystaj�c z klasy java.lang.Math
    	 */
    System.out.println("Wylosowana liczba: " + Math.random());     
    }
}
