public class TypyZmiennych {
	public static void main(String[] args) {
		Long l = 493L;
		String f = "false";
		double d = 3.7;
		float ff = 0x3F;
		String b = "'B'";
		int i = 0xF7FF;
		int ii = 07246;
		float c = 1.2e5f;
		char u = '\u0042';
		int m = -178609;
		System.out.println(l + " " + f + " " + d + " " + ff + " " + b + " " + i + " " + ii + " " + c + " " + u + " " + m);
         }
}
