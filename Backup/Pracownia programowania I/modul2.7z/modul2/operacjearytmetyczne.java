/*
 *Przyk�adowe wywo�anie programu
 *java OperacjeArytmetyczne 5 38
 */
public class OperacjeArytmetyczne 
{
    public static void main(String[] args) 
    {
        //odczyt oraz konwersja liczb do postaci numerycznej
        int liczbaA = Integer.parseInt(args[0]);
        int liczbaB = Integer.parseInt(args[1]);
        
        System.out.println("A = " + liczbaA);
        System.out.println("B = " + liczbaB);
        System.out.println("A + B = " + (liczbaA+liczbaB));
        System.out.println("A - B = " + (liczbaA-liczbaB));
        System.out.println("A * B = " + (liczbaA*liczbaB));
        System.out.println("A / B = " + (liczbaA/liczbaB));
        System.out.println("A % B = " + (liczbaA%liczbaB));
    }
}
