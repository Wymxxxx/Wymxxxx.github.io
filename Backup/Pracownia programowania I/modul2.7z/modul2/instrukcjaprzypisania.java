public class InstrukcjaPrzypisania {
   public static void main(String[] args) {
       nazwaPlanety = "Ziemia";
       powierzchniaPlanety = 510065284;  // km2
       obwodPlanety = 40041;  // km
    }
}
