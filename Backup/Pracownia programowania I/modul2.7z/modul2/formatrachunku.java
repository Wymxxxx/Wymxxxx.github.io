import java.util.Scanner;
public class FormatRachunku 
{
   public static void main(String[] args) 
   	{
    	Scanner rachunek = new Scanner(System.in);
    	System.out.println("Podaj numer rachunku: ");
    	String numerRachunku = rachunek.nextLine();
    	String czesc1 = numerRachunku.substring(0, 2);
    	String czesc2 = numerRachunku.substring(2, 6);
    	String czesc3 = numerRachunku.substring(6, 10);
    	String czesc4 = numerRachunku.substring(10, 14);
    	String czesc5 = numerRachunku.substring(14, 18);
    	String czesc6 = numerRachunku.substring(18, 22);
    	String czesc7 = numerRachunku.substring(22, 26);
    	System.out.println(czesc1 + " " + czesc2 + " " + czesc3 + " " + czesc4 + " " + czesc5 + " " + czesc6 + " " + czesc7);
    }
}
