import java.util.Scanner;
public class KonwerterTemperatur 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzone = new Scanner(System.in);
        System.out.println("Podaj temperature w stopniach Celsjusza: ");
        double tempCelsjusz = wprowadzone.nextDouble();
        double tempKelvin = tempCelsjusz + 273;
        double tempFahrenheit = (tempCelsjusz*1.8)+32;
        System.out.println(tempCelsjusz + " stopni Celsjusza to " + tempKelvin + " stopni Kelvina i " + tempFahrenheit + " stopni Fahrenheita");
    }
}
