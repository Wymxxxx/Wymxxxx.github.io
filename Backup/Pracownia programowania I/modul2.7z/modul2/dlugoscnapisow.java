import java.util.Scanner;
public class DlugoscNapisow 
{
    public static void main(String[] args) 
    {
        Scanner slowo = new Scanner(System.in);
        System.out.println("Podaj pierwsze s�owo: ");
        String slowo1 = slowo.nextLine();
        System.out.println("Podaj drugie s�owo; ");
        String slowo2 = slowo.nextLine();
        String dluzszeSlowo = slowo1.length()>slowo2.length()?slowo1:slowo2;        
        System.out.println("D�u�sze S�owo to: " + dluzszeSlowo); 
    }
}
