import java.util.Scanner;

public class ZDuzejLitery 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzone = new Scanner(System.in);
        System.out.println("Podaj Imi�: ");
        String imie = wprowadzone.nextLine();
        System.out.println("Podaj Nazwisko: ");
        String nazwisko = wprowadzone.nextLine();
        
        String poprawneImie = (imie.substring(0, 1)).toUpperCase() + (imie.substring(1)).toLowerCase();
        String poprawneNazwisko = (nazwisko.substring(0, 1)).toUpperCase() + (nazwisko.substring (1)).toLowerCase();
        System.out.println(poprawneImie + " " + poprawneNazwisko);
    }
}
