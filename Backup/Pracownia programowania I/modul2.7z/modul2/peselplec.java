import java.util.Scanner;
public class PeselPlec 
{
    public static void main(String[] args) 
    {
    	Scanner pesel = new Scanner(System.in);
    	System.out.println("Podaj sw�j Pesel: ");
    	String nrPesel = pesel.nextLine();
    	String plec = nrPesel.substring(9, 10);
    	int cyfraPlci = Integer.parseInt(plec);
    	String twojaPlec = (cyfraPlci%2)==0?"Kobiet�":"M�czyzn�";
    	System.out.println("Jeste� " + twojaPlec);
    }
}
