import java.util.Scanner;
public class WielkieLitery 
{
    public static void main(String[] args) 
    {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Wprowad� dowolny tekst: ");
    	String tekst = sc.nextLine();
    	System.out.println(tekst.toUpperCase());
    }
}
