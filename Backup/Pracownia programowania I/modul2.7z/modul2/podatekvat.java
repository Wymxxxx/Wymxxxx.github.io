public class PodatekVAT 
{
    public static void main(String[] args) 
    {
    	String towar = args[0];
    	int cenaNetto = Integer.parseInt(args[1]);
    	final Double stawkaVat = 0.22;
    	Double cenaBrutto = cenaNetto + (cenaNetto*stawkaVat);
    	System.out.println("Cena netto towaru: " + towar + " wynosi: " + cenaNetto + "z� \n" + "Stawka Vat wynosi 22%, Cena brutto wynosi: " + cenaBrutto + "z�");
    }
}
