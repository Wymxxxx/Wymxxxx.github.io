public class StandardUnicode {
     public static void main(String[] args) {
     	char M = '\u004D';
     	char a = '\u0061';
     	char t = '\u0071';
     	char e = '\u0065';
     	char u = '\u0075';
     	char s = '\u0073';
     	char z = '\u007A';
     	char � = '\u0141';
     	char c = '\u0063';
     	char y = '\u0079';
     	char � = '\u0144';
     	char k = '\u0075';
     	char i = '\u0069';
     	System.out.println(M + "" + a + "" + t + "" + e + "" + u + "" + s + "" + z + " " + � + "" + u + "" + s + "" + z + "" + c + "" + z + "" + y + "" + � + "" + s + "" + k + "" + i);
    	}
}
