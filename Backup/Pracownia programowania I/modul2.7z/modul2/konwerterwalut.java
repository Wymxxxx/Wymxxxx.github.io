public class KonwerterWalut 
{
    public static void main(String[] args)
    {
    	double kurs = 2.56;
    	double zlotowka = Integer.parseInt(args[0]);
    	System.out.println(zlotowka + " z�otych to " + (zlotowka/kurs) + " euro");
    }
}
