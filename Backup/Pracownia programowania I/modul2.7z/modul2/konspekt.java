public class konspekt {
  public static void main(String[] args) {
   String nazwaProduktu = "Telefon kom�rkowy";
   System.out.println("Liczba Znak�w:" + nazwaProduktu.length());
   System.out.println("Liczba Znak�w:" + "Programowanie rozproszone".length());
   
   String rezultat;
   String adres = "ul.Szeroka";
   rezultat = "ul.Kwiatkowa".equals("ul.Kwiatkowa") ? "adres zgodny" : "adres inny";
   System.out.println(rezultat);
   rezultat = "ul.Kwiatkowa".equals(adres) ? "adres zgodny" : "adres inny";
   System.out.println(rezultat);
   
   //tablice jednowymiarowe, deklaracja zmiennej tablicowej
   double[] cenaArtykulu;
   String[] cechaCharakteru;
   int[] rzutKostka;
   
   //utworzenie tablicy (okre�lenie liczby element�w)
   cenaArtykulu = new double[50];
   cechaCharakteru = new String[3];
   rzutKostka = new int[8];
   
   //jednoczesna deklaracja i utworzenie
   String[] srodekTransportu = new String[2];
   
   //jednoczesna deklaracja, utworzenie tablicy 3 elementowej i nadanie warto�ci
   String[] sygnalizator = {"czerwony","��ty","zielony"};
      
   //Dost�p do elementu tablicy (przypisanie i odczyt)
   cenaArtykulu[17] = 328.50;
   cenaArtykulu[25] = 29.0;
   double Razem = cenaArtykulu[17] + cenaArtykulu[25];
   rzutKostka[7] = 3;
   cechaCharakteru[0] = "komunikatywno��";
   cechaCharakteru[2] = "asertywno��";
   srodekTransportu[1] = "rower";
   System.out.println(sygnalizator[2]);
   
   //Tablice wielowymiarowe, deklaracja oraz inicjalizacja
   int[][] tabliczkaMnozenia = {{1,2,3},{2,4,6},{3,6,9}};
   System.out.println(tabliczkaMnozenia[2][0]);
   	    
   //odczytywanie liczby element�w tablicy
   String[] koloryTeczy = {"czerwony","pomara�czowy","��ty","zielony","niebieski","fioletowy"};
   int liczbaKolorowTeczy = koloryTeczy.length;
   System.out.println(liczbaKolorowTeczy);
   
   //typ wyliczeniowy
   enum Dzien {PN,WT,�R,CZ,PT,SB,ND};
   Dzien dzienPracy = Dzien.WT;
   Dzien dzienWolny = Dzien.SB;
   System.out.println(dzienPracy!=dzienWolny);
   }
}
