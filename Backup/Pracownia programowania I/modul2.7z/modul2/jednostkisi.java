public class JednostkiSI {
   public static void main(String[] args) {
   		String[] jednostki = {"kg","cd","s","A","K","mol","m"};
   		System.out.println("Jednostki podstawowe uk�adu SI");
   		System.out.println("================================");
   		System.out.println("Jednostka temperatury (Kelvin) " + jednostki[4]);
   		System.out.println("Jednostka masy (Kilogram) " + jednostki[0]);
   		System.out.println("Jednostka d�ugo�ci (metr) " + jednostki[jednostki.length-1]);
   		System.out.println("--------------------------------");
   		System.out.println("Liczba jednostek " + jednostki.length);
    }
}
