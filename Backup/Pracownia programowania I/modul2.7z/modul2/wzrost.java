import java.util.Scanner;

public class Wzrost 
{
    public static void main(String[] args) 
    {
        Scanner podane = new Scanner(System.in);
        System.out.println("Podaj sw�j wzrost w centymetrach: ");
        Double wzrostCm = podane.nextDouble();
        Double wzrostCale = wzrostCm/2.54;
        Double wzrostStopy = wzrostCm/30.48;
        System.out.println("Masz " + wzrostCm + " wzrostu w centymetrach, " + wzrostCale + " wzrostu w calach, " + wzrostStopy + " wzrostu w stopach");
    }
}
