/*
 *Choinka
 *autor: Mateusz �uszczy�ski (c) 2008
 */
 public class Choinka {
	public static void main(String[] args) {
		// Wy�wietli choinke
		System.out.println("   *");
		System.out.println("  ***");
		System.out.println(" *****");
		System.out.println("*******");
		System.out.println("   |");
	}
 }