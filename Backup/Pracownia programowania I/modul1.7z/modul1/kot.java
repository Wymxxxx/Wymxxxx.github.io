/*
 *Kot
 *autor: Piotr Nowak (c) 2008
 */
 
public class Kot {
	public static void main(String[] args){
		// Kocie my�lenie
			System.out.println("Mrucze, wi�c jestem... ");
	}
}