public class WlasciwosciSrodowiska {
	public static void main(String[] args){
		System.out.println("Wersja JRE:" + System.getProperty("java.version"));
		System.out.println("Wersja JVM:" + System.getProperty("java.vm.version"));
		System.out.println("Katalog instalacyjny:" + System.getProperty("java.home"));
		System.out.println("System Operacyjny:" + System.getProperty("os.name"));
		System.out.println("Wersja Systemu:" + System.getProperty("os.version"));
		System.out.println("Nazwa u�ytkownika:" + System.getProperty("user.name"));
		System.out.println("Katalog Bie��cy:" + System.getProperty("user.dir"));
		System.out.println("Znak Ko�ca linii:" + System.getProperty("line.separator"));
	}
}