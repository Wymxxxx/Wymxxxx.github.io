public class LiczbaPseudolosowa {
	public static void main(String[] args){
		System.out.println("Oto liczba pseudolosowa:" + Math.random());
	}
}