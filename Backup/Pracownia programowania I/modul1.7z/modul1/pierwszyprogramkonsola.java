/*
 *PierwszyProgramKonsola
 *autor: Mateusz �uszczy�ski (c) 2008
 */
 public class PierwszyProgramKonsola {
 	public static void main(String[] args) {
 		// Wy�wietli napis
 		System.out.println("Uniwersytet Ekonomiczny w Krakowie");
 	}
 }