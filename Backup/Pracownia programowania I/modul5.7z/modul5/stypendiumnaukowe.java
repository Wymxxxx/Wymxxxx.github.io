import java.util.*;

class Statystyka 
{
	private double dane[];
	public Statystyka(double[] tablica) 
	{
		dane = tablica;
	}
	public double sredniaArytmetyczna()
	{
		double suma = 0;
		for (double x : dane) suma += x;
		return (suma/dane.length);
	}
}

public class StypendiumNaukowe
{
	public static void main(String[] args)
	{
		Scanner wprowadzono = new Scanner(System.in);
		System.out.print("Podaj ilo�� ocen: ");
		int ilosc = wprowadzono.nextInt();
		double[] oceny = new double[ilosc];
		for(int i=0; i<ilosc; i++)
		{
			System.out.print("Podaj ocen�: ");
			oceny[i] = wprowadzono.nextDouble();
		}
		Statystyka obliczenia = new Statystyka(oceny);
		double srednia = obliczenia.sredniaArytmetyczna();
		System.out.println("Stypendium naukowe " + (srednia >= 4.8 ? "zosta�o przyznane" : "nie zosta�o przyznane"));
	}
}
