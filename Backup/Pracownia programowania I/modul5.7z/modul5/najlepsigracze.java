import java.util.*;

class Gracz 
{
    String nick;
    int wynik;
   
    public Gracz(String nick, int wynik)
    {
        this.nick = nick;
        this.wynik = wynik;
    }
    public String pobierzNick()
    {
        return nick;
    }
    public int pobierzWynik()
    {
        return wynik;
    }
    public String toString()
    {
        return nick + " " + wynik + "\n";
    }
}

class NajlepszaDziesiatka 
{
    Gracz[] top;
   
    public NajlepszaDziesiatka() 
    {
        top = new Gracz[10];
    }
    public void dodajGracza(Gracz gracz, int miejsce)
    {
        top[miejsce] = gracz;
    }
    public void wypiszNajlepszych() 
    {
        System.out.println(" ---------------------------");
        System.out.println(" Miejsce |   Nick   | Punkty");
        System.out.println(" ---------------------------");
        for (int i=0; i<10; i++)
            System.out.printf(" %5d.  | %-9s| %4d \n", i+1,top[i].pobierzNick(), top[i].pobierzWynik());
        System.out.println(" ---------------------------");
    }
    public String toString() 
    {
        String wynik = "";
        for(Gracz x : top) wynik += x;
        return wynik;
    }
}

public class NajlepsiGracze 
{
    static void sortujGraczy(Gracz[] tab) 
    {
        Gracz temp;
        int i,j;
        int n = tab.length;
        for(j = 0; j<n-1; j++) 
        {
            for(i = 0; i<n-1; i++) 
            {
            	if (tab[i].pobierzWynik() > tab[i+1].pobierzWynik()) 
            	{
                    temp = tab[i]; tab[i] = tab[i+1]; tab[i+1] = temp;
                }
            }   
        }
    }  
    public static void main(String[] args) 
    {
        String nicki = "Lady Malina Manowar Marta2 Marther MaSter Mayar Metalka Mansonka Laughlin Michuw Pan Paz Pinkfan Picha Princess Pro Punkow Ulver Vaderka Vader Vassago Vea Vegeta^ Verbal Vjosna Czeslaw Ania Troja Krokodyl";
        String[] tabNickow = nicki.split(" ");
        Random generator = new Random();
       
        Gracz[] tabGraczy = new Gracz[30];
        for (int i=0; i<30; i++) 
        {
            tabGraczy[i] = new Gracz(tabNickow[i], generator.nextInt(10000)+1);
        }
        sortujGraczy(tabGraczy);
         
        NajlepszaDziesiatka tabDziesieciu = new NajlepszaDziesiatka();
        int miejsce = 0;
        for (int i=29; i>=20; i--) 
        {
            tabDziesieciu.dodajGracza(tabGraczy[i], miejsce);
            miejsce++;
        }
        tabDziesieciu.wypiszNajlepszych();
    }
}