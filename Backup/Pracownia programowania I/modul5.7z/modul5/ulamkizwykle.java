class Ulamek 
{
	private int licznik;
	private int mianownik;

	public Ulamek() 
	{
		this.licznik = 0;
		this.mianownik = 1;
	}
	public Ulamek(int licznik) 
	{
		this.licznik = licznik;
		this.mianownik = 1;
	}
	public Ulamek(int licznik, int mianownik) 
	{
		this.licznik = licznik;
		this.mianownik = mianownik;
		uproscUlamek(this);
	}
	private static int obliczNWD(Ulamek a) 
	{
		int l,m;
		l = a.licznik;
		m = a.mianownik;
		if (l < 0) l = - l;
		if (m < 0) m = - m;
		while ( l != m) 
		{
			if (l > m) l = l - m;
			else m = m - l;
		}
		return l;
	}
	private static void uproscUlamek(Ulamek a) 
	{
		int nwd;
		nwd = obliczNWD(a);
		a.licznik /= nwd;
		a.mianownik /= nwd;
	}
	public String toString() 
	{
		return this.licznik + "/" + this.mianownik;
	}
}

public class UlamkiZwykle 
{
	public static void main (String[] args) 
	{
		Ulamek x = new Ulamek(4,6);
		Ulamek y = new Ulamek(10,12);
		System.out.println("Ulamek x = " + x);
		System.out.println("Ulamek y = " + y);
	}
}