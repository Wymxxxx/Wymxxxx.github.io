import java.util.*;

class Statystyka 
{
	private double dane[];
	
	public Statystyka(double[] tablica) 
	{
		dane = tablica;
		Arrays.sort(dane);
	}
	
	public double sredniaArytmetyczna()
	{
		double suma = 0;
		for (double x : dane) suma += x;
		return (suma/dane.length);
	}
	private static double sredniaArytmetyczna (double[] dane) 
	{
        double suma = 0;
        for (double x : dane)
        suma += x;
        return (suma / dane.length);
    } 
	public double mediana()
	{
		double mediana;
		if((dane.length%2)==0)
		{
			mediana = (dane[((dane.length)/2)-1] + dane[((dane.length)/2)])/2;
		}
		else mediana = dane[((dane.length+1)/2)-1];
		return mediana;
	}
	public String dominanta() 
	{
        int i,j;
        String dominanta = "0";
        int[] iloscWystapien = new int[dane.length];
        for (i=0; i<iloscWystapien.length; i++) iloscWystapien[i] = 0;
        int[] iloscWystapienSort = new int[dane.length];
        for (i=0; i<dane.length; i++)
        {
            for (j=i; j<dane.length; j++) 
            {
                if (dane[i]==dane[j]) iloscWystapien[i]++;
            }
        }
        int n = iloscWystapienSort.length;
        for (i=0; i<n; i++) iloscWystapienSort[i] = iloscWystapien[i];
        Arrays.sort(iloscWystapienSort);
        if (iloscWystapienSort[n-1] == iloscWystapienSort[n-2])    dominanta = "Brak dominanty";
        else 
        {
            for (i=0; i<iloscWystapien.length; i++) 
            {
                if (iloscWystapien[i] == iloscWystapienSort[n-1]) 
                {
                    dominanta = Double.toString(dane[i]);
                    break;
                }
            }
        }
        return dominanta;
    } 
	public double odchylenieSrednie()
	{
		double suma = 0;
		double srednia = sredniaArytmetyczna();
		for(double element:dane)
		{
			suma += Math.abs(element-srednia);
		}
		double odchylenieSrednie = suma/dane.length;
		return odchylenieSrednie;
	}
	public double wariancja()
	{
		double suma = 0;
		double srednia = sredniaArytmetyczna(dane);
		for(double element:dane)
		{
			suma += Math.pow((element-srednia),2);
		}
		double wariancja = suma/dane.length;
		return wariancja;
	}
	public double odchylenieStandardowe()
	{
		double suma = 0;
		double srednia = sredniaArytmetyczna(dane);
		for(double element:dane)
		{
			suma += Math.pow((element-srednia),2);
		}
		double odchylenieStandardowe = Math.sqrt(suma/dane.length);
		return odchylenieStandardowe;
	}
	
}

public class ObliczeniaStatystyczne
{
	public static void main(String[] args)
	{
		double[] klient1 = {0.5,4.7,3.8,7.9,5.2,6.0,3.5,7.1};
		double[] klient2 = {9.3,2.6,6.3,5.2,3.5,8.3,8.1,3.0,3.1,5.2,7.7};
		double[] klient3 = {2.1,2.5,2.8,3.4,4.5,3.9,5.6,6.0,5.7,3.4,2.4,9.1,8.3,8.8};
		
		Statystyka klient11 = new Statystyka(klient1);
		Statystyka klient22 = new Statystyka(klient2);
		Statystyka klient33 = new Statystyka(klient3);
		
		System.out.println("Mediana dla klient1 wynosi = " + klient11.mediana());
		System.out.println("Mediana dla klient2 wynosi = " + klient22.mediana());
		System.out.println("Mediana dla klient3 wynosi = " + klient33.mediana());
		
		System.out.println("Wariancja dla klient1 wynosi = " + klient11.wariancja());
		System.out.println("Wariancja dla klient2 wynosi = " + klient22.wariancja());
		System.out.println("Wariancja dla klient3 wynosi = " + klient33.wariancja());
		
		System.out.println("Odchylenie Standardowe dla klient1 wynosi = " + klient11.odchylenieStandardowe());
		System.out.println("Odchylenie Standardowe dla klient2 wynosi = " + klient22.odchylenieStandardowe());
		System.out.println("Odchylenie Standardowe dla klient3 wynosi = " + klient33.odchylenieStandardowe());
		
		System.out.println("Odchylenie �rednie dla klient1 wynosi = " + klient11.odchylenieSrednie());
		System.out.println("Odchylenie �rednie dla klient2 wynosi = " + klient22.odchylenieSrednie());
		System.out.println("Odchylenie �rednie dla klient3 wynosi = " + klient33.odchylenieSrednie());
		
		System.out.println("Dominanta dla klient1 wynosi = " + klient11.dominanta());
		System.out.println("Dominanta dla klient2 wynosi = " + klient22.dominanta());
		System.out.println("Dominanta dla klient3 wynosi = " + klient33.dominanta());
	}
}
