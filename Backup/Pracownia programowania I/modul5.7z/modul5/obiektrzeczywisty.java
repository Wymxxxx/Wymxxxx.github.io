class Komputer
{
	private String kartaGraficzna;
	private String procesor;
	private String ram;
	private String dysk;
	
	public Komputer(String procesor, String ram, String kartaGraficzne, String dysk)
	{
		this.procesor = procesor;
		this.ram = ram;
		this.kartaGraficzna = kartaGraficzna;
		this.dysk = dysk;
	}
}
public class ObiektRzeczywisty 
{
    public static void main(String[] args) 
    {
        Komputer komp1 = new Komputer("Amd","2gb","Geforce","200gb");
        Komputer komp2 = new Komputer("Intel","2gb","Radeon","500gb");
    }
}
