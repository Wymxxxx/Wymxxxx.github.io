/**
 * @(#)LiczbyZespolone.java
 *
 *
 * @author 
 * @version 1.00 2008/4/14
 */

public class LiczbyZespolone {
        
    /**
     * Creates a new instance of <code>LiczbyZespolone</code>.
     */
    public LiczbyZespolone() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
