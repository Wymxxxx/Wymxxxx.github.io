import java.util.*;
class Telefon
{
	private String numerTelefonu;
	private int lacznyCzasRozmow;
	private static double cenaRozmowy = 0.48;
	private String[] wybieraneNumery = new String[10];
	private int numerPolaczenia = 0;
	
	public Telefon (String numer)
	{
		numerTelefonu = numer;
	}
	
	double obliczKwoteDoZaplaty()
	{
		return cenaRozmowy*(lacznyCzasRozmow/60);
	}
	static void ustawCeneRozmowy(double nowaCena)
	{
		cenaRozmowy = nowaCena;
	}
	public String pobierzNumerTelefonu()
	{
		return numerTelefonu;
	}
	public double pobierzCeneRozmowy()
	{
		return cenaRozmowy;
	}
	public int pobierzLacznyCzasRozmow()
	{
		return lacznyCzasRozmow;
	}
	public void zmienNumerTelefonu(String nowyNumer)
	{
		numerTelefonu = nowyNumer;
	}
	public void zmienCenePolaczenia(double nowaCena)
	{
		cenaRozmowy = nowaCena;
	}
	public void wyswietlListePolaczen()
	{
		System.out.println("Ostatnio wybierane numery: ");
		for(String numer:wybieraneNumery)
		{
			System.out.println(numer);
		}
	}
	
	void zadzwon(String nrTelefonu)
	{
		System.out.println ("Dzwoni� do: " + nrTelefonu);
		System.out.println("Dry�, dryn...");
		System.out.println("Rozmowa w toku...");
		int czasRozmowy = (int) (Math.random()*3600);
		lacznyCzasRozmow += czasRozmowy;
		System.out.println("Rozmowa zako�czona. ");
		System.out.printf("Czas rozmowy: %d min. %d sek. \n", czasRozmowy/60, czasRozmowy%60);
		wybieraneNumery[numerPolaczenia] = nrTelefonu;
		numerPolaczenia++;
	}
}
public class WybieraneNumery
{
    public static void main(String[] args) 
    {
        Telefon telefonAni = new Telefon("123456789");
        String[] numeryTelefonow = {"123","43131","131413","99877","134315","09319","8479","31948913","0993111","13431"};
        for(String numer:numeryTelefonow)
        {
        	telefonAni.zadzwon(numer);
        }
        telefonAni.wyswietlListePolaczen();
        
	}
}
