class Ulamek 
{
	private int licznik;
	private int mianownik;

	public Ulamek() 
	{
		this.licznik = 0;
		this.mianownik = 1;
	}
	public Ulamek(int licznik) 
	{
		this.licznik = licznik;
		this.mianownik = 1;
	}
	public Ulamek(int licznik, int mianownik) 
	{
		this.licznik = licznik;
		this.mianownik = mianownik;
		uproscUlamek(this);
	}
	
	private static int obliczNWD(Ulamek a) 
	{
		int l,m;
		l = a.licznik;
		m = a.mianownik;
		if (l < 0) l = - l;
		if (m < 0) m = - m;
		while ( l != m) 
		{
			if (l > m) l = l - m;
			else m = m - l;
		}
		return l;
	}
	private static void uproscUlamek(Ulamek a) 
	{
		int nwd;
		nwd = obliczNWD(a);
		a.licznik /= nwd;
		a.mianownik /= nwd;
	}
	public String toString() 
	{
		return this.licznik + "/" + this.mianownik;
	}
	
	public static Ulamek iloczynUlamkow(Ulamek a, Ulamek b)
	{
		Ulamek wynik = new Ulamek(a.licznik*b.licznik, a.mianownik*b.mianownik);
		uproscUlamek(wynik);
		return wynik;
	}
	public static Ulamek sumaUlamkow(Ulamek a, Ulamek b)
	{
		Ulamek wynik = new Ulamek();
		wynik.licznik = a.licznik*b.mianownik+b.licznik*a.mianownik;
		wynik.mianownik = a.mianownik*b.mianownik;
		uproscUlamek(wynik);
		return wynik;
	}
	public static Ulamek ilorazUlamkow(Ulamek a, Ulamek b)
	{
		Ulamek wynik = new Ulamek();
		wynik.licznik = a.licznik*b.mianownik;
		wynik.mianownik = a.mianownik*b.licznik;
		uproscUlamek(wynik);
		return wynik;
	}
	public static Ulamek roznicaUlamkow(Ulamek a, Ulamek b)
	{
		Ulamek wynik = new Ulamek();
		wynik.licznik = a.licznik*b.mianownik-b.licznik*a.mianownik;
		wynik.mianownik = a.mianownik*b.mianownik;
		uproscUlamek(wynik);
		return wynik;
	}
	public static Ulamek naZwykly(double a)
	{
        Ulamek zwykly = new Ulamek();
        int i=0;
        while(a!=(int)a)
        {
            a*=10;
            i++;
        }
        zwykly.licznik = (int)a;
        zwykly.mianownik = (int)Math.pow(10, i);
        return zwykly
    }        
	public static double naDziesietny(Ulamek a)
	{
		double dziesietny = (double)a.licznik/a.mianownik; 
		return dziesietny;
	}
}

public class OperacjeNaUlamkach 
{
	public static void main (String[] args) 
	{
		Ulamek x = new Ulamek(4,6);
		Ulamek y = new Ulamek(10,12);
		System.out.println("Ulamek x = " + x);
		System.out.println("Ulamek y = " + y);
		System.out.println("Iloczyn u�amk�w x i y = " + Ulamek.iloczynUlamkow(x,y));
		System.out.println("Suma u�amk�w x i y = " + Ulamek.sumaUlamkow(x,y));
		System.out.println("Iloraz u�amk�w x i y = " + Ulamek.ilorazUlamkow(x,y));
		System.out.println("R�nica u�amk�w x i y = " + Ulamek.roznicaUlamkow(x,y));
		System.out.println("x dziesi�tnie to " + Ulamek.naDziesietny(x) + ", y dziesi�tnie to " + Ulamek.naDziesietny(y));
	}
}