/*
 * Nazwa: ZamianaLiczb
 * Uruchomienie: 
 *
 * cmd.exe:
 * Kompilacja poleceniem javac sterowaniePrzebiegiemProgramu.java
 * Uruchomienie poleceniem java sterowaniePrzebiegiemProgramu
 */

//Import klas bibliotecznych
import java.util.Scanner;

public class ZamianaLiczb 
	{	 
		 public static int[] liczbyArabskie   = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
 		 public static String[] liczbyRzymskie = {"M", "CM", "D", "CD", "C","XC", "L", "XL", "X", "IX", "V", "IV", "I"};

		//Metoda sprawdzajaca poprawnosc liczby liczbyRzymskiej podanej przez uzytkownika
		public static boolean sprPoprawnosc(String liczba)
			{
				//Konwersja podanych znakow na wielkie (takie znajduja sie w tablicy i takie sa uzywane do zapisu liczb rzymskich)
				liczba = liczba.toUpperCase();  
				//Zwroc false, jesli liczba jest pusta
  				if (liczba.length() == 0) return false; 
				//Zeby sprawdzic, czy podana liczba rzymska jest prawidlowa, przeliczam ja na arabska i powtornie na rzymska, w przypadku gdy wejsciowa i wyjsciowa nie sa sobie rowne, zwracam false
  				if (!liczba.equals(zmienArabskaNaRzymska(zmienRzymskaNaArabska(liczba)))) return false;
				//Jesli podana liczba wejsciowa jest rowna liczbie wyjsciowej, zwracam true
  				else return true;
 			}
 			
 		//Metoda statyczna zamieniajaca liczbe arabska na rzymska - potrzebna do sprawdzenia poprawnosci liczby liczbyRzymskiej				
 		public static String zmienArabskaNaRzymska(int liczba) 
 			{	
 				//Przechowywanie w zmiennej wynik liczby rzymskiej
 				String wynik = "";
 				
 				//Petla sprawdzajaca elementy tablicy
  				for (int i = 0; i < liczbyArabskie.length; i++) 
  					{
  						while (liczba >= liczbyArabskie[i]) 
  							{
  								//Tworzy liczbe rzymska
   								wynik += liczbyRzymskie[i];
								//Zmniejsza arabska
								liczba -= liczbyArabskie[i];
   							}
  					}
				//Zwraca liczbe rzymska
  				return wynik;
			}
 		//Metoda statyczna zamieniajaca liczbe rzymska na arabska
 		public static int zmienRzymskaNaArabska(String liczba) 
 			{	
 				//Zamiana wszystkich otrzymanych znakow na duze (takie mamy w tablicy i takie sa uzywane do zapisu liczb rzymskich)
 				liczba = liczba.toUpperCase();
 				//Zmienna wynik przechowuje liczbe arabska
  				int wynik = 0;
  				//Zmienna indeks umozliwa przemieszczanie sie po tablicy
 				int indeks = 0;      
 				
 				//Petla sprawdzajaca elementy tablicy
  				for (int i = 0; i < liczbyRzymskie.length; i++) 
  					{
  						//Jesli podana liczba zaczyna sie liczba rzymska
   						while (liczba.startsWith(liczbyRzymskie[i], indeks)) 
   							{
   								//Tworzy liczbe arabska
    							wynik += liczbyArabskie[i];
    							//i przechodzi do kolejnej pozycji
    							indeks += liczbyRzymskie[i].length();
   							}
  					}  
 				//Zwraca liczbe arabska
  				return wynik;
 			} 
  
public static void main (String[] args) 
 	{
  		String rzymska;
  		rzymska = args[0];
  		
  		//Sprawdzenie poprawnosci podanej liczby
  		if(sprPoprawnosc(rzymska)) 
  			{	
  				//Wyswietl liczbe arabska
  				System.out.println("Liczba arabska: " + zmienRzymskaNaArabska(rzymska));
  			} 
  		else 
  			{
   				System.out.println ("-1");      
  			}
 	}
}
