import java.util.*;

class WspolrzedneGeograficzne
{
	private double szerokoscStopnie;
	private double szerokoscMinuty;
	private double szerokoscSekundy;
	private double dlugoscStopnie;
	private double dlugoscMinuty;
	private double dlugoscSekundy;
	
	public WspolrzedneGeograficzne (double szerokoscStopnie, double szerokoscMinuty, double szerokoscSekundy, double dlugoscStopnie, double dlugoscMinuty, double dlugoscSekundy)
	{
		this.szerokoscStopnie = szerokoscStopnie;
		this.szerokoscMinuty = szerokoscMinuty;
		this.szerokoscSekundy = szerokoscSekundy;
		this.dlugoscStopnie = dlugoscStopnie;
		this.dlugoscMinuty = dlugoscMinuty;
		this.dlugoscSekundy = dlugoscSekundy;
	}
	public static double wyznaczOdleglosc(WspolrzedneGeograficzne miasto1, WspolrzedneGeograficzne miasto2)
	{
		double odleglosc = Math.sqrt(Math.pow((miasto1.dlugoscStopnie - miasto2.dlugoscStopnie), 2) + 
					                 Math.pow((miasto1.szerokoscStopnie - miasto2.szerokoscStopnie), 2));
		return odleglosc;
	}
}

public class KartografiaMoja 
{
    public static void main(String[] args) 
    {
        WspolrzedneGeograficzne czechowiceDziedzice = new WspolrzedneGeograficzne(49,54,00,19,00,00);
        WspolrzedneGeograficzne krakow = new WspolrzedneGeograficzne(50,03,41.56,19,56,18.97);
        WspolrzedneGeograficzne warszawa = new WspolrzedneGeograficzne(52,13,56.28,21,00,30.36);
        double odleglosc = WspolrzedneGeograficzne.wyznaczOdleglosc(czechowiceDziedzice, krakow);
        System.out.println("Odleg�o�� wynosi = " + odleglosc);
    }
}



