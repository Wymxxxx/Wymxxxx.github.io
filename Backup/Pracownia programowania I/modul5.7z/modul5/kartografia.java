import java.lang.Math;
class WspolrzedneGeograficzne
{
    private char polkula;
    private int stopnie;
    private int minuty;
    private int sekundy;
    public WspolrzedneGeograficzne(char polkula, int stopnie, int minuty, int sekundy)
    {
        this.polkula = polkula;
        this.stopnie = stopnie;
        this.minuty = minuty;
        this.sekundy = sekundy;
    }
    public char pobierzPolkula()
    {
        return polkula;
    }
    public int pobierzStopnie()
    {
        return stopnie;
    }
    public int pobierzMinuty()
    {
        return minuty;
    }
    public int pobierzSekundy()
    {
        return sekundy;
    }
    public void wyswietlanieWspolrzedne(WspolrzedneGeograficzne a)
    {
        System.out.print("(" + pobierzStopnie()+"�"+pobierzMinuty()+"'"+pobierzSekundy()+"'' "+pobierzPolkula()+ ")");
    }
}

class Kartografia{
    static void wyznaczOdleglosc(WspolrzedneGeograficzne a, WspolrzedneGeograficzne b)
    {
        int stopnie, minuty, sekundy;
        if (a.pobierzPolkula()==b.pobierzPolkula())
        {
            if (a.pobierzStopnie()>b.pobierzStopnie())
            {
                if(a.pobierzMinuty()>b.pobierzMinuty())
                {
                    if(a.pobierzSekundy()>b.pobierzSekundy())
                    {
                        stopnie=a.pobierzStopnie()-b.pobierzStopnie();
                        minuty=a.pobierzMinuty()-b.pobierzMinuty();
                        sekundy=a.pobierzSekundy()-b.pobierzSekundy();
                    } 
                    else 
                    {
                        stopnie=a.pobierzStopnie()-b.pobierzStopnie();
                        minuty=a.pobierzMinuty()-b.pobierzMinuty()-1;
                        sekundy=a.pobierzSekundy()-b.pobierzSekundy()+60;
                    }
                } 
                else 
                {
                    if(a.pobierzSekundy()>b.pobierzSekundy())
                    {
                        stopnie=a.pobierzStopnie()-b.pobierzStopnie()-1;
                        minuty=a.pobierzMinuty()-b.pobierzMinuty()+60;
                        sekundy=a.pobierzSekundy()-b.pobierzSekundy();
                    }
                    else 
                    {
                        stopnie=a.pobierzStopnie()-b.pobierzStopnie()-1;
                        minuty=a.pobierzMinuty()-b.pobierzMinuty()+59;
                        sekundy=a.pobierzSekundy()-b.pobierzSekundy()+60;
                    }
                }
            } 
            else 
            {
                if(b.pobierzMinuty()>a.pobierzMinuty())
                {
                    if(b.pobierzSekundy()>a.pobierzSekundy())
                    {
                        stopnie=b.pobierzStopnie()-a.pobierzStopnie();
                        minuty=b.pobierzMinuty()-a.pobierzMinuty();
                        sekundy=b.pobierzSekundy()-a.pobierzSekundy();
                    } 
                    else 
                    {
                        stopnie=b.pobierzStopnie()-a.pobierzStopnie();
                        minuty=b.pobierzMinuty()-a.pobierzMinuty()-1;
                        sekundy=b.pobierzSekundy()-a.pobierzSekundy()+60;
                    }
                } 
                else 
                {
                    if(b.pobierzSekundy()>a.pobierzSekundy())
                    {
                        stopnie=b.pobierzStopnie()-a.pobierzStopnie()-1;
                        minuty=b.pobierzMinuty()-a.pobierzMinuty()+60;
                        sekundy=b.pobierzSekundy()-a.pobierzSekundy();
                    } 
                    else 
                    {
                        stopnie=b.pobierzStopnie()-a.pobierzStopnie()-1;
                        minuty=b.pobierzMinuty()-a.pobierzMinuty()+59;
                        sekundy=b.pobierzSekundy()-a.pobierzSekundy()+60;
                    }
                }
            }
        } 
        else 
        {
            stopnie = a.pobierzStopnie()+b.pobierzStopnie();
            minuty = a.pobierzMinuty()+b.pobierzMinuty();
            sekundy = a.pobierzSekundy()+b.pobierzSekundy();
            if (sekundy>60)
            {
                minuty++;
                sekundy=sekundy-60;
            }
            if (minuty>60)
            {
                stopnie++;
                minuty=minuty-60;
            }
        }
        System.out.println("Stopnie: " + stopnie + " minuty: " + minuty + " sekundy: " + sekundy);
    }
    public static void main(String[] args)
    {
        WspolrzedneGeograficzne czechowiceDziedziceDl = new WspolrzedneGeograficzne('E', 19,00,00);
        WspolrzedneGeograficzne czechowiceDziedziceSzer = new WspolrzedneGeograficzne('N', 49,54,00);
        WspolrzedneGeograficzne krakowDl = new WspolrzedneGeograficzne('E', 19,56,18);
        WspolrzedneGeograficzne krakowSzer = new WspolrzedneGeograficzne('N', 50,3,41);
        WspolrzedneGeograficzne warszawaDl = new WspolrzedneGeograficzne('E', 21,00,30);
        WspolrzedneGeograficzne warszawaSzer = new WspolrzedneGeograficzne('N', 52,13,56);
        
        System.out.print("Odleg�o�� pomi�dzy szeroko�ciami Czechowice Dziedzice ");
        czechowiceDziedziceSzer.wyswietlanieWspolrzedne(czechowiceDziedziceSzer);
        System.out.print(" a Krakowa ");
        krakowSzer.wyswietlanieWspolrzedne(krakowSzer);
        System.out.print(" wynosi: ");
        wyznaczOdleglosc(czechowiceDziedziceSzer, krakowSzer);
        System.out.print("Odleg�o�� pomi�dzy d�ugo�ciami Czechowic Dziedzic ");
        czechowiceDziedziceDl.wyswietlanieWspolrzedne(czechowiceDziedziceDl);
        System.out.print(" a Krakowa ");
        krakowDl.wyswietlanieWspolrzedne(krakowDl);
        System.out.print(" wynosi: ");
        wyznaczOdleglosc(czechowiceDziedziceDl, krakowDl);
        System.out.print("Odleg�o�� pomi�dzy szeroko�ciami Warszawy ");
        warszawaSzer.wyswietlanieWspolrzedne(warszawaSzer);
        System.out.print(" a Krakowa ");
        krakowSzer.wyswietlanieWspolrzedne(krakowSzer);
        System.out.print(" wynosi: ");
        wyznaczOdleglosc(warszawaSzer, krakowSzer);
        System.out.print("Odleg�o�� pomi�dzy d�ugo�ciami Warszawy ");
        warszawaDl.wyswietlanieWspolrzedne(warszawaDl);
        System.out.print(" a Krakowa ");
        krakowDl.wyswietlanieWspolrzedne(krakowDl);
        System.out.print(" wynosi: ");
        wyznaczOdleglosc(warszawaDl, krakowDl);
        System.out.print("Odleg�o�� pomi�dzy szeroko�ciami Warszawy ");
        warszawaSzer.wyswietlanieWspolrzedne(warszawaSzer);
        System.out.print(" a Czechowic Dziedzic ");
        czechowiceDziedziceSzer.wyswietlanieWspolrzedne(czechowiceDziedziceSzer);
        System.out.print(" wynosi: ");
        wyznaczOdleglosc(warszawaSzer, czechowiceDziedziceSzer);
        System.out.print("Odleg�o�� pomi�dzy d�ugo�ciami Warszawy ");
        warszawaDl.wyswietlanieWspolrzedne(warszawaDl);
        System.out.print(" a Czechowic Dziedzic ");
        czechowiceDziedziceDl.wyswietlanieWspolrzedne(czechowiceDziedziceDl);
        System.out.print(" wynosi: ");
        wyznaczOdleglosc(warszawaDl, czechowiceDziedziceDl);
    }
}