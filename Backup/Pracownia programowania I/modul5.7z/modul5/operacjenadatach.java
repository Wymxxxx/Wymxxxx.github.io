import java.util.*;

class Data
{
	private int dzien;
	private int miesiac;
	private int rok;
	
	public Data(int rok, int miesiac, int dzien)
	{
		this.dzien = dzien;
		this.miesiac = miesiac;
		this.rok = rok;
	}	
	
	public static int obliczDniPomiedzy(Data a, Data b)
	{
		int ilosc;
		Calendar data1 = new GregorianCalendar(a.rok, a.miesiac-1, a.dzien);
		Calendar data2 = new GregorianCalendar(b.rok, b.miesiac-1, b.dzien);
		ilosc = (int) (Math.abs((data1.getTimeInMillis()/1000 - data2.getTimeInMillis()/1000)/86400));
		return ilosc;
	}
	public static String podajDzienTygodnia(Data a)
	{
		Calendar data = new GregorianCalendar(a.rok, a.miesiac-1, a.dzien);
		int dzienTygodnia = data.get(Calendar.DAY_OF_WEEK);
		String[] dniTygodnia = {"Niedziela","Poniedzia�ek","Wtorek","�roda","Czwartek","Pi�tek","Sobota"};
		return dniTygodnia[dzienTygodnia-1];
	}
	public static String podajZnakZodiaku(Data a)
	{
        String znak = null;
        if (a.miesiac == 1 && a.dzien >=20 || a.miesiac == 2 && a.dzien <=18) znak = "Wodnik";
        if (a.miesiac == 2 && a.dzien >=19 || a.miesiac == 3 && a.dzien <=20) znak = "Ryby";
        if (a.miesiac == 3 && a.dzien >=21 || a.miesiac == 4 && a.dzien <=19) znak = "Baran";
        if (a.miesiac == 4 && a.dzien >=20 || a.miesiac == 5 && a.dzien <=20) znak = "Byk";
        if (a.miesiac == 5 && a.dzien >=21 || a.miesiac == 6 && a.dzien <=21) znak = "Bli�ni�ta";
        if (a.miesiac == 6 && a.dzien >=22 || a.miesiac == 7 && a.dzien <=22) znak = "Rak";
        if (a.miesiac == 7 && a.dzien >=23 || a.miesiac == 8 && a.dzien <=22) znak = "Lew";
        if (a.miesiac == 8 && a.dzien >=23 || a.miesiac == 9 && a.dzien <=22) znak = "Panna";
        if (a.miesiac == 9 && a.dzien >=23 || a.miesiac == 10 && a.dzien <=22) znak = "Waga";
        if (a.miesiac == 10 && a.dzien >=23 || a.miesiac == 11 && a.dzien <=21) znak = "Skorpion";
        if (a.miesiac == 11 && a.dzien >=22 || a.miesiac == 12 && a.dzien <=21) znak = "Strzelec";
        if (a.miesiac == 12 && a.dzien >=22 || a.miesiac == 1 && a.dzien <=19) znak = "Kozioro�ec";
        return znak;
    } 
}

public class OperacjeNaDatach 
{
    public static void main(String[] args) 
    {
    	Data data1 = new Data(2008,4,14);
    	Data data2 = new Data(1988,7,25);
    	Data data3 = new Data(2008,6,14);
    	System.out.println("Mi�dzy 14.4.2008 a 25.7.1988 jest " + Data.obliczDniPomiedzy(data1,data2) + " dni");
        System.out.println("14.4.2008 by� " + Data.podajDzienTygodnia(data1));
        System.out.println("25.7.1988 by� " + Data.podajDzienTygodnia(data2));
        System.out.println("25.7.1988 odpowiada znak zodiaku: " + Data.podajZnakZodiaku(data2));
        System.out.println("Dni do rozpocz�cia sesji = " + Data.obliczDniPomiedzy(data1,data3));
    }
}
