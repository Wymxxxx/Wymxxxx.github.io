class Stoper
{
	private long start;
	private long stop;
	private String nazwa;
	private long czasPosredni;
	
	public Stoper()
	{
		nazwa = "";
	}
	public Stoper(String nazwa)
	{
		this.nazwa = nazwa;
	}
	
	public void start()
	{
		start = System.currentTimeMillis();
	}
	public void stop()
	{
		stop = System.currentTimeMillis();
	}
	public double pobierzWynik()
	{
		return (stop-start)/1000.0;
	}
	public void czasPosredni()
	{
		czasPosredni = System.currentTimeMillis();
	}
	public double pobierzCzasPosredni()
	{
		return (czasPosredni-start)/1000.0;
	}
}

public class PomiarCzasowPosrednich
{
    public static void main(String[] args) 
    {
    	Stoper nowyStoper = new Stoper();
        
        nowyStoper.start();
        int[] liczbyPierwsze = new int[1000];
        int i=0;
        int liczba=2;
        int j;
        boolean poprawnoscLiczby = true;
                
        while(i<1000)
        {
        	for(j=2; j<=liczba/2; j++)
        	{
        		if(liczba%j==0)
        		{
        			poprawnoscLiczby = false;
        			break;
        		}
        	}
        	if(poprawnoscLiczby)
        	{
        		liczbyPierwsze[i] = liczba;
        		System.out.println(liczba);
        		if(i==249 || i==499 || i==749)
        		{
        		nowyStoper.czasPosredni();
        		System.out.println("Czas posredni po: " +(i+1)+ " liczbach, wynosi: " + nowyStoper.pobierzCzasPosredni());
        		}
        		i++;
        	}
        	liczba++;
        	poprawnoscLiczby = true;
        	
        }
        
        nowyStoper.stop();
        System.out.println("Czas ko�cowy: " + nowyStoper.pobierzWynik() + " sekundy");
        
        
        
        int k,l;
    	Stoper nowyStoper2 = new Stoper();
    	nowyStoper2.start();
    	
    	boolean[] tablica = new boolean[7921];
   
    	for (k=0; k<=7920; k++) tablica[k] = true;
    	for (k=2; k<=7920; k++) 
    	{
            for (l=2; l<=(7920/k); l++) tablica [k*l] = false;
    	}
    	System.out.println("Kolejne liczby pierwsze:");
    	for (k=2; k<=7920; k++) 
    	{
        	if (tablica[k]) 
        	{
            	System.out.println(k);        
    		}
    	}
    	nowyStoper2.stop();
    	System.out.println("Czas wynosi: " + nowyStoper2.pobierzWynik() + " sekund");
    }
}
