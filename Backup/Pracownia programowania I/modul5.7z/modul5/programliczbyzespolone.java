class LiczbyZespolone
{
	double czescRzeczywista;
	double czescUrojona;
	
	public LiczbyZespolone()
	{
		this.czescRzeczywista = 0;
		this.czescUrojona = 0;
	}
	public LiczbyZespolone(double czescRzeczywista, double czescUrojona)
	{
		this.czescRzeczywista = czescRzeczywista;
		this.czescUrojona = czescUrojona;
	}
	
	public static LiczbyZespolone dodajLiczbyZespolone(LiczbyZespolone liczba1, LiczbyZespolone liczba2)
	{
		LiczbyZespolone wynik = new LiczbyZespolone();
		wynik.czescRzeczywista = liczba1.czescRzeczywista+liczba2.czescRzeczywista;
		wynik.czescUrojona = liczba1.czescUrojona+liczba2.czescUrojona;
		return wynik;
	}
	public static LiczbyZespolone odejmijLiczbyZespolone(LiczbyZespolone liczba1, LiczbyZespolone liczba2)
	{
		LiczbyZespolone wynik = new LiczbyZespolone();
		wynik.czescRzeczywista = liczba1.czescRzeczywista-liczba2.czescRzeczywista;
		wynik.czescUrojona = liczba1.czescUrojona-liczba2.czescUrojona;
		return wynik;
	}
	public static LiczbyZespolone pomnozLiczbyZespolone(LiczbyZespolone liczba1, LiczbyZespolone liczba2)
	{
		LiczbyZespolone wynik = new LiczbyZespolone();
		wynik.czescRzeczywista = (liczba1.czescRzeczywista*liczba2.czescRzeczywista)-(liczba1.czescUrojona*liczba2.czescUrojona);
		wynik.czescUrojona = (liczba1.czescUrojona*liczba2.czescRzeczywista)+(liczba1.czescRzeczywista*liczba2.czescUrojona);
		return wynik;
	}
	public static void podajWartoscBezwzgledna(LiczbyZespolone liczba)
	{
        double wynik = Math.pow((liczba.czescRzeczywista*liczba.czescRzeczywista)+(liczba.czescUrojona*liczba.czescUrojona),0.5);
        System.out.println("Warto�c bezwzgl�dna liczby zespolonej : " +liczba+" wynosi " + wynik);
    } 
	public static double zwrocCzescRzeczywista(LiczbyZespolone liczba)
	{
		return liczba.czescRzeczywista;
	}
	public static double zwrocCzescUrojona(LiczbyZespolone liczba)
	{
		return liczba.czescUrojona;
	}
	public static void wyswietlLiczbeZespolona(LiczbyZespolone liczba)
	{
		System.out.println(liczba.czescRzeczywista+"+"+liczba.czescUrojona+"i");
	}
	public String toString()
	{
        return this.czescRzeczywista+"+"+this.czescUrojona+"i";
    } 
}

public class ProgramLiczbyZespolone 
{
    public static void main(String[] args) 
    {
        LiczbyZespolone liczba1 = new LiczbyZespolone(5,3);
        LiczbyZespolone liczba2 = new LiczbyZespolone(2,3);
        System.out.println("Suma = " + LiczbyZespolone.dodajLiczbyZespolone(liczba1, liczba2));
        System.out.println("R�nica = " + LiczbyZespolone.odejmijLiczbyZespolone(liczba1, liczba2));
        System.out.println("Iloczyn = " + LiczbyZespolone.pomnozLiczbyZespolone(liczba1, liczba2));
        System.out.println("Cz�� rzeczywista liczby1 to "+LiczbyZespolone.zwrocCzescRzeczywista(liczba1));
        System.out.println("Cz�� urojona liczby1 to "+LiczbyZespolone.zwrocCzescUrojona(liczba1));
        LiczbyZespolone.podajWartoscBezwzgledna(liczba1);
    }
}
