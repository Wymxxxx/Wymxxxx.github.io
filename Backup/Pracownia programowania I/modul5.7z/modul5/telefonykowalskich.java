class Telefon
{
	private String numerTelefonu;
	private int lacznyCzasRozmow;
	private static double cenaRozmowy = 0.48;
	
	public Telefon (String numer)
	{
		numerTelefonu = numer;
	}
	double obliczKwoteDoZaplaty()
	{
		return cenaRozmowy*(lacznyCzasRozmow/60);
	}
	static void ustawCeneRozmowy(double nowaCena)
	{
		cenaRozmowy = nowaCena;
	}
	void zadzwon(String nrTelefonu)
	{
		System.out.println ("Dzwoni� do: " + nrTelefonu);
		System.out.println("Dry�, dryn...");
		System.out.println("Rozmowa w toku...");
		int czasRozmowy = (int) (Math.random()*3600);
		lacznyCzasRozmow += czasRozmowy;
		System.out.println("Rozmowa zako�czona. ");
		System.out.printf("Czas rozmowy: %d min. %d sek. \n", czasRozmowy/60, czasRozmowy%60);
	}
}
public class TelefonyKowalskich 
{
    public static void main(String[] args) 
    {
        Telefon telefonAni = new Telefon("123456789");
        Telefon telefonJarka = new Telefon("987654321");
        
        telefonAni.zadzwon("012345678");
        telefonJarka.zadzwon("112");
        
        double kwota = telefonAni.obliczKwoteDoZaplaty();
        System.out.printf("Ania ma do zap�aty " + kwota +" z�.");
    }
}
