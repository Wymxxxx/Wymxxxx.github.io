import java.util.*;

class Licznik
{
	private int ilosc = 0;
	public int wyswietlLicznik()
	{
		return ilosc;
	}
	public void zmodyfikujLicznik()
	{
		ilosc++;
	}
}

public class ProgramLicznik 
{
    public static void main(String[] args) 
    {
    	Licznik nowyLicznik = new Licznik();
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj jakie� zdanie: ");
        String zdanie = wprowadzono.nextLine();
        String znak;
        for(int i=0; i<zdanie.length(); i++)
        {
        	znak = zdanie.substring(i,i+1);
        	if(znak.equals(" ")) nowyLicznik.zmodyfikujLicznik();
        }
        System.out.println("W podanym przez Ciebie zdaniu s� " + nowyLicznik.wyswietlLicznik() + " spacje");
    }
}
