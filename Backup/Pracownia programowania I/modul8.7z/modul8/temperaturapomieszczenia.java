public class TemperaturaPomieszczenia 
{
	private final double TEMP_MAX = 25.0;
	private final double TEMP_MIN = 15.0;
	private double temperatura;
	
	public static void main(String[] args) 
	{
		TemperaturaPomieszczenia kuchnia = new TemperaturaPomieszczenia();
		System.out.println("ELEKTRONICZNY REGULATOR TEMPERATURY");
		try
		{
			double temp1 = 19.6;
			kuchnia.ustawTemperature(temp1);
			System.out.println(kuchnia.pobierzTemperature());
		}
		catch (TemperaturaException e)
		{
			System.out.println("Temperatura poza dopuszczalnym zakresem");
		}
		
		try
		{
			double temp2 = 17.2;
			kuchnia.ustawTemperature(temp2);
			System.out.println(kuchnia.pobierzTemperature());
		}
		catch (TemperaturaException e)
		{
			System.out.println("Temperatura poza dopuszczalnym zakresem");
		}
		
		try
		{
			double temp3 = 27.4;
			kuchnia.ustawTemperature(temp3);
			System.out.println(kuchnia.pobierzTemperature());
		}
		catch (TemperaturaException e)
		{
			System.out.println("Temperatura poza dopuszczalnym zakresem");
		}
		
	}
	
	public void ustawTemperature(double temp) throws TemperaturaException 
	{
		if ((temp < TEMP_MIN) || (temp > TEMP_MAX))
		{
			throw new TemperaturaException();
		} 
		else 
		{
			temperatura = temp;
		}
	}
	
	public double pobierzTemperature()
	{
		return temperatura;
	}
}

class TemperaturaException extends Exception 
{
	public TemperaturaException()
	{
		super("Temperatura poza dopuszczalnym zakresem.");
	}
	public TemperaturaException(String komunikat)
	{
		super(komunikat);
	}
}