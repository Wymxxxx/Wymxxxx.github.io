import java.util.*;
public class PierwiastekKwadratowy 
{
	public static double pierwiastekKwadratowy(double a)
	{
		if(a<0)
		{
			throw new IllegalArgumentException("Brak pierwiastk�w dla liczb ujemnych.");
		}
		else
		{
			return Math.sqrt(a);
		}
	}
	
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj liczb� kt�rej pierwiastek chcesz obliczy�: ");
        double liczba = 0;
        
        try
        {
        	liczba = wprowadzono.nextDouble();
        }
        catch (InputMismatchException e)
		{
			System.out.println("Wprowadzona warto�� \"" + wprowadzono.nextLine() + "\" jest niepoprawna!!!");
		}
		
		double pierwiastek = pierwiastekKwadratowy(liczba);
		System.out.println("Pierwiastek kwadratowy liczby: " + liczba + " wynosi: " + pierwiastek);
    }
}
