import java.util.*;
public class WielkoscWynagrodzenia 
{
    public static void main(String[] args) 
    {
        int godziny;
        double stawka;
        double wynagrodzenie = 0;
        Scanner wprowadzono = new Scanner(System.in);
        do 
		{
			try 
			{
				System.out.print("Ilo�� przepracowanych godzin: ");
				godziny = wprowadzono.nextInt();
				System.out.print("Stawka za godzin�: ");
				stawka = wprowadzono.nextDouble();
				wynagrodzenie = (double)godziny*stawka;
				if(stawka==0) System.out.println("Stawka nie mo�e wynosi� 0z�!!");
			}
			catch (InputMismatchException e)
			{
				System.out.println("Nie poprawnie wprowadzi�e� liczb�: "+ wprowadzono.nextLine() + " !!!");
			}
		} 
		while(wynagrodzenie==0);
		System.out.println("Wynagrodzenie wynosi: " + wynagrodzenie + " z�.");
    }
}
