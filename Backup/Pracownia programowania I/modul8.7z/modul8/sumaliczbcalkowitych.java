import java.util.*;

public class SumaLiczbCalkowitych 
{
	public static void main(String[] args) 
	{
		int sumaLiczb = 0;
		int liczbaCalkowita = 0;
		System.out.println("Wprowad� liczby ca�kowite.");
		System.out.println("Warto�� 0 ko�czy wprowadzanie.\n");
		Scanner wprowadzono = new Scanner(System.in);
		do 
		{
			try 
			{
				System.out.print("Liczba ca�kowita: ");
				liczbaCalkowita = wprowadzono.nextInt();
				sumaLiczb += liczbaCalkowita;
			}
			catch (InputMismatchException e)
			{
				System.out.println("Wprowadzona warto�� \"" + wprowadzono.nextLine() + "\" jest niepoprawna!!!");
			}
		} 
		while (liczbaCalkowita!=0);
		System.out.println("Suma wprowadzonych warto�ci: " + sumaLiczb);
	}
}
