import java.util.*;
public class SredniaPredkoscRoweru 
{
	public static double sredniaPredkoscRoweru(double s, double t)
	{
		if (s<0)
		{
			throw new IllegalArgumentException("�le podany dystans!");
		}
		else if (t<0)
		{
			throw new IllegalArgumentException("�le podany czas!");
		}
		else
		{
			double czas = t/60;
			double v = s*czas;
			return v;
		}
	}
	
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj przejechany dystans (w kilometrach): ");
        double s = wprowadzono.nextDouble();
        System.out.println("Podaj czas jazdy (w minutach) odliczaj�c postoje: ");
        double t = wprowadzono.nextDouble();
        
        System.out.println("�rednia pr�dko��: " + sredniaPredkoscRoweru(s,t) + " km/h");
    }
}
