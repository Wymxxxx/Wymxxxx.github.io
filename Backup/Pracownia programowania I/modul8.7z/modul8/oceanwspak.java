public class OceanWspak 
{
	public static void main(String[] args) 
	{
		String ocean = "Ocean Indyjski";
		try 
		{
			for(int i=ocean.length(); i>=0; i--)
			System.out.print(ocean.charAt(i));
		}
		catch(IndexOutOfBoundsException e)
		{
			System.out.println("Program zosta� wykonany nieprawid�owo!");
		}
	}
}
