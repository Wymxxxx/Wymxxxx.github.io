import java.util.*;

public class DzieleniePrzezZero 
{
	public static void main(String[] args) 
	{
		double wynik = 0.00000000000000000000000001;
		int dzielna;
		int dzielnik;
		System.out.println("Wprowad� liczby ca�kowite kt�re chcesz podzieli�.");
		Scanner wprowadzono = new Scanner(System.in);
		do 
		{
			try 
			{
				System.out.print("Dzielna: ");
				dzielna = wprowadzono.nextInt();
				System.out.print("Dzielnik: ");
				dzielnik = wprowadzono.nextInt();
				wynik = (double)dzielna/(double)dzielnik;
				if (dzielnik==0) 
				{
					System.out.println("Nie wolno dzieli� przez zero!!!");
					wynik = 0.00000000000000000000000001;
				}
			}
			catch (InputMismatchException e)
			{
				System.out.println("Nie poprawnie wprowadzi�e� liczb�: "+ wprowadzono.nextLine() + " !!!");
			}
		} 
		while (wynik==0.00000000000000000000000001);
		System.out.println("Iloraz wprowadzonych warto�ci: " + wynik);
	}
}
