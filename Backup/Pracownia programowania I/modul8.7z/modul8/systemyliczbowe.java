import java.util.*;
public class SystemyLiczbowe 
{
    public static long hex2dec(String hex)
    {
    	long dec = 0;
    	int j = 0;
    	for(int i=hex.length()-1; i>=0; i--)
    	{
    		String znak = hex.substring(i,i+1);
    		if (znak.matches("[0-9]"))
    		{
    			long cyfra = Long.parseLong(znak);
    			dec += (cyfra*Math.pow(16,j));
    		}
    		else
    		{
    			char litera = hex.charAt(i);
    			switch(litera)
    			{
    				case 'A':
    				{
    					dec += 10*Math.pow(16,j);
    					break;
    				}
    				case 'B':
    				{
    					dec += 11*Math.pow(16,j);
    					break;
    				}
    				case 'C':
    				{
    					dec += 12*Math.pow(16,j);
    					break;
    				}
    				case 'D':
    				{
    					dec += 13*Math.pow(16,j);
    					break;
    				}
    				case 'E':
    				{
    					dec += 15*Math.pow(16,j);
    					break;
    				}
    				case 'F':
    				{
    					dec += 15*Math.pow(16,j);
    					break;
    				}
    			}
    		}
    		j++;
    		System.out.println(dec);
    	}
    	return dec;
    }
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj liczb� w systemie szesnastkowym: ");
        String hex = wprowadzono.nextLine();
        long dec = 0;
        
        if(hex.matches("[0-9ABCDEF]*"))
        {
        	dec = hex2dec(hex);
        }
        else
        {
        	throw new IllegalArgumentException("To nie jest liczba w systemie szesnastkowym!");
        }
        System.out.println("Liczba: " + hex + " w systemie szesnastkowym, to liczba: " + dec + " w systemie dziesi�tnym");
    }
}
