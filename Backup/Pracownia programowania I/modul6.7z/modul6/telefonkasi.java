import telefonia.TelefonKomorkowy;
public class TelefonKasi 
{
	public static void main(String args[]) 
	{
		TelefonKomorkowy telefonKasi = new TelefonKomorkowy("503984532","Plus");
		telefonKasi.wyslijSMS("602875295","Zadanie z pakietem wykonane");
	}
}
