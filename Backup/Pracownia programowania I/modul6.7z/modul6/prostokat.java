public class Prostokat extends Figura 
{
	private Punkt punktA,punktB,punktC,punktD;
	
	public Prostokat(Punkt punktA, Punkt punktB, Punkt punktC, Punkt punktD)
	{
		this.punktA = punktA;
		this.punktB = punktB;
		this.punktC = punktC;
		this.punktD = punktD;
	}
	private double obliczOdleglosc(Punkt X, Punkt Y)
	{
		int xpunktA = X.pobierzX();
		int ypunktA = X.pobierzY();
		int xpunktB = Y.pobierzX();
		int ypunktB = Y.pobierzY();
		return Math.sqrt( (xpunktA-xpunktB)*(xpunktA-xpunktB) +	(ypunktA-ypunktB)*(ypunktA-ypunktB) );
	}
	public double obliczPole()
	{
		double a = obliczOdleglosc(punktA,punktB);
		double b = obliczOdleglosc(punktA,punktD);
		return a*b;
	}
	public double obliczObwod()
	{
		double a = obliczOdleglosc(punktA,punktB);
		double b = obliczOdleglosc(punktA,punktD);
		return 2*a + 2*b;
	}
	public void przesun(int x, int y)
	{
		punktA.przesun(x,y);
		punktB.przesun(x,y);
		punktC.przesun(x,y);
		punktD.przesun(x,y);
	}
	public String toString()
	{
		return String.format("Prostok�t: A%s, B%s, C%s, D%s ",punktA,punktB,punktC,punktD) +
							String.format("pole=%f, obw�d=%f",obliczPole(),obliczObwod());
	}
}
