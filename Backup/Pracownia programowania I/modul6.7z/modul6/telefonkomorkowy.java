package telefonia;
public class TelefonKomorkowy extends Telefon 
{
	public String operator;
	
	public TelefonKomorkowy(String numer, String operator) 
	{
		super(numer);
		this.operator = operator;
	}

	public void wyslijSMS(String nrTelefonu, String tresc) 
	{
		System.out.println("Wysylam SMS�a o tresci: " + tresc);
		System.out.println("Pod numer: " + nrTelefonu);
	}
	public void zadzwon(String nrTelefonu) 
	{
		System.out.println("Dzwonie z kom�rki do: " + nrTelefonu);
	}
}
