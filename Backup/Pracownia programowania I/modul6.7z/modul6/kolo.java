public class Kolo extends Figura
{
	private Punkt punktA;
	private int r;
	
	public Kolo(Punkt punktA, int r)
	{
		this.punktA = punktA;
		this.r = r;
	}
	
	public double obliczPole()
	{
		return Math.PI * r * r;
	}
	public double obliczObwod()
	{
		return 2 * Math.PI * r;
	}
	public void przesun(int dx, int dy)
	{
		punktA.przesun(dx,dy);
	}
	public String toString()
	{
		return String.format("Ko�o: A%s, r=%d, pole=%f, obw�d=%f",punktA,r,obliczPole(),obliczObwod());
	}
}