import java.util.*;
class Zwierze
{
	public String imie;
	public int wiek;
	public String gatunek;
	
	public Zwierze()
	{
		this.imie = "Brak";
		this.wiek = 0;
		this.gatunek = "Zwierz�";
	}
	public Zwierze(String imie, int wiek, String gatunek)
	{
		this.imie = imie;
		this.wiek = wiek;
		this.gatunek = gatunek;
	}
	
	public void pobierzInfo()
	{
		System.out.println(this.gatunek + " " + this.imie + " wiek: " + this.wiek + " miesi�cy");
	}
}
class Panda extends Zwierze
{
	public Panda(String imie, int wiek)
	{
		this.imie = imie;
		this.wiek = wiek;
		this.gatunek = "Panda";
	}
}
class Malpa extends Zwierze
{
	public Malpa(String imie, int wiek)
	{
		this.imie = imie;
		this.wiek = wiek;
		this.gatunek = "Malpa";
	}
}
class Kucyk extends Zwierze
{
	public Kucyk(String imie, int wiek)
	{
		this.imie = imie;
		this.wiek = wiek;
		this.gatunek = "Kucyk";
	}
}
class Zoo
{
	public Zwierze[] zwierzeta;
	private int stanZoo;
	
	public Zoo(int iloscZwierzat)
	{
		zwierzeta = new Zwierze[iloscZwierzat];
		stanZoo = zwierzeta.length;
	}
	
	public void pobierzStanZoo()
	{
		System.out.println("Stan zoo to: " + stanZoo + " zwierz�t:");
		for(int i=0; i<zwierzeta.length; i++)
		{
			zwierzeta[i].pobierzInfo();
		}
	}
	public void dodajZwierze(String gatunek, String imie, int wiek)
	{
		Zwierze[] pomocnicza = zwierzeta.clone();
		zwierzeta = new Zwierze[pomocnicza.length+1];
		for(int i=0; i<pomocnicza.length; i++)
		{
			zwierzeta[i] = pomocnicza[i];
		}
		if(gatunek.equals("Panda")) zwierzeta[zwierzeta.length-1] = new Panda(imie,wiek);
		else if (gatunek.equals("Malpa")) zwierzeta[zwierzeta.length-1] = new Malpa(imie,wiek);
		else if (gatunek.equals("Kucyk")) zwierzeta[zwierzeta.length-1] = new Kucyk(imie,wiek);
		stanZoo++;
		
		System.out.println("Mamy nowego mieszka�ca:");
		zwierzeta[zwierzeta.length-1].pobierzInfo();
	}
	public void nakarmZwierze(String imie)
	{
		if(imie.equalsIgnoreCase("Wszystkie"))
		{
			for(Zwierze zwierzak:zwierzeta)
			{	
				System.out.println(zwierzak.imie + " jest karmiony/na \nMmm ale by�o pycha");
			}
		}
		else 
		{		
			for(Zwierze zwierzak:zwierzeta)
			{
				if((zwierzak.imie).equals(imie)) System.out.println(zwierzak.imie + " jest karmiony/na \nMmm ale by�o pycha");
			}
		}
	}

}

public class MiniZoo 
{
    public static void main(String[] args) 
    {
        Zoo miniZoo = new Zoo(8);
        miniZoo.zwierzeta[0] = new Panda("Teo",36);
        miniZoo.zwierzeta[1] = new Panda("Piki",5);
        miniZoo.zwierzeta[2] = new Panda("Miki",5);
        miniZoo.zwierzeta[3] = new Malpa("Romi", 48);
        miniZoo.zwierzeta[4] = new Malpa("Tysia",48);
        miniZoo.zwierzeta[5] = new Kucyk("Gatek",24);
        miniZoo.zwierzeta[6] = new Kucyk("Kajtek",36);
        miniZoo.zwierzeta[7] = new Kucyk("Taksel",60);
        
        miniZoo.pobierzStanZoo();
        
        miniZoo.dodajZwierze("Malpa","Iga",0);
        
        miniZoo.pobierzStanZoo();
        miniZoo.nakarmZwierze("wszystkie");
    }
}
