import telefonia.Telefon;
import telefonia.TelefonKomorkowy;
import telefonia.TelefonStacjonarny;
import telefonia.TelefonInternetowy;
public class Test 
{
	public static void main(String args[]) 
	{
		Telefon telefonJasia = new Telefon("867312632");
		Telefon komorkaMarka = new TelefonKomorkowy("606345956", "Era");
		Telefon stacjonarnyKasi = new TelefonStacjonarny("125439876", "1044");
		Telefon InternetowyAni = new TelefonInternetowy("146743253", "Anula7");
	}
}