public class Punkt 
{
	private int x,y;
	
	public Punkt(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	
	public int pobierzX()
	{
		return x;
	}
	public int pobierzY()
	{
		return y;
	}
	public void ustawX(int x)
	{
		this.x = x;
	}
	public void ustawY(int y)
	{
		this.y = y;
	}
	public void przesun(int x, int y)
	{
		this.x += x;
		this.y += y;
	}
	public String toString()
	{
		return String.format("(%d,%d)",x,y);
	}
}
