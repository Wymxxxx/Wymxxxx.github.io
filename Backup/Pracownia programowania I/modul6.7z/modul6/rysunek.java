public class Rysunek 
{
	int liczbaFigur = 0;
	Figura[] figury;
	
	public Rysunek(int maxLiczbaFigur)
	{
		figury = new Figura[maxLiczbaFigur];
	}
	public void dodajFigure(Figura nowaFigura)
	{
		figury[liczbaFigur++] = nowaFigura;
	}
	public void przesun(int x, int y)
	{
		for(int i=0; i<liczbaFigur; i++)
		figury[i].przesun(x,y);
	}
	public String toString()
	{
		String s = "";
		for(int i=0; i<liczbaFigur; i++)
		{
			s += figury[i] + "\n";
		}
		return s;
	}
	
	public static void main(String[] args) 
	{
		Rysunek rysunek = new Rysunek(8);
		rysunek.dodajFigure(new Kolo(new Punkt(2,5),7));
		rysunek.dodajFigure(new Prostokat(new Punkt(5,2), new Punkt(5,4), new Punkt(1,4), new Punkt(1,2) ));
		rysunek.dodajFigure(new Kolo(new Punkt(4,1),3));
		rysunek.dodajFigure(new Kolo(new Punkt(8,9),1));
		rysunek.dodajFigure(new Prostokat(new Punkt(3,0), new Punkt(4,0), new Punkt(4,8), new Punkt(3,8) ));
		rysunek.dodajFigure(new Trojkat(new Punkt(0,0), new Punkt(0,4), new Punkt(3,0)));
		rysunek.dodajFigure(new Romb(new Punkt(0,0), new Punkt(4,0), new Punkt(4,4), new Punkt(0,4)));
		rysunek.dodajFigure(new Trapez(new Punkt(0,0), new Punkt(6,0), new Punkt(5,3), new Punkt(2,3)));
		System.out.println(rysunek);
		System.out.println("Przesuni�cie figur...");
		rysunek.przesun(3,-1);
		System.out.println(rysunek);
	}
}

