public class Romb extends Figura
{
	private Punkt punktA,punktB,punktC,punktD;
	
	public Romb(Punkt punktA, Punkt punktB, Punkt punktC, Punkt punktD)
	{
		this.punktA = punktA;
		this.punktB = punktB;
		this.punktC = punktC;
		this.punktD = punktD;
	}
	private double obliczOdleglosc(Punkt X, Punkt Y)
	{
		int xpunktA = X.pobierzX();
		int ypunktA = X.pobierzY();
		int xpunktB = Y.pobierzX();
		int ypunktB = Y.pobierzY();
		return Math.sqrt( (xpunktA-xpunktB)*(xpunktA-xpunktB) +	(ypunktA-ypunktB)*(ypunktA-ypunktB) );
	}
	public double obliczPole()
	{
		double e = obliczOdleglosc(punktA,punktC);
		double f = obliczOdleglosc(punktD,punktB);
		return (e*f)/2;
	}
	public double obliczObwod()
	{
		double a = obliczOdleglosc(punktA,punktB);
		return 4*a;
	}
	public void przesun(int x, int y)
	{
		punktA.przesun(x,y);
		punktB.przesun(x,y);
		punktC.przesun(x,y);
		punktD.przesun(x,y);
	}
	public String toString()
	{
		return String.format("Romb: A%s, B%s, C%s, D%s ",punktA,punktB,punktC,punktD) +
							String.format("pole=%f, obw�d=%f",obliczPole(),obliczObwod());
	}
}
