class Student
{
	private String imie;
	private String nazwisko;
	private int nrAlbumu;
	
	public Student(String imie, String nazwisko, int nrAlbumu)
	{
		this.imie = imie;
		this.nazwisko = nazwisko;
		this.nrAlbumu = nrAlbumu;
	}
	
	public void equals(Student student2)
	{
		if(nrAlbumu==student2.nrAlbumu) System.out.println("To ten sam student");
		else System.out.println("To dwaj r�ni studenci");
	}
	public String toString()
	{
		return String.format("Imi�: %s \nNazwisko: %s \nNumer Albumu: %d", imie,nazwisko,nrAlbumu);
	}
}
public class PorownanieObiektow 
{
    public static void main(String[] args) 
    {
        Student student1 = new Student("Marian","Zdzis�awski",1110);
        Student student2 = new Student("Zdzis�aw","Henrykowski",9999);
        Student student3 = new Student("Marian","Kupka",1110);
        
        System.out.println(student1);
        student1.equals(student3);
    }
}
