package telefonia;
public class TelefonStacjonarny extends Telefon 
{
	public String prefiks;
	
	public TelefonStacjonarny (String numer, String prefiks) 
	{
		super(numer);
		this.prefiks = prefiks;
	}
	
	public void zadzwon(String nrTelefonu) 
	{
		System.out.println ("Dzwonie ze stacjonarnego do: " + nrTelefonu);
	}
}