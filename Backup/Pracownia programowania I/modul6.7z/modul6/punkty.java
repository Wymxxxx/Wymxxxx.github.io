public class Punkty 
{
	public static void main(String[] args) 
	{
		Punkt punktA = new Punkt(3,7);
		Punkt punktB = new Punkt(2,11);
		Punkt punktC = new Punkt(6,5);
		
		System.out.print("Wsp�rz�dne punkt�w: ");
		System.out.printf("%s %s %s\n",punktA,punktB,punktC);
		
		System.out.println("Zmiana po�o�enia punkt�w...");
		punktA.przesun(2,-1);
		punktB.przesun(2,-1);
		punktC.przesun(2,-1);
		System.out.print("Wsp�rz�dne punkt�w: ");
		System.out.printf("%s %s %s\n",punktA,punktB,punktC);
	}
}