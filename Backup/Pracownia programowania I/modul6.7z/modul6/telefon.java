package telefonia;
public class Telefon 
{
	public String numer;
	
    public Telefon(String numer) 
    {
    	this.numer = numer;
    }
    
	public void zadzwon(String nrTelefonu) 
	{
		System.out.println("Dzwonie do: " + nrTelefonu);
	}
}
