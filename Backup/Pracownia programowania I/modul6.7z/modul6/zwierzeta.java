public class Zwierzeta 
{
	public static void main(String[] args) 
	{
		Zwierze[] zwierzeta = new Zwierze[3];
		zwierzeta[0] = new Pies();
		zwierzeta[1] = new Kot();
		zwierzeta[2] = new Krowa();
		System.out.println("Rykowisko...");
		for(Zwierze zwierze: zwierzeta)
		{
			zwierze.dajGlos();
		}
	}
}
class Zwierze 
{
	private String nazwa;
	public void dajGlos()
	{
		System.out.println("G�os zwierz�cia");
	}
}
class Pies extends Zwierze 
{
	public void dajGlos()
	{
	System.out.println("hau hau");
	}
}
class Kot extends Zwierze 
{
	public void dajGlos()
	{
		System.out.println("miau miau");
	}
}
class Krowa extends Zwierze 
{
	public void dajGlos()
	{
		System.out.println("muuuuu");
	}
}
