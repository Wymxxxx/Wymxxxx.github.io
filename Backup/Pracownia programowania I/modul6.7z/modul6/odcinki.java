public class Odcinki 
{
	public static void main(String[] args) 
	{
		Odcinek odcinek = new Odcinek( new Punkt(2,3), new Punkt(7,4) );
		System.out.println(odcinek);
		System.out.println("Zmiana po�o�enia odcinka...");
		odcinek.przesun(-1,4);
		System.out.println(odcinek);
	}
}

class Odcinek 
{
	private Punkt punktA,punktB; 
		
	public Odcinek(Punkt ppunktA, Punkt ppunktB)
	{
		punktA = ppunktA;
		punktB = ppunktB;
	}
	
	public double dlugosc()
	{
		int xpunktA = punktA.pobierzX();
		int ypunktA = punktA.pobierzY();
		int xpunktB = punktB.pobierzX();
		int ypunktB = punktB.pobierzY();
		return Math.sqrt( (xpunktA-xpunktB)*(xpunktA-xpunktB) +	(ypunktA-ypunktB)*(ypunktA-ypunktB) );
	}
	public void przesun(int dx, int dy)
	{
		punktA.przesun(dx,dy);
		punktB.przesun(dx,dy);
	}
	public String toString()
	{
		String opis;
		opis = String.format("Odcinek: A%s,B%s,", punktA,punktB);
		opis += String.format(" d�ugo�� %3.1f", dlugosc());
		return opis;
	}
}