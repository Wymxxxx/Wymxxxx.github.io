import java.util.*;
class Produkt
{
	String nazwa;
	double cenaNettoSztuka;
	double cenaNettoSuma;
	double stopaVAT;
	double ilosc;
	double cenaBruttoSztuka;
	double cenaBruttoSuma;
	String jednostka;
	
	public Produkt(String nazwa, double cenaNetto, double ilosc, double stopaVAT)
	{
		this.nazwa = nazwa;
		this.cenaNettoSztuka = cenaNetto;
		this.ilosc = ilosc;
		this.stopaVAT = stopaVAT;
		this.cenaNettoSuma = cenaNetto*ilosc;
		wyliczCeneBrutto();
		this.cenaBruttoSuma = this.cenaBruttoSztuka*ilosc;
	}
	
	public void wyliczCeneBrutto()
	{
		this.cenaBruttoSztuka = this.cenaNettoSztuka+(this.cenaNettoSztuka*this.stopaVAT);
	}
	
	public String toString()
	{
		return String.format("%-22s|%7s|%6.2f|%7.2f|%12.2f|%8.2f|%12.2f|",this.nazwa,this.jednostka,this.cenaNettoSztuka,this.ilosc,
															this.cenaNettoSuma,this.stopaVAT,this.cenaBruttoSuma);
	}
}
class Towar extends Produkt
{
	public Towar(String nazwa, String jednostka, double cenaNetto, double ilosc, double stopaVAT)
	{
		super(nazwa, cenaNetto, ilosc, stopaVAT);
		this.jednostka = jednostka;
	}
}
class Usluga extends Produkt
{
	public Usluga(String nazwa, double cenaNetto, double ilosc, double stopaVAT)
	{
		super(nazwa, cenaNetto, ilosc, stopaVAT);
		this.jednostka = "godz.";
	}
}

class FakturaVat
{
	private Produkt[] produkty;
	private int numer;
	private String data;
	private String nabywca;
	private double suma;
	private int i=0;
	
	public FakturaVat(String data, int iloscProduktow)
	{
		produkty = new Produkt[iloscProduktow];
		this.data = data;
		Random generator = new Random();
		numer = generator.nextInt(10000);
	}
	
	public void dodajProdukt(String rodzaj, String nazwa, String jednostka, double cenaNetto, double ilosc, double stopaVat)
	{
		if(rodzaj.equalsIgnoreCase("Us�uga"))
		{
			produkty[i] = new Usluga(nazwa, cenaNetto, ilosc, stopaVat);
		}
		else if(rodzaj.equalsIgnoreCase("Towar"))
		{
			produkty[i] = new Towar(nazwa, jednostka, cenaNetto, ilosc, stopaVat);
		}
		suma += produkty[i].cenaBruttoSuma*produkty[i].ilosc;
		i++;
	}
	public void ustawNabywce(String nazwa, String adres, String nip)
	{
		nabywca = String.format("%s \n%s \n%s",nazwa,adres,nip);
	}
	public void drukujFakture()
	{
		System.out.println("FAKTURA VAT nr "+this.numer);
		System.out.println("Data sprzeda�y: "+this.data);
		System.out.println();
		System.out.println("SPRZEDAWCA:");
		System.out.println("Firma Us�ugowo-Handlowa Morinex");
		System.out.println("ul. Koszykowa 15, 30-194 Krak�w");
		System.out.println("NIP 677-001-20-12");
		System.out.println();
		System.out.println("NABYWCA:");
		System.out.println(this.nabywca);
		System.out.println();
		System.out.println("| Nazwa towaru/us�ugi |  j.m. | cena | ilo�� | wart.netto | st.VAT | wart.Brutto|");
		System.out.println("--------------------------------------------------------------------------------");
		for(Produkt produkt:produkty)
		{
			System.out.println(produkt);
		}
		System.out.println("--------------------------------------------------------------------------------");
		System.out.println();
		System.out.printf("Razem do zap�aty: %5.2f z�.",this.suma);
	}
}


public class KreatorFakturVAT 
{
    public static void main(String[] args) 
    {
        FakturaVat faktura = new FakturaVat("24.04.2008",3);
        faktura.ustawNabywce("Firma VENPOL SA","ul. D�uga 8/7, 31-723","NIP 982-10-32-203");
        faktura.dodajProdukt("towar","Buty","para",19.99,2,0.22);
        faktura.dodajProdukt("towar","Bluza","szt.",39.99,3,0.22);
        faktura.dodajProdukt("us�uga","Szycie","Roboczo Godziny",5.99,1,0.22);
        faktura.drukujFakture();
    }
}
