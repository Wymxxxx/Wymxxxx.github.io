public class Trojkat extends Figura
{
    private Punkt punktA,punktB,punktC;
    
    public Trojkat(Punkt punktA,Punkt punktB,Punkt punktC) 
    {
    	this.punktA = punktA;
    	this.punktB = punktB;
    	this.punktC = punktC;
    }
    
    private double obliczOdleglosc(Punkt X, Punkt Y)
	{
		int xpunktA = X.pobierzX();
		int ypunktA = X.pobierzY();
		int xpunktB = Y.pobierzX();
		int ypunktB = Y.pobierzY();
		return Math.sqrt( (xpunktA-xpunktB)*(xpunktA-xpunktB) +	(ypunktA-ypunktB)*(ypunktA-ypunktB) );
	}
	public double obliczPole()
	{
		double a = obliczOdleglosc(punktA,punktB);
		double b = obliczOdleglosc(punktA,punktC);
		double c = obliczOdleglosc(punktB,punktC);
		double p = (a + b + c)/2;
		return Math.sqrt(p*(p-a)*(p-b)*(p-c));
	}
	public double obliczObwod()
	{
		double a = obliczOdleglosc(punktA,punktB);
		double b = obliczOdleglosc(punktA,punktC);
		double c = obliczOdleglosc(punktB,punktC);
		return a+b+c;
	}
	public void przesun(int x, int y)
	{
		punktA.przesun(x,y);
		punktB.przesun(x,y);
		punktC.przesun(x,y);
	}
	public String toString()
	{
		return String.format("Tr�jk�t: A%s, B%s, C%s",punktA,punktB,punktC) +
							String.format("pole=%f, obw�d=%f",obliczPole(),obliczObwod());
	}
    
}
