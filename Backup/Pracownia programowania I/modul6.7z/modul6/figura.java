public class Figura
{
	public Figura()
	{
	}
	public void przesun(int dx, int dy)
	{
	}
}
