package telefonia;
public class TelefonInternetowy extends Telefon 
{
	public String identyfikator;

	public TelefonInternetowy (String numer, String identyfikator) 
	{
		super(numer);
		this.identyfikator = identyfikator;
	}

	public boolean sprawdzPolaczenie() 
	{
		return true;
	}
	public void zadzwon(String nrTelefonu) 
	{
		if(sprawdzPolaczenie())	System.out.println("Dzwonie z internetowego do: " + nrTelefonu);
		else System.out.println("Brak polaczenia z internetem");
	}
}