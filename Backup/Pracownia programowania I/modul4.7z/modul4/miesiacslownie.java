import java.util.Scanner;
public class MiesiacSlownie 
{
	static String podajMiesiacSlownie(int a)
	{
		switch(a)
		{
			case 1:
				return "Stycze�";
			case 2:
				return "Luty";
			case 3:
				return "Marzec";
			case 4:
				return "Kwiecie�";
			case 5:
				return "Maj";
			case 6:
				return "Czerwiec";
			case 7:
				return "Lipiec";
			case 8:
				return "Sierpie�";
			case 9:
				return "Wrzesie�";
			case 10:
				return "Pa�dziernik";
			case 11:
				return "Listopad";
			case 12:
				return "Grudzie�";
		}
		return "B��dny Miesi�c";
	}
	public static void main(String[] args) 
	{
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj oznaczenie liczbowe miesi�ca: ");
        int miesiac = wprowadzono.nextInt();
        if (0<miesiac && miesiac<=12) System.out.println("Jest to " + podajMiesiacSlownie(miesiac));
        else System.out.println("�le wprowadzi�e� oznaczenie liczbowe!");
    }
}
