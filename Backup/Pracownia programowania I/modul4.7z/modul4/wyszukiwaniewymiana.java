import java.util.*;
public class WyszukiwanieWymiana 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj tekst: ");
        String tekst = wprowadzono.nextLine();
        System.out.println("Podaj ci�g znak�w z podanego tekstu kt�ry chcesz zast�pi�: ");
        String ciagZastepowany = wprowadzono.nextLine();
        System.out.println("Podaj ci�g znak�w kt�ry ma by� wstawiony w miejsce zast�powanych: ");
        String ciagNowy = wprowadzono.nextLine();
        String nowyTekst = tekst.replace(ciagZastepowany, ciagNowy);
        System.out.println("Powsta�y tekst to: " + nowyTekst);
    }
}
