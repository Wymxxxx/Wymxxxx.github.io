import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;

public class Totolotek 
{
	static int[] wytypojLiczby()
	{
		Scanner wprowadzono = new Scanner(System.in);
		int[] liczbyWytypowane = new int[6];
		System.out.println("Podaj 6 liczb naturalnych z zakresu 1-49 kt�re chcesz wytypowa�: ");
		for (int i=0; i<6; i++) 
		{
			do
			{
				liczbyWytypowane[i] = wprowadzono.nextInt();
				if(liczbyWytypowane[i]<1 || 49<liczbyWytypowane[i] || (i>0 && liczbyWytypowane[i-1]==liczbyWytypowane[i])) System.out.println("Ta liczba nie jest z przedzia�u 1-49, lub ju� j� poda�e�, podaj inn�");
			}
			while (liczbyWytypowane[i]<1 || 49<liczbyWytypowane[i]);
		}			
		Arrays.sort(liczbyWytypowane);
		return liczbyWytypowane;
	}
	
	static int[] wylosujLiczby()
	{
		Random generator = new Random();
		int[] liczbyWylosowane = new int[6];
		for (int i=0; i<6; i++)
		{
			do 
			{
				liczbyWylosowane[i] = generator.nextInt(50-1)+1;
			}
			while((i>0 && liczbyWylosowane[i-1]==liczbyWylosowane[i]));
		}
		Arrays.sort(liczbyWylosowane);
		return liczbyWylosowane;
	}
	
	public static void main(String[] args) 
	{
        int[] liczbyWytypowane = wytypojLiczby();
        int[] liczbyWylosowane = wylosujLiczby();
        int wynik = 0;
        for (int i=0 ; i<6; i++)
        {
        	for (int j=0; j<6; j++)
        	{
        		if(liczbyWylosowane[j] == liczbyWytypowane[i]) wynik++;
        	}
        }
        System.out.print("Twoje Liczby to: ");
        for(int liczbaWytypowana:liczbyWytypowane) System.out.print(liczbaWytypowana + " ");
        System.out.print("\nLiczby Wylosowane to: ");
        for(int liczbaWylosowana:liczbyWylosowane) System.out.print(liczbaWylosowana + " ");
        System.out.print("\nTrafi�e� " + wynik + " liczb!");
        
    }
}
