public class konspekt 
{
    public static void main(String[] args) 
    {
         String napis1 = "Jan Kowalski";
         String napis2 = new String("Jan Kowalski");
         if (napis1==napis2) System.out.println("TAK");
         else System.out.println("NIE");
         if (napis1.equals(napis2)) System.out.println("TAK");
         else System.out.println("NIE");
         
    }
}
