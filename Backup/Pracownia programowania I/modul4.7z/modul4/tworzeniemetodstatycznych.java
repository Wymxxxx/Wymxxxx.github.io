import java.util.Scanner;
public class TworzenieMetodStatycznych 
{
	static void wyswietlTekst(String tekst)
	{
		System.out.print(tekst);
	}
	
	static int odczytajLiczbe()
	{
		Scanner wprowadzono = new Scanner (System.in);
		return wprowadzono.nextInt();
	}
    public static void main(String[] args) 
   	{
   		int liczbaPierwsza, liczbaDruga, wynik;
   		wyswietlTekst("Podaj pierwsz� liczb�: ");
   		liczbaPierwsza = odczytajLiczbe();
   		wyswietlTekst("Podaj druga liczb�: ");
   		liczbaDruga = odczytajLiczbe();
   		wynik = liczbaPierwsza + liczbaDruga;
   		wyswietlTekst("Suma wynosi = " + wynik + "\n");
   	}
}
