import java.util.*;
public class Statki {       
    static int literaNaCyfre(char x)
    {
        switch(x)
        {
            case 'A':
                return 0;
            case 'B':
                return 1;
            case 'C':
                return 2;
            case 'D':
                return 3;
            case 'E':
                return 4;
            case 'F':
                return 5;
            case 'G':
                return 6;
            case 'H':
                return 7;
            case 'I':
                return 8;
            case 'J':
                return 9;
            default:
                return -1;
        }
                   
               
        }
       
    public static void main(String[] args) {
    Scanner sc = new Scanner (System.in);
    long czasStart = System.currentTimeMillis();
    int[][] statki = new int[10][10];
    int licznikJedynek = 0;
    int licznikStrzalow = 0;
    int licznikDwojek = 0;
    // wypelniamy tabele zerami
    for (int i = 0; i < 10; i++)
    {
           for (int j = 0; j < 10; j++)
           {
               statki[i][j] = 0;
           }
    }

    //dwumasztowce
    int dwojki = 0;
    while (dwojki != 2)
    {
    int losPion = (int)(Math.round((Math.random()*9)));
    int losPoz = (int)(Math.round((Math.random()*9)));
    int pionCzyPoziom = (int)(Math.round((Math.random()*1))); // 0 pion, 1 poziom
    if (pionCzyPoziom == 0)
    {       
        if (losPoz >= 0 && losPoz <8)
        {       
            if (statki[losPoz][losPion] == 0 && statki[losPoz+1][losPion] == 0)
            {           
            dwojki++;
            statki[losPoz][losPion]=2;
            statki[losPoz+1][losPion]=2;
            if (losPoz != 0)
                statki[losPoz-1][losPion]=8;
            if (losPoz != 8)
                statki[losPoz+2][losPion]=8;
            if (losPion != 0)
            {           
                statki[losPoz][losPion-1]=8;
                statki[losPoz+1][losPion-1]=8;
            }
            if (losPion != 9)
            {           
                statki[losPoz][losPion+1]=8;
                statki[losPoz+1][losPion+1]=8;
            }
            if (losPion !=0 && losPoz != 0)
                statki[losPoz-1][losPion-1]=8;
            if (losPion !=0 && losPoz != 8)
                statki[losPoz+2][losPion-1]=8;
            if (losPion !=9 && losPoz!=0)
                statki[losPoz-1][losPion+1]=8;
            if (losPion !=9 && losPoz != 8)
                statki[losPoz+2][losPion+1]=8;
            }
            }
            if (losPoz == 9)
            {
                if (statki[losPoz][losPion] == 0 && statki[losPoz-1][losPion] == 0)
                {
                dwojki++;
                statki[losPoz][losPion]=2;
                statki[losPoz-1][losPion]=2;
                statki[losPoz-2][losPion]=8;
                if (losPion != 0)
                {               
                    statki[losPoz][losPion-1]=8;
                    statki[losPoz-1][losPion-1]=8;
                    statki[losPoz-2][losPion-1]=8;
                }
                if (losPion != 9)
                {               
                    statki[losPoz][losPion+1]=8;
                    statki[losPoz-1][losPion+1]=8;
                    statki[losPoz-2][losPion+1]=8;
                }
               
           
                   
                }

            }
        }
        else
        {
            if (losPion >= 0 && losPion <8)
            {
                if (statki[losPoz][losPion] == 0 && statki[losPoz][losPion+1] == 0)
                {
                dwojki++;
                statki[losPoz][losPion]=2;
                statki[losPoz][losPion+1]=2;
                if (losPoz != 0)
                {               
                    statki[losPoz-1][losPion]=8;
                    statki[losPoz-1][losPion+1]=8;
                }
                if (losPoz != 9)
                {
                    statki[losPoz+1][losPion]=8;
                    statki[losPoz+1][losPion+1]=8;
                }
                if (losPion != 0)
                    statki[losPoz][losPion-1]=8;
                if (losPion != 8)
                    statki[losPoz][losPion+2]=8;
                if (losPoz != 0 && losPion != 0)
                    statki[losPoz-1][losPion-1]=8;
                if (losPoz != 0 && losPion != 8)
                    statki[losPoz-1][losPion+2]=8;
                if (losPoz != 9 && losPion != 8)
                    statki[losPoz+1][losPion+2]=8;
                if (losPoz != 9 && losPion != 0)
                    statki[losPoz+1][losPion-1]=8;

                }
            }
            if (losPion == 9)
            {
                if (statki[losPoz][losPion] == 0 && statki[losPoz][losPion-1] == 0)
                {
                dwojki++;
                statki[losPoz][losPion]=2;
                statki[losPoz][losPion-1]=2;
                statki[losPoz][losPion-2]=8;
                if (losPoz != 0)
                {               
                    statki[losPoz-1][losPion]=8;
                    statki[losPoz-1][losPion-1]=8;
                    statki[losPoz-1][losPion-2]=8;                   
                }
                if (losPoz != 9)
                {
                    statki[losPoz+1][losPion]=8;
                    statki[losPoz+1][losPion-1]=8;
                    statki[losPoz+1][losPion-2]=8;
                }
               
                }
            }
        }
    }
 
    //dwumasztowce end
    // jednomasztowce
    int jedynki = 0;
    while (jedynki != 3)
    {   
    int losPion = (int)(Math.round((Math.random()*9)));
    int losPoz = (int)(Math.round((Math.random()*9)));
    if (statki[losPoz][losPion] == 0)
    {
        jedynki++;
        statki[losPoz][losPion] = 1;
        if (losPoz != 0)
            statki[losPoz-1][losPion] = 8;
        if (losPoz != 9)
            statki[losPoz+1][losPion] = 8;
        if (losPion != 0)
            statki[losPoz][losPion-1] = 8;
        if (losPion != 9)
            statki[losPoz][losPion+1] = 8;
        if (losPoz != 0 && losPion != 0)
            statki[losPoz-1][losPion-1] = 8;
        if (losPoz != 9 && losPion != 9)
            statki[losPoz+1][losPion+1] = 8;
        if (losPoz != 0 && losPion != 9)
            statki[losPoz-1][losPion+1] = 8;
        if (losPoz != 9 && losPion != 0)
            statki[losPoz+1][losPion-1] = 8;
           
    }
   
    }
    // jednomasztowce end

    // strzelanko ;)   
    do
    {   
    licznikJedynek = 0;
    licznikDwojek = 0;
    // tester
    System.out.println();
    for(int test = 0; test < 10; test++)
    {
        for (int test2 = 0; test2 < 10; test2++)
        {
            System.out.print(statki[test][test2] + " ");
        }
        System.out.println();
    }
    // tester
    System.out.println("STRZELAJ!");
    String strzal = sc.nextLine();
    char krzaczek = strzal.charAt(0);
    int two = literaNaCyfre(krzaczek);
    // zeby 10 dzialalo ;)
    int one = 0;
    if (strzal.length() == 2)   
        one = Integer.parseInt(strzal.substring(1,2));
    else
        one = Integer.parseInt(strzal.substring(1,3));
    licznikStrzalow++;
    // litery to rzedy a cyfry to kolumny i trzeba obrocic ;)   
    if (statki[one-1][two] == 1)
        {
        System.out.println("Trafiony zatopiony ;)");
        statki[one-1][two] = 4;       
        }
    else if (statki[one-1][two] == 2) // dwojki sprawdzenie
    {
        System.out.print("trafiony ");
        statki[one-1][two] = 5;
        if (one-1 == 0 && two == 0)
        {
            if (statki[one][two] != 2 || statki [one-1][two+1] != 2)
                System.out.print("i zatopiony\n");
        }
        if (one-1 == 9 && two == 9)
        {
            if (statki[one-2][two] != 2 || statki[one-1][two-1] != 2)
                System.out.print("i zatopiony\n");
        }
        if (one-1 == 9 && two == 0)
        {
            if (statki[one-2][two] != 2 || statki[one-1][two+1] != 2)
                System.out.print("i zatopiony\n");
        }
        if (one-1 == 0 && two == 9)
        {
            if (statki[one-1][two-1] != 2 || statki[one][two] != 2)
                System.out.print("i zatopiony\n");
        }
        if ((one-1 >=1 && one-1<= 8) && (two >= 1 && two <= 8 ))
        {
            if (statki[one-2][two] != 2 && statki[one][two] != 2 && statki[one-1][two-1] != 2 && statki[one-1][two+1] != 2)
                System.out.print("i zatopiony\n");           
        }
        if ((one-1 >= 1 && one-1 <= 8) && two == 0)
        {
            if (statki[one][two] != 2 && statki[one-2][two] != 2)
                System.out.print("i zatopiony\n");
        }
        if ((one-1 >=1 && one-1 <=8) && two == 9)
        {
            if (statki[one][two] != 2 && statki[one-2][two] != 2)
                System.out.print("i zatopiony\n");
        }
        if ((two >= 1 && two <= 8) && one-1 == 0)
        {
            if (statki[one-1][two-1] != 2 && statki[one-1][two+1] != 2)
                System.out.print("i zatopiony\n");
        }
        if ((two >= 1 && two <= 8) && one-1 == 9)
        {
            if (statki[one-1][two+1] != 2 && statki[one-1][two-1] != 2)
                System.out.print("i zatopiony\n");
        }
    }
    else
        System.out.println("Pudlo ;p");
    // sprawdzenie czy sa jeszcze do utopienia
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (statki[i][j]==1)
            {
                licznikJedynek++;               
            }
            else if (statki[i][j]==2)
            {
                licznikDwojek++;
            }
        }       
    }   
    }   
    while (licznikJedynek != 0 || licznikDwojek != 0);
    System.out.println("\n == Gameover == \n");   
    System.out.println("Ilosc strzalow: " + licznikStrzalow);
      long czasKoniec = System.currentTimeMillis();
      long sec = ((czasKoniec - czasStart)/1000);
      long minuty = sec/60;
      long sekundy = sec%60;     
      System.out.println("Gra trwala: " + minuty + " minut, " + sekundy + " sekund.");

    }
} 