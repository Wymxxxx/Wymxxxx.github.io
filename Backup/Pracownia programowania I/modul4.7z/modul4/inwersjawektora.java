public class InwersjaWektora 
{
	static void inwersja(int[] tablica)
	{
		int i = 0;
		int j = tablica.length-1;
		int pomoc;
		while(i<j)
		{
			pomoc = tablica[i];
			tablica[i] = tablica[j];
			tablica[j] = pomoc;
			i++;
			j--;
		}
	}	
    public static void main(String[] args) 
    {
        int[] wektor = {4,2,7,3,9,1,8,5};
        inwersja(wektor);
        for(int liczba:wektor) System.out.print(liczba + " ");
    }
}
