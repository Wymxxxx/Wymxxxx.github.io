/*
 * Nazwa: sterowaniePrzebiegiemProgramu
 * Uruchomienie: 
 *
 * cmd.exe:
 * Kompilacja poleceniem javac SterowaniePrzebiegiemProgramu.java
 * Uruchomienie poleceniem java SterowaniePrzebiegiemProgramu
 *
 * IDE:
 * Kompilacja poleceniem 'Build' -> 'Build file'
 * Uruchomienie poleceniem 'Run' -> 'Run file'
 */
 
//Import klas bibliotecznych
import java.util.Scanner;

public class SterowaniePrzebiegiemProgramu
{
	public static void main(String[] args)
	{
	
	//Rozpoczynamy wczytywanie  slow, lub zdan z klawiatury
	Scanner klawiatura = new Scanner(System.in);
	//Zmienna stop typu boolean przyjmuje warto�� false
	boolean stop = false;
	//Wstawka estetyczna
	String wyjscie = " ";
	
	do {
	System.out.print("  \n Podaj slowo, lub zdanie (jesli chcesz zakonczyc dzialanie programu wpisz STOP):  ");
	//Skanowanie podanego slowa, lub zdania
	String wejscie = klawiatura.nextLine();
	//STOP zostalo tutaj zapisane wielkimi literami celowo, uzytkownik moze wprowadzic slowo "stop" i program sie wykona, wpisanie slowa "STOP" zakonczy program
	if (wejscie.equals("STOP")) {
		stop = true;		
	}
	else {
	//Wyeliminowanie koniecznosci podwajania wpisow w 'case' poprzez zamiane wszystkich liter pobranych z klawiatury na male
	wejscie = wejscie.toLowerCase();
	//Petla sprawdzajaca ilosc liter w slowie
	for( int k = 0; k < wejscie.length(); k++)
		{
		//Switch sprawdzajacy na ktorym miejscu jest zadana litera w slowie
		switch (wejscie.charAt(k))
		{
		//Zamiana poszczegolnych liter na NATO-PA
		case 'a': wyjscie = "Alpha";
		break;
		case 'b': wyjscie = "Bravo";
		break;
		case 'c': wyjscie = "Charlie";
		break;
		case 'd': wyjscie = "Delta";
		break;
		case 'e': wyjscie = "Echo";
		break;
		case 'f': wyjscie = "Foxtrot";
		break;
		case 'g': wyjscie = "Golf";
		break;
		case 'h': wyjscie = "Hotel";
		break;
		case 'i': wyjscie = "India";
		break;
		case 'j': wyjscie = "Juliett";
		break;
		case 'k': wyjscie = "Kilo";
		break;
		case 'l': wyjscie = "Lima";
		break;
		case 'm': wyjscie = "Mike";
		break;
		case 'n': wyjscie = "November";
		break;
		case 'o': wyjscie = "Oscar";
		break;
		case 'p': wyjscie = "Papa";
		break;
		case 'q': wyjscie = "Quebec";
		break;
		case 'r': wyjscie = "Romeo";
		break;
		case 's': wyjscie = "Sierra";
		break;
		case 't': wyjscie = "Tango";
		break;
		case 'u': wyjscie = "Uniform";
		break;
		case 'v': wyjscie = "Victor";
		break;
		case 'w': wyjscie = "Whiskey";
		break;
		case 'x': wyjscie = "X-Ray";
		break;
		case 'y': wyjscie = "Yankee";
		break;
		case 'z': wyjscie = "Zulu";
		break;
		//Wartosc domyslna w przypadku znaku spoza listy
		default:
		wyjscie = " ";
		break;	
		}
	//Wyswietlenie slowa, lub zdania w NATO-PA
	System.out.print(wyjscie + " ");
		}
	}
} 
while (!stop);
	}
}
