import java.util.Scanner;
public class WeryfikacjaPeselMetoda 
{
    static boolean liczbaKontrolna (String pesel) 
    {
        int[] tab = new int[11];
        for (int i=0; i<=10; i++) tab[i] = (int)pesel.charAt(i)-(int)'0';
        tab[0] = tab[0]*9;
        tab[1] = tab[1]*7;
        tab[2] = tab[2]*3;
        tab[4] = tab[4]*9;
        tab[5] = tab[5]*7;
        tab[6] = tab[6]*3;
        tab[8] = tab[8]*9;
        tab[9] = tab[9]*7;
        int suma = 0;
        for (int i=0; i<=9; i++) suma+=tab[i];
        int wynik = suma%10;
        if (wynik == tab[10]) return true;
        else return false;
    }
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        String pesel;
        do
        {
        System.out.print("Podaj poprawny Pesel: ");
        pesel = wprowadzono.nextLine();
        }
        while(!(pesel.matches("[0-9]{11}")));
        
        if (liczbaKontrolna(pesel)) System.out.println("Pesel " + pesel + " jest poprawny");
        else System.out.println("Pesel " + pesel + " jest niepoprawny.");
    }
} 