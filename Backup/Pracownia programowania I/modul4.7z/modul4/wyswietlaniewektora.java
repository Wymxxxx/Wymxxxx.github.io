public class WyswietlanieWektora 
{
	static void wyswietlWektor(int[] tablica)
	{
		for(int liczba:tablica) System.out.print(liczba + " ");
		System.out.println();
	}
	static void inwersja(int[] tablica)
	{
		int i = 0;
		int j = tablica.length-1;
		int pomoc;
		while(i<j)
		{
			pomoc = tablica[i];
			tablica[i] = tablica[j];
			tablica[j] = pomoc;
			i++;
			j--;
		}
	}	
    public static void main(String[] args) 
    {
        int[] wektor = {4,2,7,3,9,1,8,5};
        wyswietlWektor(wektor);
        inwersja(wektor);
        wyswietlWektor(wektor);
    }
}

