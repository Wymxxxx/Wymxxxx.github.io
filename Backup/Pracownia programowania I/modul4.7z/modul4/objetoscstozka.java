import java.util.*;
public class ObjetoscStozka 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj wysoko�� sto�ka: ");
        double h = wprowadzono.nextDouble();
        System.out.println("Podaj promie� podstawy sto�ka: ");
        double r = wprowadzono.nextDouble();
        double objetosc = (Math.PI*r*r*h)/3;
        System.out.println("Obj�to�� tego sto�ka wynosi: " + objetosc + "cm3");
    }
}
