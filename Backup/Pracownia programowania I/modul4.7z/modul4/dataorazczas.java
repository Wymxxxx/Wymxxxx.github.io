import java.util.*;
public class DataOrazCzas 
{
    public static void main(String[] args) 
    {
        GregorianCalendar teraz = new GregorianCalendar();
        System.out.println(teraz.getTime());
        System.out.println(teraz.get(Calendar.YEAR) + "." + teraz.get(Calendar.MONTH+1) + "." + teraz.get(Calendar.DAY_OF_MONTH)
        					 + " " + teraz.get(Calendar.HOUR) + "." + teraz.get(Calendar.MINUTE));
    	System.out.println("Mamy " + teraz.get(Calendar.DAY_OF_YEAR) + " dzie� roku i " + teraz.get(Calendar.WEEK_OF_YEAR)
    						 + " tydzie� roku");
    						 
    	int dzienAktualny = teraz.get(Calendar.DAY_OF_YEAR);
    	int tydzienAktualny = teraz.get(Calendar.WEEK_OF_YEAR);
    	int ostatniDzienRoku = teraz.getActualMaximum(Calendar.DAY_OF_YEAR);
    	int ostatniTydzienRoku = teraz.getActualMaximum(Calendar.WEEK_OF_YEAR);
    	System.out.println("Do ko�ca roku zosta�o " + (ostatniDzienRoku-dzienAktualny) + " dni");
    	System.out.println("Do ko�ca roku zosta�o " + (ostatniTydzienRoku-tydzienAktualny) + " tygodni");
    	
    	GregorianCalendar dataNarodzin = new GregorianCalendar(1988, 6, 25, 15, 45);
    	long ileSekundAktualnie = teraz.getTimeInMillis()/1000;
        long ileSekundNarodziny = dataNarodzin.getTimeInMillis()/1000;
        long roznica = ileSekundAktualnie-ileSekundNarodziny;
        System.out.println("Tyle sekund mine�o od urodzenia: " + roznica);
        System.out.println("Tyle minut mine�o od urodzenia: " + roznica/60);
        System.out.println("Tyle godzin mine�o od urodzenia: " + roznica/3600);
        System.out.println("Tyle dni mine�o od urodzenia: " + roznica/3600/24);
        System.out.println("Tyle lat mine�o od urodzenia: " + roznica/3600/24/365);

    	
    }
}
