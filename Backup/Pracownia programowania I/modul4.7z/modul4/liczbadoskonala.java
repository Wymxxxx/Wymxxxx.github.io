import java.util.Scanner;
public class LiczbaDoskonala 
{
	static boolean sprawdzLiczbeDoskonala(int liczba)
	{
		int suma = 0;
		for(int i=1; i<=liczba/2; i++)
		{
			if(liczba%i==0) suma += i;
		}
		if(suma==liczba) return true;
		else return false;
	}
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.print("Podaj liczb� naturaln� kt�r� chcesz sprawdzi�: ");
        int liczba = wprowadzono.nextInt();
        if(sprawdzLiczbeDoskonala(liczba)) System.out.println("Liczba " + liczba + " jest liczb� doskona��");
        else System.out.println("Liczba " + liczba + " nie jest liczb� doskona��");
    }
}
