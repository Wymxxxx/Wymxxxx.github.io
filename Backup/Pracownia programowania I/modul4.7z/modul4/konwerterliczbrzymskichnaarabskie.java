import java.util.Scanner;
public class KonwerterLiczbRzymskichNaArabskie 
{
    static int zmienRzymskaNaArabska(String liczbaRzymska)
    {
    	int liczbaArabska = 0;
    	for(int i=0; i<liczbaRzymska.length(); i++)
    	{
    		char znak = liczbaRzymska.charAt(i);
    		switch(znak)
    		{
    			case 'I':
    				if(i<(liczbaRzymska.length()-1))
    				{
    					if(liczbaRzymska.charAt(i+1)=='V' || liczbaRzymska.charAt(i+1)=='X') liczbaArabska-=1;
    					else if(liczbaRzymska.charAt(i+1)=='L' || liczbaRzymska.charAt(i+1)=='C' || liczbaRzymska.charAt(i+1)=='D' || liczbaRzymska.charAt(i+1)=='M')
    					{
    						return -1;
    					}
    					else liczbaArabska+=1;
    				}
    				else liczbaArabska+=1;
    				break;
    			case 'V':
    				if(i<(liczbaRzymska.length()-1))
    				{
    					if(liczbaRzymska.charAt(i+1)=='X' || liczbaRzymska.charAt(i+1)=='L' || liczbaRzymska.charAt(i+1)=='C' || liczbaRzymska.charAt(i+1)=='D' || liczbaRzymska.charAt(i+1)=='M')
    					{
    						return -1;
    					}
    					else liczbaArabska+=5;
    				}
    				else liczbaArabska+=5;
    				break;
    			case 'X':
    				if(i<(liczbaRzymska.length()-1)) 
    				{
    					if(liczbaRzymska.charAt(i+1)=='L' || liczbaRzymska.charAt(i+1)=='C') liczbaArabska-=10;
    					else if(liczbaRzymska.charAt(i+1)=='D' || liczbaRzymska.charAt(i+1)=='M')
    					{
    						return -1;
    					}
    					else liczbaArabska+=10;
    				}
    				else liczbaArabska+=10;
    				break;
    			case 'L':
    				if(i<(liczbaRzymska.length()-1))
    				{
    					if(liczbaRzymska.charAt(i+1)=='C' || liczbaRzymska.charAt(i+1)=='D' || liczbaRzymska.charAt(i+1)=='M')
    					{
    						return -1;
    					}
    					else liczbaArabska+=50;
    				}
    				else liczbaArabska+=50;
    				break;
    			case 'C':
    				if(i<(liczbaRzymska.length()-1))
    				{
    					if(liczbaRzymska.charAt(i+1)=='D' || liczbaRzymska.charAt(i+1)=='M') liczbaArabska-=100;
    					else liczbaArabska+=100;
    				}
    				liczbaArabska+=100;
    				break;
    			case 'D':
    				if(i<(liczbaRzymska.length()-1))
    				{
    					if(liczbaRzymska.charAt(i+1)=='M')
    					{
    						return -1;
    					}
    					else liczbaArabska+=500;
    				}
    				else liczbaArabska+=500;
    				break;
    			case 'M':
    				liczbaArabska+=1000;
    				break;		
    		}
    	}
    	return liczbaArabska;
    }
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj liczb� w zapisie Rzymskim: ");
        String liczbaRzymska = wprowadzono.nextLine();
        if(liczbaRzymska.matches("[IVXLCDM]*"))
        {
        	int liczbaArabska = zmienRzymskaNaArabska(liczbaRzymska);
        	if(liczbaArabska==-1) System.out.println("�le poda�e� liczbe!");
        	else System.out.println("Liczba " + liczbaRzymska + " w zapisie Rzymskim, to liczba " + liczbaArabska + " w zapisie Arabskim");
        }
        else System.out.println("�le poda�e� liczbe!");
    }
}
