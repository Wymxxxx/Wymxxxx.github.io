import java.util.Scanner;
import java.util.Arrays;
public class AnalizatorKursowWalut 
{
	static double pobierzKurs()
	{
		Scanner wprowadzono = new Scanner(System.in);
		System.out.println("Podaj kurs ");
		double kurs = wprowadzono.nextDouble();
		return kurs;
	}
	static double wyznaczKursMax(double[] kursy)
	{
		double max = kursy[0];
		for(double kurs:kursy)
		{
			if(kurs>=max) max=kurs;
		}
		return max;
	}
	static double wyznaczKursMin(double[] kursy)
	{
		double min = kursy[0];
		for(double kurs:kursy)
		{
			if(kurs<=min) min=kurs;
		}
		return min;
	}
	static double wyznaczSredniaAryt(double[] kursy)
	{
		double suma = 0;
		for(double kurs:kursy) suma+=kurs;
		return suma/kursy.length;
	}
	static double wyznaczMediane(double[] kursy)
	{
		Arrays.sort(kursy);
		if (kursy.length%2==0) return (kursy[kursy.length/2]+kursy[kursy.length/2-1])/2;
		else return kursy[kursy.length/2];
	}
	static double wyznaczSredniaGeo(double[] kursy)
	{
		double suma=1;
		for(double kurs:kursy) suma*=kurs;
		return Math.pow(suma,0.2);
	}
	static double wyznaczSredniaHar(double[] kursy)
	{
		double suma=0;
		for(double kurs:kursy) suma+=(1/kurs);
		return (kursy.length)/suma;
	}
    public static void main(String[] args) 
    {
        double[] kursy = new double[5];
		for(int i=0; i<5; i++) kursy[i] = pobierzKurs();
		
		System.out.println("Kurs maksymalny = " + wyznaczKursMax(kursy));
		System.out.println("Kurs minimalny = " + wyznaczKursMin(kursy));
		System.out.println("�rednia arytmetyczna wynosi " + wyznaczSredniaAryt(kursy));
		System.out.println("Mediana wynosi " + wyznaczMediane(kursy));
		System.out.println("�rednia geometryczna wynosi " + wyznaczSredniaGeo(kursy));
		System.out.println("�rednia harmoniczna wynosi " + wyznaczSredniaHar(kursy));
    }
}
