import java.util.Scanner;
public class NowaMetodaStatyczna2
{
	static int odczytajLiczbe(String tekst)
	{
		System.out.print(tekst);
		Scanner wprowadzono = new Scanner (System.in);
		return wprowadzono.nextInt();
	}
    public static void main(String[] args) 
   	{
   		int liczbaPierwsza, liczbaDruga, wynik;
   		liczbaPierwsza = odczytajLiczbe("Zapodaj Liczbe: ");
   		liczbaDruga = odczytajLiczbe("Zapodaj Liczbe: ");
   		wynik = liczbaPierwsza + liczbaDruga;
   		System.out.print("Suma wynosi = " + wynmk + "\n");
   	}
}

