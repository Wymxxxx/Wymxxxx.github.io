import java.util.*;
public class KalendarzMiesieczny 
{
    static void wyswietlKalendarz(int rok, int miesiac) 
    {
        GregorianCalendar data = new GregorianCalendar(rok, miesiac-1, 1);
        String[] miesiace = {"Styczen", "Luty", "Marzec", "Kwiecien", "Maj", "Czerwiec", "Lipiec", "Sierpien", "Wrzesien", "Pazdziernik", "Listopad", "Grudzien"};
        System.out.println(miesiace[miesiac-1]+ " " +rok);
        System.out.println("PN WT SR CZ PT SB ND");
        int pierwszyDzienMiesiaca=data.get(Calendar.DAY_OF_WEEK)-1;
        if (pierwszyDzienMiesiaca==0) pierwszyDzienMiesiaca=7;
        for (int i=1; i<pierwszyDzienMiesiaca; i++) 
        {
            System.out.print("   ");
        }
        for (int j=1; j<=data.getActualMaximum(Calendar.DAY_OF_MONTH); j++) 
        {
            System.out.printf("%-3d", j);
            pierwszyDzienMiesiaca++;
            if (pierwszyDzienMiesiaca>7) 
            {
                System.out.println();
                pierwszyDzienMiesiaca=1;
            }
        }
    }
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj rok i miesi�c kt�rego kalendarz chcesz zobaczy�: ");
        System.out.println("Podaj rok: ");
        int rok = wprowadzono.nextInt();
        System.out.println("Podaj miesi�c: ");
        int miesiac = wprowadzono.nextInt();
        wyswietlKalendarz(rok, miesiac);
       
    }
}