import java.util.*;

public class Palindrom 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj jaki� napis: ");
        String napis = wprowadzono.nextLine();
        StringBuilder napis2 = new StringBuilder(napis);
        System.out.println(napis + "-" + napis2.reverse());
    }
}
