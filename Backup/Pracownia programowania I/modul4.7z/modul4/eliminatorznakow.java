import java.util.*;
public class EliminatorZnakow 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj tekst: ");
        String text = wprowadzono.nextLine();
        StringBuilder tekst = new StringBuilder(text);
        System.out.println("Podaj w postaci ci�gu znak�w, znaki kt�re chcesz usun�� z podanego tekstu: ");
        String ciag = wprowadzono.nextLine();
        int i,j;
        char znak,litera;
        for(i=0; i<ciag.length(); i++)
        {
        	znak = ciag.charAt(i);
        	for (j=0; j<tekst.length(); j++)
        	{
        		litera = tekst.charAt(j);
        		if(String.valueOf(znak).equalsIgnoreCase(String.valueOf(litera))) tekst.deleteCharAt(j);
        	}
        }
        System.out.println("Tekst po modyfikacji to: " + tekst);
    }
}
