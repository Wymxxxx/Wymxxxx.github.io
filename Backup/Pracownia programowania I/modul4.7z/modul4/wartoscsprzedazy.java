import java.util.Scanner;
import java.util.Arrays;
public class WartoscSprzedazy 
{
    static void posortujSprzedaz(double[] sprzedaze)
    {
        Scanner wprowadzono = new Scanner(System.in);
        for (int i = 0; i<10; i++)
        {
            System.out.println("Podaj laczna wartosc sprzedazy " + (i+1) + " pracownika");
            sprzedaze[i] = wprowadzono.nextDouble();
        }
       	Arrays.sort(sprzedaze);
       	System.out.println("Wartosci malejaco:");
        for (int i=9; i>=0; i--) System.out.println(sprzedaze[i]);
    }   
    public static void main(String[] args) 
    {
    	double[] sprzedaze = new double[10];
    	posortujSprzedaz(sprzedaze);
    }
} 
