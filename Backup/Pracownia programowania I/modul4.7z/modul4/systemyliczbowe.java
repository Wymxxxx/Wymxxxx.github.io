import java.util.*;
public class SystemyLiczbowe 
{
    public static void main(String[] args) 
    {
    	Scanner wprowadzono = new Scanner(System.in);
    	System.out.println("Podaj liczb�: ");
    	String liczbaWprowadzona = wprowadzono.nextLine();
    	System.out.println("Podaj podstaw� systemu liczbowego: ");
    	int podstawa = wprowadzono.nextInt();
    	Integer liczba = Integer.valueOf(liczbaWprowadzona, podstawa);
    	System.out.println("W systemie dziesi�tnym jest to liczba: " + liczba);
    }
}
