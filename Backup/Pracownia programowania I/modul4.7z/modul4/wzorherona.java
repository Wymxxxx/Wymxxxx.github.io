import java.util.Scanner;
public class WzorHerona 
{
	static double poleTrojkata(double a, double b, double c)
	{
		double p = 0.5*(a+b+c);
		double pole = Math.pow(p*(p-a)*(p-b)*(p-c), 0.5);
		return pole;
	}
    public static void main(String[] args) 
    {
    	Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj d�ugo�ci bok�w tr�jk�ta: ");
        System.out.println("Podaj bok a= ");
        double a = wprowadzono.nextDouble();
        System.out.println("Podaj bok b= ");
        double b = wprowadzono.nextDouble();
        System.out.println("Podaj bok c= ");
        double c = wprowadzono.nextDouble();
        if (a+b<c && a+c<b && c+b<a) System.out.println("Pole tego tr�jk�ta wynosi: " + poleTrojkata(a,b,c));
        else System.out.println("Z podanych bok�w nie stworzymy tr�jk�ta!");
    }
}
