import java.util.Scanner;
public class TworzenieMetodInstancyjnych 
{
	int obliczSzescian(int liczba)
	{
		return liczba*liczba*liczba;
	}
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj liczb� ca�kowit� kt�rej sze�cian chcesz policzy�: ");
        int a = wprowadzono.nextInt();
        TworzenieMetodInstancyjnych obiekt = new TworzenieMetodInstancyjnych();
        int wynik = obiekt.obliczSzescian(a);
        System.out.printf("Sze�cian liczby %d wynosi %d", a, wynik);
    }
}
