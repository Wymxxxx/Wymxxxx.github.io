import java.util.*;
public class FunkcjeTrygonometryczne 
{
	static double sinus(double kat)
	{
		kat = Math.toRadians(kat);
		return Math.sin(kat);
	}
	static double cosinus(double kat)
	{
		kat = Math.toRadians(kat);
		return Math.cos(kat);
	}
	static double tangens(double kat)
	{
		kat = Math.toRadians(kat);
		return Math.tan(kat);
	}
	public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj miar� k�ta: ");
        double kat = wprowadzono.nextDouble();
        System.out.println("Sinus tego k�ta wynosi " + sinus(kat));
        System.out.println("Cosinus tego k�ta wynosi " + cosinus(kat));
        System.out.println("Tangens tego k�ta wynosi " + tangens(kat));
    }
}
