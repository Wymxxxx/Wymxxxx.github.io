import java.util.Scanner;
public class OdchylenieStandardowe 
{	
	static double wyliczOdchylenieStandardowe(double[] liczby)
	{
		double suma = 0;
		for (int i=0; i<liczby.length; i++) suma+=liczby[i];
		double srednia = suma/liczby.length;
		suma = 0;
		for (int i=0; i<liczby.length; i++) suma+=Math.pow((liczby[i]-srednia),2);
		double odchylenieStandardowe = Math.pow(suma/liczby.length,0.5);
		return odchylenieStandardowe;
	}
    public static void main(String[] args) 
    {
    	Scanner wprowadzono = new Scanner(System.in);
    	System.out.println("Dla ilu liczb chcesz policzy� odchylenie standardowe?");
    	int ilosc = wprowadzono.nextInt();
    	double[] liczby = new double[ilosc];
        System.out.println("Podaj te liczby: ");
        for (int i=0; i<ilosc; i++) liczby[i]=wprowadzono.nextDouble();
        System.out.println("Odchylenie standardowe dla tych liczb wynosi: " + wyliczOdchylenieStandardowe(liczby));
        
        
    }
}
