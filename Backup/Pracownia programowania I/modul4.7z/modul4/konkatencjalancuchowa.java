public class KonkatencjaLancuchowa 
{
    public static void main(String[] args) 
    {
        String napis1 = "Uniwersytet ";
        String napis2 = "Ekonomiczny ";
        String napis3 = "w Krakowie";
        System.out.println((napis1.concat(napis2)).concat(napis3));
    }
}
