public class ZaokraglanieWartosci 
{
    public static void main(String[] args) 
    {
        double v = 10.5;
        System.out.println(Math.ceil(v));
        System.out.println(Math.round(v));
        System.out.println(Math.floor(v));
        System.out.println((int)Math.ceil(v));
        System.out.println((int)Math.floor(v));
    }
}
