import java.util.*;
public class PodzialWyrazenia 
{
    public static void main(String[] args) 
    {	
    	Scanner wprowadzono = new Scanner(System.in);
    	System.out.println("Podaj dowolne wyra�enie arytmetyczne: ");
    	StringBuilder tekst = new StringBuilder(wprowadzono.nextLine());
    	for(int i=0; i<tekst.length(); i++)
    	{
    		if(tekst.charAt(i)==(' ')) tekst.deleteCharAt(i);
    	}
    	String tekstNowy = tekst.toString();
    	StringTokenizer wyrazenie = new StringTokenizer(tekstNowy,"+-=*/", true);
     	while (wyrazenie.hasMoreTokens()) 
     	{
     		System.out.println(wyrazenie.nextToken());
     	}

    }
}
