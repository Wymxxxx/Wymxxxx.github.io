import java.io.*;
import java.util.*;
public class DaneStudentaCSV
{
	public static void main(String[] args) 
	{
		FileWriter plik = null;
		final boolean dopisywanie = true;
		String EOL = System.getProperty("line.separator");
		Scanner wprowadzono = new Scanner(System.in);
		int ilosc = 0;
		
		try 
		{
			plik = new FileWriter("DaneStudenta.csv",dopisywanie);
			System.out.println("Ilu student�w chcesz doda�?");
			ilosc = wprowadzono.nextInt();
			for(int i=1; i<=ilosc; i++)
			{
				System.out.println("Podaj nazwisko studenta nr " + i + " : ");
				plik.write(wprowadzono.next() + ",");
				System.out.println("Podaj imi� studenta nr " + i + " : ");
				plik.write(wprowadzono.next() + ",");
				System.out.println("Podaj wiek studenta nr " + i + " : ");
				plik.write(wprowadzono.nextInt() + ",");
				System.out.println("Podaj Kod Pocztowy studenta nr " + i + " : ");
				plik.write(wprowadzono.next() + ",");
				System.out.println("Podaj Miejscowo�� studenta nr " + i + " : ");
				plik.write(wprowadzono.next() + EOL);
				
				System.out.println("Zapisano do pliku: Studenta nr" + i);
			}
		}
		catch (IOException e) 
		{
			System.out.println("Problem z zapisem do pliku!");
		}
		finally 
		{
			if (plik != null)
			try 
			{
				plik.close();
			}
			catch (IOException e)
			{
				System.out.println("Problem z zamkni�ciem pliku!");
			}
		}
	}
}