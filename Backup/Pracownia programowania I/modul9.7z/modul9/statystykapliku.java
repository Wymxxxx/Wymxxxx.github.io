import java.io.*;
import java.util.*;
public class StatystykaPliku 
{
	public static void main(String[] args) 
	{
		FileReader plik = null;
		int znak;
		int znaki=0;
		int wyrazy=0;
		int linie=0;
		try 
		{
			plik = new FileReader("RedutaOrdona1.txt");
			while ( (znak = plik.read()) != -1 ) 
			{
				if(Character.toString((char)znak).equals(" "))
				{
					wyrazy++;
				}
				else if(Character.toString((char)znak).equals("\n"))
				{
					linie++;
					wyrazy++;
				}
				znaki++;
			}
		}
		catch (FileNotFoundException e) 
		{
			System.out.println("Brak pliku o podanej nazwie!");
		}
		catch (IOException e) 
		{
			System.out.println("Problem z odczytem pliku!");
		}
		finally 
		{
			if (plik != null)
			try 
			{
				plik.close();
			}			
			catch (IOException e)
			{
				System.out.println("Problem z zamkni�ciem pliku!");
			}
		}
		System.out.println("Statystyka: ");
		System.out.println("Liczba znak�w: " + znaki);
		System.out.println("Liczba wyraz�w: " + wyrazy);
		System.out.println("Liczba lini: " + linie);
	}
}