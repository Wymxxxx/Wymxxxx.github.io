import java.io.*;
import java.util.*;
public class KonwersjaZnakowPliku
{
	public static void main(String[] args) 
	{
		FileReader plik = null;
		FileWriter plikNowy = null;
		FileWriter plikPomocniczy = null;
		final boolean dopisywanie = true;
		String EOL = System.getProperty("line.separator");
		int znak = 0;
		Scanner wprowadzono = new Scanner(System.in);
		String sciezka = null;
		String nazwa = null;
		
		try 
		{
			System.out.println("Podaj nazwe pliku kt�ry chcesz zamieni�: ");
			nazwa = wprowadzono.next();
			System.out.println("Podaj lokalizacje pliku kt�ry chcesz zamieni�: ");
			sciezka = wprowadzono.next();
			plik = new FileReader(sciezka + nazwa);
			plikPomocniczy = new FileWriter("pomocniczy.txt",dopisywanie);
			plikNowy = new FileWriter(sciezka+nazwa,dopisywanie);
				 	
			while ( (znak = plik.read()) != -1 ) 
			{
				if(Character.toString((char)znak).equals("\n"))
				{
					plikPomocniczy.write(EOL);
				}
				else if(Character.toString((char)znak).matches("[A-Z�ӥ�����]"))
				{
					plikPomocniczy.write((Character.toString((char)znak)).toLowerCase());
				}
				else if(Character.toString((char)znak).matches("[a-z�󹜳���]"))
				{
					plikPomocniczy.write((Character.toString((char)znak)).toUpperCase());
				}
				else
				{
					plikPomocniczy.write(Character.toString((char)znak));
				}
			}
			plik.delete();
			plikNowy = plikPomocniczy;
			plikPomocniczy.delete();
			System.out.println("Zapisano do pliku: RedutaOrdona.txt");
		}
		catch (FileNotFoundException e) 
		{
			System.out.println("Brak pliku o podanej nazwie!");
		}
		catch (IOException e) 
		{
			System.out.println("Problem z odczytem lub zapisem do pliku!");
		}
		finally 
		{
			if (plikNowy != null)
			try 
			{
				plikNowy.close();
			}
			catch (IOException e)
			{
				System.out.println("Problem z zamkni�ciem pliku!");
			}
		}
	}
}