import java.io.*;
import java.util.*;
public class SzyfrCezara
{
	public static void main(String[] args) 
	{
		FileReader plik = null;
		FileWriter plikNowy = null;
		final boolean dopisywanie = true;
		String EOL = System.getProperty("line.separator");
		int znak = 0;
		Scanner wprowadzono = new Scanner(System.in);
		String sciezka = null;
		String nazwa = null;
		
		try 
		{
			System.out.println("Podaj nazwe pliku kt�ry chcesz zamieni�: ");
			nazwa = wprowadzono.next();
			System.out.println("Podaj lokalizacje pliku kt�ry chcesz zamieni�: ");
			sciezka = wprowadzono.next();
			plik = new FileReader(sciezka + nazwa);
			plikNowy = new FileWriter((sciezka+nazwa).replaceFirst(".txt","Zaszyfrowane.txt"),dopisywanie);
				 	
			while ( (znak = plik.read()) != -1 ) 
			{
				if(Character.toString((char)znak).equals("\n"))
				{
					plikNowy.write(EOL);
				}
				else if(Character.toString((char)znak).matches("[A-Wa-w]"))
				{
					plikNowy.write(Character.toString((char)(znak+3)));
				}
				else if(Character.toString((char)znak).matches(""))
				{
					plikNowy.write(Character.toString((char)(znak+3)));
				}
				else if(Character.toString((char)znak).matches("[X-Zx-z]"))
				{
					switch((char)znak)
					{
						case 'x':
						{
							plikNowy.write("a");
							break;
						}
						case 'y':
						{
							plikNowy.write("b");
							break;
						}
						case 'z':
						{
							plikNowy.write("c");
							break;
						}
						case 'X':
						{
							plikNowy.write("A");
							break;
						}
						case 'Y':
						{
							plikNowy.write("B");
							break;
						}
						case 'Z':
						{
							plikNowy.write("C");
							break;
						}
					}
				}
				else
				{
					plikNowy.write(Character.toString((char)znak));
				}
			}
			System.out.println("Zapisano do pliku: " + nazwa.replaceFirst(".txt","Zaszyfrowane.txt"));
		}
		catch (FileNotFoundException e) 
		{
			System.out.println("Brak pliku o podanej nazwie!");
		}
		catch (IOException e) 
		{
			System.out.println("Problem z odczytem lub zapisem do pliku!");
		}
		finally 
		{
			if (plikNowy != null)
			try 
			{
				plikNowy.close();
			}
			catch (IOException e)
			{
				System.out.println("Problem z zamkni�ciem pliku!");
			}
		}
	}
}