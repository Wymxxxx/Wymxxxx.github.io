import java.io.*;
public class ObjetoscPlikowFolderu 
{
	public static void main(String[] args) 
	{
		long objetosc = 0;
		String nazwaFolderu = args[0];
		File folder = new File(nazwaFolderu);
		File[] pliki = folder.listFiles();
		for(File plik : pliki)
		objetosc += plik.length();
		System.out.printf("Pojemno�� wszystkich plik�w wynosi %s bajt�w",objetosc);
	}
}