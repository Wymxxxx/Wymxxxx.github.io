import java.io.*;
public class PojemnoscDyskow 
{
	public static void main(String[] args) 
	{
		String folderGlowny = File.separator;
		String zasob;
		double pojemnosc;
		double GB = 1024*1024*1024;
		System.out.println("NAZWA POJEMNO��");
		File[] dyski = (new File(folderGlowny)).listRoots();
		for(File dysk : dyski) 
		{
			zasob = dysk.getPath();
			pojemnosc = dysk.getTotalSpace()/GB;
			System.out.printf("%4s %8.2fGB\n",zasob,pojemnosc);
		}
	}
}