import java.io.*;
import java.util.*;
public class KonwersjaZnakowPliku
{
	public static void main(String[] args) 
	{
		FileReader plik = null;
		FileWriter plikNowy = null;
		final boolean dopisywanie = true;
		String EOL = System.getProperty("line.separator");
		int znak = 0;
		Scanner wprowadzono = new Scanner(System.in);
		String sciezka = null;
		String nazwa = null;
		
		try 
		{
			System.out.println("Podaj nazwe pliku kt�ry chcesz zamieni�: ");
			nazwa = wprowadzono.next();
			System.out.println("Podaj lokalizacje pliku kt�ry chcesz zamieni�: ");
			sciezka = wprowadzono.next();
			plik = new FileReader(sciezka + nazwa);
			plikNowy = new FileWriter(sciezka+nazwa,dopisywanie);
				 	
			while ( (znak = plik.read()) != -1 ) 
			{
				if(Character.toString((char)znak).equals("\n"))
				{
					plikNowy.write(EOL);
				}
				else if(Character.toString((char)znak).matches("[A-Z�ӥ�����]"))
				{
					plikNowy.write((Character.toString((char)znak)).toLowerCase());
				}
				else if(Character.toString((char)znak).matches("[a-z�󹜳���]"))
				{
					plikNowy.write((Character.toString((char)znak)).toUpperCase());
				}
				else
				{
					plikNowy.write(Character.toString((char)znak));
				}
			}
			System.out.println("Zapisano do pliku: " + nazwa);
		}
		catch (FileNotFoundException e) 
		{
			System.out.println("Brak pliku o podanej nazwie!");
		}
		catch (IOException e) 
		{
			System.out.println("Problem z odczytem lub zapisem do pliku!");
		}
		finally 
		{
			if (plikNowy != null)
			try 
			{
				plikNowy.close();
			}
			catch (IOException e)
			{
				System.out.println("Problem z zamkni�ciem pliku!");
			}
		}
	}
}