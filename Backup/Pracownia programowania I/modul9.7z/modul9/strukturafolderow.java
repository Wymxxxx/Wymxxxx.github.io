import java.io.*;
public class StrukturaFolderow
{
	public static void main(String[] args)
	{
		String nazwa = "KOMPUTER";
		String danePliku = nazwa;
		File komputer = new File(danePliku);
		komputer.mkdir();
	
		String sciezka = "KOMPUTER" + File.separator;
		String nazwa2 = "LAPTOP";
		String danePliku2 = sciezka + nazwa2;
		File laptop = new File(danePliku2);
		laptop.mkdir();
	
		String sciezka2 = "KOMPUTER" + File.separator + "LAPTOP" + File.separator;
		String nazwa3 = "IBM";
		String danePliku3 = sciezka2 + nazwa3;
		File ibm = new File(danePliku3);
		ibm.mkdir();
	
		String nazwa4 = "COMPAQ";
		String danePliku4 = sciezka2 + nazwa4;
		File compaq = new File(danePliku4);
		compaq.mkdir();
	
		String nazwa5 = "PALMTOP";
		String danePliku5 = sciezka + nazwa5;
		File palmtop = new File(danePliku5);
		palmtop.mkdir();
	}
}