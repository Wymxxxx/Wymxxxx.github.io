import java.io.*;
import java.util.*;
public class StatystykaZnakowPliku 
{
	public static void main(String[] args) 
	{
		FileReader plik = null;
		int znak;
		int samogloski=0;
		int wspolgloski=0;
		try 
		{
			plik = new FileReader("RedutaOrdona.txt");
			while ( (znak = plik.read()) != -1 ) 
			{
				if(Character.toString((char)znak).matches("[AEIOUYaeiuoy]"))
				{
					samogloski++;
				}
				else if(Character.toString((char)znak).matches("[QWRTPSDFGHJKLZXCVBNMʥӌ����qw�rt�p�sdfghjk�zx����vbnm�]"))
				{
					wspolgloski++;
				}
			}
		}
		catch (FileNotFoundException e) 
		{
			System.out.println("Brak pliku o podanej nazwie!");
		}
		catch (IOException e) 
		{
			System.out.println("Problem z odczytem pliku!");
		}
		finally 
		{
			if (plik != null)
			try 
			{
				plik.close();
			}			
			catch (IOException e)
			{
				System.out.println("Problem z zamkni�ciem pliku!");
			}
		}
		System.out.println("Samog�osek: " + samogloski);
		System.out.println("Wsp�g�osek: " + wspolgloski);
	}
}