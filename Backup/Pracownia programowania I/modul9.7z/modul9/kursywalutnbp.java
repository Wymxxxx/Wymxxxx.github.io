import java.net.*;
import java.io.*;
public class KursyWalutNBP 
{
	public static void main(String[] args) 
	{
		String adres = "http://www.nbp.pl/Kursy/KursyA.html";
		try
		{
			URL url = new URL(adres);
			InputStream inStream = url.openStream();
			BufferedReader dane = new BufferedReader(new InputStreamReader(inStream));
			String linia = "";
			String kurs = "";
			System.out.println("�redni Kurs Wynosi: ");
			while ((linia = dane.readLine()) != null)
			{
				if(linia.matches("(.*)(dolar ameryka�ski)(.*)"))
				{
					System.out.print("Dolar Ameryka�ski: ");
					linia = dane.readLine();
					linia = dane.readLine();
					kurs = linia.substring(16,22);
					System.out.print(kurs + "\n");
				}
				
				if(linia.matches("(.*)(funt szterling)(.*)"))
				{
					System.out.print("Funt Szterling: ");
					linia = dane.readLine();
					linia = dane.readLine();
					kurs = linia.substring(16,22);
					System.out.print(kurs + "\n");
				}
				
				if(linia.matches("(.*)(frank szwajcarski)(.*)"))
				{
					System.out.print("Frank Szwajcarski: ");
					linia = dane.readLine();
					linia = dane.readLine();
					kurs = linia.substring(16,22);
					System.out.print(kurs + "\n");
				}
				
				if(linia.matches("(.*)(euro)(.*)"))
				{
					System.out.print("Euro: ");
					linia = dane.readLine();
					linia = dane.readLine();
					kurs = linia.substring(16,22);
					System.out.print(kurs + "\n");
				}
			}
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
		}
	}
}