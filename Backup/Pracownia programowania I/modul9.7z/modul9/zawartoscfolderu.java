import java.io.*;
import java.util.*;
public class ZawartoscFolderu 
{
    public static void main(String[] args) 
    {
    	GregorianCalendar dataPoczatek = new GregorianCalendar(1970,1,1,0,0,0);
    	long miliPoczatek = dataPoczatek.getTimeInMillis();
    	long miliPlik = 0;
    	long miliWynik; 
    	GregorianCalendar dataPliku = new GregorianCalendar(1970,1,1,0,0,0);
        File folder = new File(args[0]);
        File[] pliki = folder.listFiles();
		for(File plik : pliki)
		{
        	System.out.println(plik.getName());
			if(plik.isFile())
			{
				System.out.print("Rozmiar: " + plik.length()+ " bajt�w  ");
				miliPlik = plik.lastModified();
				miliWynik = miliPlik-miliPoczatek;
				dataPliku.setTimeInMillis(miliWynik);
				System.out.print("Data: " + dataPliku.getTime() + "\n");
			}
        }
    }
}
