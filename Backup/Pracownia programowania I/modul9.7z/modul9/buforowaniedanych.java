import java.io.*;
public class BuforowanieDanych
{
	public static void main(String[] args) 
	{
		FileReader plik = null;
		BufferedReader plikBuforowany = null;
		int znak;
		try 
		{
			plik = new FileReader(args[0]);
			plikBuforowany = new BufferedReader(plik);
			while ( (znak = plikBuforowany.read()) != -1 ) 
			{
				System.out.print((char)znak);
			}
		}
		catch (FileNotFoundException e) 
		{
			System.out.println("Brak pliku o podanej nazwie!");
		}
		catch (IOException e) 
		{
			System.out.println("Problem z odczytem pliku!");
		}
		finally 
		{
			if (plik != null)
			try 
			{
				plik.close();
			}			
			catch (IOException e)
			{
				System.out.println("Problem z zamkni�ciem pliku!");
			}
		}
	}
}