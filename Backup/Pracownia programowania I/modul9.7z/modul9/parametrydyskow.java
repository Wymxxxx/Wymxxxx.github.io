import java.io.*;
public class ParametryDyskow 
{
	public static void main(String[] args) 
	{
		String folderGlowny = File.separator;
		String zasob;
		double pojemnosc;
		double wolne;
		double zajete;
		double GB = 1024*1024*1024;
		System.out.println("NAZWA POJEMNO�� 	WOLNE  		ZAJ�TE");
		File[] dyski = (new File(folderGlowny)).listRoots();
		for(File dysk : dyski) {
		zasob = dysk.getPath();
		pojemnosc = dysk.getTotalSpace()/GB;
		wolne = dysk.getFreeSpace()/GB;
		zajete = pojemnosc-wolne;
		System.out.printf("%4s %8.2fGB %8.2fGB %8.2fGB\n",zasob,pojemnosc,wolne,zajete);
}
}
}