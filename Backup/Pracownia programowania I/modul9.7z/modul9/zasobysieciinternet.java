import java.net.*;
import java.io.*;
public class ZasobySieciInternet 
{
	public static void main(String[] args) 
	{
		String adres = "http://www.uek.krakow.pl";
		try
		{
			URL url = new URL(adres);
			InputStream inStream = url.openStream();
			BufferedReader dane = new BufferedReader(new InputStreamReader(inStream));
			String linia = "";
			while ((linia = dane.readLine()) != null)
			System.out.println(linia);
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
		}
	}
}