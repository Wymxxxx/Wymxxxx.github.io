import java.io.*;
import java.util.*;
public class RedutaOrdonaHTML
{
	public static void main(String[] args) 
	{
		FileReader plikTXT = null;
		FileWriter plikHTML = null;
		final boolean dopisywanie = true;
		String EOL = System.getProperty("line.separator");
		int znak = 0;
		
		try 
		{
			plikTXT = new FileReader("RedutaOrdona.txt");
			plikHTML = new FileWriter("RedutaOrdona.html",dopisywanie);
			
			plikHTML.write("<html>" + EOL + "<head>" + EOL + "<meta http-equiv=\"Content-Type\" content=/text/html;charset=ISO-8859-2\">"
							 + EOL + "<title>Moja strona</title>" + EOL + "</head>" + EOL + "<body>" + EOL + "<i>");
						 	
			while ( (znak = plikTXT.read()) != -1 ) 
			{
				if(Character.toString((char)znak).equals("\n"))
				{
					plikHTML.write("<br>" + EOL);
				}
				else
				{
					plikHTML.write(Character.toString((char)znak));
				}
			}
						 	
			plikHTML.write("</i>" + EOL + "</body>" + EOL + "</html>");
			System.out.println("Zapisano do pliku: RedutaOrdona.html");
		}
		catch (FileNotFoundException e) 
		{
			System.out.println("Brak pliku o podanej nazwie!");
		}
		catch (IOException e) 
		{
			System.out.println("Problem z odczytem lub zapisem do pliku!");
		}
		finally 
		{
			if (plikHTML != null)
			try 
			{
				plikHTML.close();
			}
			catch (IOException e)
			{
				System.out.println("Problem z zamkni�ciem pliku!");
			}
		}
	}
}