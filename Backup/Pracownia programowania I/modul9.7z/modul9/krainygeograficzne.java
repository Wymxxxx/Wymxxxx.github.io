import java.io.*;
public class KrainyGeograficzne 
{
	public static void main(String[] args) 
	{
		FileWriter plik = null;
		final boolean dopisywanie = true;
		String EOL = System.getProperty("line.separator");
		try 
		{
			plik = new FileWriter("KrainyGeograficzne.txt",dopisywanie);
			for(int i=0; i<args.length; i++)
			{
				plik.write(args[i] + EOL);
				System.out.println("Zapisano do pliku: " + args[i]);
			}
		}
		catch (IOException e) 
		{
			System.out.println("Problem z zapisem do pliku!");
		}
		finally 
		{
			if (plik != null)
			try 
			{
				plik.close();
			}
			catch (IOException e)
			{
				System.out.println("Problem z zamkni�ciem pliku!");
			}
		}
	}
}