import java.io.*;
public class TworzenieFolderow
{
	public static void main(String[] args)
	{
		String sciezka = args[0];
		String nazwa = args[1];
		String danePliku = sciezka + nazwa;
		File f = new File(danePliku);
		f.mkdir();
	}
}