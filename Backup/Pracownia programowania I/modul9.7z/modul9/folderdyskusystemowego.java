import java.io.*;
public class FolderDyskuSystemowego 
{
	public static void main(String[] args) 
	{
		String nazwaFolderu = "C:" + File.separator;
		File folder = new File(nazwaFolderu);
		for(String nazwaPlikuLubFolderu : folder.list())
		System.out.println(nazwaPlikuLubFolderu);
	}
}