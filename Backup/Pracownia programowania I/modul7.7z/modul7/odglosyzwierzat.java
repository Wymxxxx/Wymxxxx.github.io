interface Odglos
{
	public void dajGlos();
}

class Zwierze implements Odglos
{
	private String nazwa;
	public void dajGlos()
	{
		System.out.println("G�os zwierz�cia");
	}
}
class Pies extends Zwierze 
{
	public void dajGlos()
	{
	System.out.println("hau hau");
	}
}
class Kot extends Zwierze 
{
	public void dajGlos()
	{
		System.out.println("miau miau");
	}
}
class Krowa extends Zwierze 
{
	public void dajGlos()
	{
		System.out.println("muuuuu");
	}
}
class Kogut extends Zwierze
{
	public void dajGlos()
	{
		System.out.println("Kukuryku");
	}
}
public class OdglosyZwierzat
{
	public static void main(String[] args) 
	{
		Zwierze[] zwierzeta = new Zwierze[4];
		zwierzeta[0] = new Pies();
		zwierzeta[1] = new Kot();
		zwierzeta[2] = new Krowa();
		zwierzeta[3] = new Kogut();
		System.out.println("Rykowisko...");
		for(Zwierze zwierze: zwierzeta)
		{
			zwierze.dajGlos();
		}
	}
}