/* 
 *
 * Uruchomienie: Nalezy skompilowac pliki Aparat.java, Drukarka.java, Monitor.java, oraz Naglosnienie.java, a nastepnie skompilowac i uruchomic plik Przedmioty.java LUB skompilowac i uruchomic plik Przedmioty.java
 * W IDE JCreator: kompilacja -> build -> build file, uruchomienie -> run -> run file
 *
 * Stworzono w: JCreator 5.00 Pro
 */
class Drukarka {
	
	//Deklaracja zmiennych
	private String producent;
	private boolean laserowa;
	private String rodzajPapieru;
	private double szybkoscDruku;
	private boolean wifi;
	
	//Zmienne potrzebne do opisywania cech przedmiotu
	private String tekst = "Programowanie w Javie";
	
	//Zmienna, do sprawdzenia ile Drukarek mamy w bazie	
	private static int liczbaDrukarek;
	
	//Konstruktor do pierwszej metody
	public Drukarka(String producent, boolean laserowa, String rodzajPapieru, double szybkoscDruku, boolean wifi) {
	this.producent = producent;
	this.laserowa = laserowa;
	this.rodzajPapieru = rodzajPapieru;
	this.szybkoscDruku = szybkoscDruku;
	this.wifi = wifi;	
	liczbaDrukarek++;
	}
	
	//Metoda wyswietlajaca informacje o przedmiotach
	public void wyswietlInfo() {
	System.out.println("Drukarke wyprodukowal " + producent);
	System.out.println("Jest to drukarka laserowa " + laserowa);
	System.out.println("Obsluguje format " + rodzajPapieru);
	System.out.println("Drukuje z predkoscia " + szybkoscDruku + " stron na minute");
	System.out.println("Posiada funkcje WiFi " + wifi);
	}
	
	//Metody wyswietlajace cechy i wlasciwosci przedmiotow
	public String wyswietlCechePierwsza() {
	System.out.println("\n Drukuje tekst : ");
	return tekst;
	}
	
	public String wyswietlCecheDruga() {
	System.out.println("\n Drukuje tekst duzymi literami: ");
	return tekst.toUpperCase();
	}
	
	public String wyswietlCecheTrzecia() {
	System.out.println("\n Drukuje tekst dwukrotnie: ");
	return tekst + tekst;
	}
	
	//Metoda sprawdzajaca ile mamy Drukarek w bazie
	public static int ileDrukarek() {
		return liczbaDrukarek;
	}
	
	//Metody pobierajace dane z pol
	public String pobierzProducenta() {
		return producent;
	}
	
	public boolean pobierzCzyLaserowa() {
		return laserowa;
	}
	
	public String pobierzRodzajPapieru() {
		return rodzajPapieru;
	}
	
	public double pobierzSzybkoscDruku() {
		return szybkoscDruku;
	}
	
	public boolean pobierzWifi() {
		return wifi;
	}
	
	//Metody zmieniajace dane w polach
	public void ustawProducenta(String nowy) {
		this.producent = nowy;
	}
	
	public void ustawCzyLaserowa(boolean nowy) {
		this.laserowa = nowy;
	}
	
	public void ustawRodzajPapieru(String nowy) {
		this.rodzajPapieru = nowy;
	}
	
	public void ustawSzybkoscDruku(double nowy) {
		this.szybkoscDruku = nowy;
	}
	
	public void ustawWifi(boolean nowy) {
		this.wifi = nowy;
	}
	
	//Metoda trzecia - toString, dzieki ktorej mozemy wyswietlic na ekranie opis przedmiotu
	public String toString() {
		return "Producent: " + producent + "\n Laserowa: " + laserowa + "\n Rodzaj obslugiwanego papieru: " + rodzajPapieru + "\n Szybkosc druku: " + szybkoscDruku + " stron na minute " + "\n WiFi: " + wifi;
	}
}