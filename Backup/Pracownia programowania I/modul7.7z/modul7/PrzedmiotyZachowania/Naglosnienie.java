/*
 *
 * Uruchomienie: Nalezy skompilowac pliki Aparat.java, Drukarka.java, Monitor.java, oraz Naglosnienie.java, a nastepnie skompilowac i uruchomic plik Przedmioty.java LUB skompilowac i uruchomic plik Przedmioty.java
 * W IDE JCreator: kompilacja -> build -> build file, uruchomienie -> run -> run file
 *
 * Stworzono w: JCreator 5.00 Pro
 */
class Naglosnienie {
	
	//Deklaracja zmiennych
	private String producent;
	private String kolor;
	private double iloscGlosnikow;
	private boolean sterowaniePilotem;
	private boolean wyjscieSluchawkowe;
	
	//Zmienne potrzebne do opisywania cech przedmiotu
	private static double glosnosc = 5.2;
	
	//Zmienna, do sprawdzenia ile Naglosnienia mamy w bazie
	private static int liczbaNaglosnienia;
	
	//Konstruktor do pierwszej metody
	public Naglosnienie(String producent, String kolor, double iloscGlosnikow, boolean sterowaniePilotem, boolean wyjscieSluchawkowe) {
	this.producent = producent;
	this.kolor = kolor;
	this.iloscGlosnikow = iloscGlosnikow;
	this.sterowaniePilotem = sterowaniePilotem;
	this.wyjscieSluchawkowe = wyjscieSluchawkowe;	
	liczbaNaglosnienia++;
	}
	
	//Metoda wyswietlajaca informacje o przedmiotach
	public void wyswietlInfo() {
	System.out.println("Naglosnienie wyprodukowal " + producent);
	System.out.println("Obudowa ma kolor " + kolor);
	System.out.println("W zestaw wchodzi " + iloscGlosnikow + " glosnikow");
	System.out.println("Mozna nim sterowac za pomoca zdalnego pilota " + sterowaniePilotem);
	System.out.println("Posiada wyjscie sluchawkowe " + wyjscieSluchawkowe);
	}
	
	//Metody wyswietlajace cechy i wlasciwosci przedmiotow
	public double wyswietlCechePierwsza() {
	System.out.println("\n Odtwarzam plik z glosnoscia: ");
	return glosnosc;
	}
	
	public double wyswietlCecheDruga() {
	System.out.println("\n Odtwarzam plik o jeden punkt glosniej: ");
	return glosnosc+1;
	}
	
	public double wyswietlCecheTrzecia() {
	System.out.println("\n Wyciszam: ");
	glosnosc = 0;
	return glosnosc;
	}
	
	//Metoda sprawdzajaca ile mamy Monitorow w bazie
	public static int ileNaglosnienia() {
		return liczbaNaglosnienia;
	}
	
	//Metody pobierajace dane z pol
	public String pobierzProducenta() {
		return producent;
	}
	
	public String pobierzKolor() {
		return kolor;
	}
	
	public double pobierzIloscGlosnikow() {
		return iloscGlosnikow;
	}
	
	public boolean pobierzSterowaniePilotem() {
		return sterowaniePilotem;
	}
	
	public boolean pobierzWyjscieSluchawkowe() {
		return wyjscieSluchawkowe;
	}
	
	//Metody zmieniajace dane w polach
	public void ustawProducenta(String nowy) {
		this.producent = nowy;
	}
	
	public void ustawKolor(String nowy) {
		this.kolor = nowy;
	}
	
	public void ustawIloscGlosnikow(double nowy) {
		this.iloscGlosnikow = nowy;
	}
	
	public void ustawSterowaniePilotem(boolean nowy) {
		this.sterowaniePilotem = nowy;
	}
	
	public void ustawWyjscieSluchawkowe(boolean nowy) {
		this.wyjscieSluchawkowe = nowy;
	}
	
	//Metoda trzecia - toString, dzieki ktorej mozemy wyswietlic na ekranie opis przedmiotu
	public String toString() {
		return "Producent: " + producent + "\n Kolor: " + kolor + "\n Ilosc glosnikow w zestawie: " + iloscGlosnikow + "\n Sterowanie pilotem: " + sterowaniePilotem + "\n Wyjscie sluchawkowe: " + wyjscieSluchawkowe;
	}
}