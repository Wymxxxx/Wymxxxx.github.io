/* 
 *
 * Uruchomienie: Nalezy skompilowac pliki Aparat.java, Drukarka.java, Monitor.java, oraz Naglosnienie.java, a nastepnie skompilowac i uruchomic plik Przedmioty.java LUB skompilowac i uruchomic plik Przedmioty.java
 * W IDE JCreator: kompilacja -> build -> build file, uruchomienie -> run -> run file
 *
 * Stworzono w: JCreator 5.00 Pro
 */
public class Przedmioty {
	
	public static void main(String args[]) {
		//Metoda pierwsza - konstruktory
		System.out.println("METODA PIERWSZA: \n");
		//********************************************************************************************************************************
		//Utworzenie dziesi�ciu konstruktowow dla dziesieciu przedmiotow - 5 przedmiotow x 2
		Drukarka drukarkaPierwsza = new Drukarka("HP", true, "A4", 12, true);
		Drukarka drukarkaDruga = new Drukarka("Canon", false, "A3", 13, true);

		Aparat aparatPierwszy = new Aparat("Kodak", 7, 8, true, 3);		
		Aparat aparatDrugi = new Aparat("Canon", 10, 32, true, 8);	
			
		Naglosnienie naglosnieniePierwsze = new Naglosnienie("Creative", "czarny", 5, false, true);	
		Naglosnienie naglosnienieDrugie = new Naglosnienie("Creative", "srebrny", 6, true, true);
		
		Monitor monitorPierwszy = new Monitor("BENQ", "P2062AM0W4N13", 19, false, false);	
		Monitor monitorDrugi = new Monitor("SIEMENS", "P2062AM0W4N13", 22, true, false);	
		
		//********************************************************************************************************************************
		//Wyswietlanie informacji o przedmiotach za pomoca metody .wyswietlInfo()
		drukarkaPierwsza.wyswietlInfo();
		System.out.println(" ");
		
		drukarkaDruga.wyswietlInfo();
		System.out.println(" ");
		
		aparatPierwszy.wyswietlInfo();
		System.out.println(" ");
		
		aparatDrugi.wyswietlInfo();
		System.out.println(" ");
		
		naglosnieniePierwsze.wyswietlInfo();
		System.out.println(" ");
		
		naglosnienieDrugie.wyswietlInfo();
		System.out.println(" ");
		
		monitorPierwszy.wyswietlInfo();
		System.out.println(" ");
		
		monitorDrugi.wyswietlInfo();
		//********************************************************************************************************************************
		//Cechy i wlasciwosci przedmiotow
		System.out.println("\nWLASCIWOSCI PRZEDMIOTOW: \n");
		
		//Wyswietlanie cech i wlasciwosci przedmiotow przez zastosowanie metod .wyswietlCechePierwsza(), .wyswietlCecheDruga(), .wyswietlCecheTrzecia()
		
		//Monitory
		System.out.println("\nMonitor pierwszy i drugi: ");
		System.out.println(monitorPierwszy.wyswietlCechePierwsza());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(monitorPierwszy.wyswietlCecheDruga());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(monitorPierwszy.wyswietlCecheTrzecia());
		System.out.println("Zakonczylem dzialanie \n");
		
		System.out.println(monitorDrugi.wyswietlCechePierwsza());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(monitorDrugi.wyswietlCecheDruga());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(monitorDrugi.wyswietlCecheTrzecia());
		System.out.println("Zakonczylem dzialanie \n");
		
		//Naglosnienie
		System.out.println("\nNaglosnienie pierwsze i drugie: ");
		System.out.println(naglosnieniePierwsze.wyswietlCechePierwsza());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(naglosnieniePierwsze.wyswietlCecheDruga());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(naglosnieniePierwsze.wyswietlCecheTrzecia());
		System.out.println("Zakonczylem dzialanie \n");
		
		System.out.println(naglosnienieDrugie.wyswietlCechePierwsza());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(naglosnienieDrugie.wyswietlCecheDruga());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(naglosnienieDrugie.wyswietlCecheTrzecia());
		System.out.println("Zakonczylem dzialanie \n");
		
		//Aparaty
		System.out.println("\nAparat pierwszy i drugi: ");
		System.out.println(aparatPierwszy.wyswietlCechePierwsza());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(aparatPierwszy.wyswietlCecheDruga());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(aparatPierwszy.wyswietlCecheTrzecia());
		System.out.println("Zakonczylem dzialanie \n");
		
		System.out.println(aparatDrugi.wyswietlCechePierwsza());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(aparatDrugi.wyswietlCecheDruga());
		System.out.println("Zakonczylem dzialanie \n");
		System.out.println(aparatDrugi.wyswietlCecheTrzecia());
		System.out.println("Zakonczylem dzialanie \n");
		
		//Drukarki
		System.out.println("\nDrukarka pierwsza i druga: ");
		System.out.println(drukarkaPierwsza.wyswietlCechePierwsza());
		System.out.println("Zakonczylam dzialanie \n");
		System.out.println(drukarkaPierwsza.wyswietlCecheDruga());
		System.out.println("Zakonczylam dzialanie \n");
		System.out.println(drukarkaPierwsza.wyswietlCecheTrzecia());
		System.out.println("Zakonczylam dzialanie \n");
		
		System.out.println(drukarkaDruga.wyswietlCechePierwsza());
		System.out.println("Zakonczylam dzialanie \n");
		System.out.println(drukarkaDruga.wyswietlCecheDruga());
		System.out.println("Zakonczylam dzialanie \n");
		System.out.println(drukarkaDruga.wyswietlCecheTrzecia());
		System.out.println("Zakonczylam dzialanie \n");
		
		//********************************************************************************************************************************
		//Podsumowanie iloci przedmiotow w bazie metodami .ileDrukarek(), .ileAparatow(), .ileDyskow(), .ileNaglosnienia(), .ileMonitorow()
		System.out.println("\nPodsumowanie przedmiotow w bazie: ");
		System.out.println(" ");
		System.out.println("Liczba drukarek: " + Drukarka.ileDrukarek());
		System.out.println("Liczba aparatow: " + Aparat.ileAparatow());
		System.out.println("Liczba naglosnienia: " + Naglosnienie.ileNaglosnienia());
		System.out.println("Liczba monitorow: " + Monitor.ileMonitorow());
		//********************************************************************************************************************************
		//Metoda druga - wyswietlanie informacji o przedmiotach za pomoca metod .pobierz[Pole]()
		
		//Drukarka pierwsza i druga
		System.out.println("\nMETODA DRUGA :");
		System.out.println(" ");
		System.out.println("Producent: " + drukarkaPierwsza.pobierzProducenta());
		System.out.println("Laserowa: " + drukarkaPierwsza.pobierzCzyLaserowa());
		System.out.println("Obslugiwany format papieru: " + drukarkaPierwsza.pobierzRodzajPapieru());
		System.out.println("Szybkosc druku: " + drukarkaPierwsza.pobierzSzybkoscDruku() + " stron na minute");
		System.out.println("WiFi: " + drukarkaPierwsza.pobierzWifi());
		
		System.out.println(" ");
		System.out.println("Producent: " + drukarkaDruga.pobierzProducenta());
		System.out.println("Laserowa: " + drukarkaDruga.pobierzCzyLaserowa());
		System.out.println("Obslugiwany format papieru: " + drukarkaDruga.pobierzRodzajPapieru());
		System.out.println("Szybkosc druku: " + drukarkaDruga.pobierzSzybkoscDruku() + " stron na minute");
		System.out.println("WiFi: " + drukarkaDruga.pobierzWifi());
		
		//Ustawianie nowych wartosci przedmiotow za pomoca metody ustaw[Pole](nowa wartosc)
		drukarkaPierwsza.ustawProducenta("Lexmark");
		drukarkaPierwsza.ustawCzyLaserowa(true);
		drukarkaPierwsza.ustawRodzajPapieru("A2");
		drukarkaPierwsza.ustawSzybkoscDruku(10);
		drukarkaPierwsza.ustawWifi(true);
		
		//Sprawdzenie wynikow dzialania metody
		System.out.println(" ");
		System.out.println("Producent: " + drukarkaPierwsza.pobierzProducenta());
		System.out.println("Laserowa: " + drukarkaPierwsza.pobierzCzyLaserowa());
		System.out.println("Obslugiwany format papieru: " + drukarkaPierwsza.pobierzRodzajPapieru());
		System.out.println("Szybkosc druku: " + drukarkaPierwsza.pobierzSzybkoscDruku() + " stron na minute");
		System.out.println("WiFi: " + drukarkaPierwsza.pobierzWifi());
		
		//Ustawianie nowych wartosci przedmiotow za pomoca metody ustaw[Pole](nowa wartosc)
		drukarkaDruga.ustawProducenta("Epson");
		drukarkaDruga.ustawCzyLaserowa(false);
		drukarkaDruga.ustawRodzajPapieru("A1");
		drukarkaDruga.ustawSzybkoscDruku(15);
		drukarkaDruga.ustawWifi(false);
		
		//Sprawdzenie wynikow dzialania metody
		System.out.println(" ");
		System.out.println("Producent: " + drukarkaDruga.pobierzProducenta());
		System.out.println("Laserowa: " + drukarkaDruga.pobierzCzyLaserowa());
		System.out.println("Obslugiwany format papieru: " + drukarkaDruga.pobierzRodzajPapieru());
		System.out.println("Szybkosc druku: " + drukarkaDruga.pobierzSzybkoscDruku() + " stron na minute");
		System.out.println("WiFi: " + drukarkaDruga.pobierzWifi());
		
		//Aparat pierwszy i drugi
		System.out.println(" ");
		System.out.println("Producent: " + aparatPierwszy.pobierzProducenta());
		System.out.println("Matryca: " + aparatPierwszy.pobierzMatryce() + " mega pikseli");
		System.out.println("Karta pamieci: " + aparatPierwszy.pobierzKartePamieci() + " GB");
		System.out.println("Stabilizator obrazu: " + aparatPierwszy.pobierzStabilizatorObrazu());
		System.out.println("Zoom optyczny x" + aparatPierwszy.pobierzZoom());
		
		System.out.println(" ");
		System.out.println("Producent: " + aparatDrugi.pobierzProducenta());
		System.out.println("Matryca: " + aparatDrugi.pobierzMatryce() + " mega pikseli");
		System.out.println("Karta pamieci: " + aparatDrugi.pobierzKartePamieci() + " GB");
		System.out.println("Stabilizator obrazu: " + aparatDrugi.pobierzStabilizatorObrazu());
		System.out.println("Zoom optyczny x" + aparatDrugi.pobierzZoom());
		
		//Ustawianie nowych wartosci przedmiotow za pomoca metody ustaw[Pole](nowa wartosc)
		aparatPierwszy.ustawProducenta("Canon");
		aparatPierwszy.ustawMatryce(8);
		aparatPierwszy.ustawKartePamieci(12);
		aparatPierwszy.ustawStabilizatorObrazu(false);
		aparatPierwszy.ustawZoom(6);
		
		//Sprawdzenie wynikow dzialania metody
		System.out.println(" ");
		System.out.println("Producent: " + aparatPierwszy.pobierzProducenta());
		System.out.println("Matryca: " + aparatPierwszy.pobierzMatryce() + " mega pikseli");
		System.out.println("Karta pamieci: " + aparatPierwszy.pobierzKartePamieci() + " GB");
		System.out.println("Stabilizator obrazu: " + aparatPierwszy.pobierzStabilizatorObrazu());
		System.out.println("Zoom optyczny x" + aparatPierwszy.pobierzZoom());
		
		//Ustawianie nowych wartosci przedmiotow za pomoca metody ustaw[Pole](nowa wartosc)
		aparatDrugi.ustawProducenta("HP");
		aparatDrugi.ustawMatryce(12);
		aparatDrugi.ustawKartePamieci(24);
		aparatDrugi.ustawStabilizatorObrazu(true);
		aparatDrugi.ustawZoom(10);
		
		//Sprawdzenie wynikow dzialania metody
		System.out.println(" ");
		System.out.println("Producent: " + aparatDrugi.pobierzProducenta());
		System.out.println("Matryca: " + aparatDrugi.pobierzMatryce() + " mega pikseli");
		System.out.println("Karta pamieci: " + aparatDrugi.pobierzKartePamieci() + " GB");
		System.out.println("Stabilizator obrazu: " + aparatDrugi.pobierzStabilizatorObrazu());
		System.out.println("Zoom optyczny x" + aparatDrugi.pobierzZoom());
		
		//Naglosnienie pierwsze i drugie
		System.out.println(" ");
		System.out.println("Producent: " + naglosnieniePierwsze.pobierzProducenta());
		System.out.println("Kolor: " + naglosnieniePierwsze.pobierzKolor());
		System.out.println("Ilosc glosnikow w zestawie: " + naglosnieniePierwsze.pobierzIloscGlosnikow());
		System.out.println("Sterowanie pilotem: " + naglosnieniePierwsze.pobierzSterowaniePilotem());
		System.out.println("Wyjscie sluchawkowe: " + naglosnieniePierwsze.pobierzWyjscieSluchawkowe());
		
		System.out.println(" ");
		System.out.println("Producent: " + naglosnienieDrugie.pobierzProducenta());
		System.out.println("Kolor: " + naglosnienieDrugie.pobierzKolor());
		System.out.println("Ilosc glosnikow w zestawie: " + naglosnienieDrugie.pobierzIloscGlosnikow());
		System.out.println("Sterowanie pilotem: " + naglosnienieDrugie.pobierzSterowaniePilotem());
		System.out.println("Wyjscie sluchawkowe: " + naglosnienieDrugie.pobierzWyjscieSluchawkowe());
		
		//Ustawianie nowych wartosci przedmiotow za pomoca metody ustaw[Pole](nowa wartosc)
		naglosnieniePierwsze.ustawProducenta("Logitech");
		naglosnieniePierwsze.ustawKolor("Zielone");
		naglosnieniePierwsze.ustawIloscGlosnikow(4);
		naglosnieniePierwsze.ustawSterowaniePilotem(true);
		naglosnieniePierwsze.ustawWyjscieSluchawkowe(true);
		
		//Sprawdzenie wynikow dzialania metody
		System.out.println(" ");
		System.out.println("Producent: " + naglosnieniePierwsze.pobierzProducenta());
		System.out.println("Kolor: " + naglosnieniePierwsze.pobierzKolor());
		System.out.println("Ilosc glosnikow w zestawie: " + naglosnieniePierwsze.pobierzIloscGlosnikow());
		System.out.println("Sterowanie pilotem: " + naglosnieniePierwsze.pobierzSterowaniePilotem());
		System.out.println("Wyjscie sluchawkowe: " + naglosnieniePierwsze.pobierzWyjscieSluchawkowe());
		
		//Ustawianie nowych wartosci przedmiotow za pomoca metody ustaw[Pole](nowa wartosc)
		naglosnienieDrugie.ustawProducenta("Creative");
		naglosnienieDrugie.ustawKolor("Biale");
		naglosnienieDrugie.ustawIloscGlosnikow(2);
		naglosnienieDrugie.ustawSterowaniePilotem(false);
		naglosnienieDrugie.ustawWyjscieSluchawkowe(false);
		
		//Sprawdzenie wynikow dzialania metody
		System.out.println(" ");
		System.out.println("Producent: " + naglosnienieDrugie.pobierzProducenta());
		System.out.println("Kolor: " + naglosnienieDrugie.pobierzKolor());
		System.out.println("Ilosc glosnikow w zestawie: " + naglosnienieDrugie.pobierzIloscGlosnikow());
		System.out.println("Sterowanie pilotem: " + naglosnienieDrugie.pobierzSterowaniePilotem());
		System.out.println("Wyjscie sluchawkowe: " + naglosnienieDrugie.pobierzWyjscieSluchawkowe());
		
		//Monitor pierwszy i drugi
		System.out.println(" ");
		System.out.println("Producent: " + monitorPierwszy.pobierzProducenta());
		System.out.println("Model: " + monitorPierwszy.pobierzModel());
		System.out.println("Przekatna: " + monitorPierwszy.pobierzPrzekatna() + " cali");
		System.out.println("Stereoskopowy: " + monitorPierwszy.pobierzStereoskopowy());
		System.out.println("PIVOT: " + monitorPierwszy.pobierzPivot());
		
		System.out.println(" ");
		System.out.println("Producent: " + monitorDrugi.pobierzProducenta());
		System.out.println("Model: " + monitorDrugi.pobierzModel());
		System.out.println("Przekatna: " + monitorDrugi.pobierzPrzekatna() + " cali");
		System.out.println("Stereoskopowy: " + monitorDrugi.pobierzStereoskopowy());
		System.out.println("PIVOT: " + monitorDrugi.pobierzPivot());
		
		//Ustawianie nowych wartosci przedmiotow za pomoca metody ustaw[Pole](nowa wartosc)
		monitorPierwszy.ustawProducenta("Manta");
		monitorPierwszy.ustawModel("A444");
		monitorPierwszy.ustawPrzekatna(21);
		monitorPierwszy.ustawStereoskopowy(false);
		monitorPierwszy.ustawPivot(false);
		
		//Sprawdzenie wynikow dzialania metody
		System.out.println(" ");
		System.out.println("Producent: " + monitorPierwszy.pobierzProducenta());
		System.out.println("Model: " + monitorPierwszy.pobierzModel());
		System.out.println("Przekatna: " + monitorPierwszy.pobierzPrzekatna() + " cali");
		System.out.println("Stereoskopowy: " + monitorPierwszy.pobierzStereoskopowy());
		System.out.println("PIVOT: " + monitorPierwszy.pobierzPivot());
		
		//Ustawianie nowych wartosci przedmiotow za pomoca metody ustaw[Pole](nowa wartosc)
		monitorDrugi.ustawProducenta("SIEMENS");
		monitorDrugi.ustawModel("GHD12");
		monitorDrugi.ustawPrzekatna(21);
		monitorDrugi.ustawStereoskopowy(true);
		monitorDrugi.ustawPivot(true);
		
		//Sprawdzenie wynikow dzialania metody
		System.out.println(" ");
		System.out.println("Producent: " + monitorDrugi.pobierzProducenta());
		System.out.println("Model: " + monitorDrugi.pobierzModel());
		System.out.println("Przekatna: " + monitorDrugi.pobierzPrzekatna() + " cali");
		System.out.println("Stereoskopowy: " + monitorDrugi.pobierzStereoskopowy());
		System.out.println("PIVOT: " + monitorDrugi.pobierzPivot());
		//********************************************************************************************************************************
		//Metoda trzecia - toString
		
		//Wyswietlanie informacji o przedmiotach dzieki toString
		System.out.println("\nMETODA TRZECIA: ");
		
		System.out.println(" ");
		System.out.println(drukarkaPierwsza);
		
		System.out.println(" ");
		System.out.println(drukarkaDruga);
		
		System.out.println(" ");
		System.out.println(aparatPierwszy);
		
		System.out.println(" ");
		System.out.println(aparatDrugi);
		
		System.out.println(" ");
		System.out.println(naglosnieniePierwsze);
		
		System.out.println(" ");
		System.out.println(naglosnienieDrugie);
		
		System.out.println(" ");
		System.out.println(monitorPierwszy);
		
		System.out.println(" ");
		System.out.println(monitorDrugi);
	}
}