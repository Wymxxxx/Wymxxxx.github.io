/* 
 *
 * Uruchomienie: Nalezy skompilowac pliki Aparat.java, Drukarka.java, Monitor.java, oraz Naglosnienie.java, a nastepnie skompilowac i uruchomic plik Przedmioty.java LUB skompilowac i uruchomic plik Przedmioty.java
 * W IDE JCreator: kompilacja -> build -> build file, uruchomienie -> run -> run file
 *
 * Stworzono w: JCreator 5.00 Pro
 */
class Aparat {
	
	//Deklaracja zmiennych
	private String producent;
	private double matryca;
	private double kartaPamieci;
	private boolean stabilizatorObrazu;
	private double zoom;
	
	//Zmienne potrzebne do opisywania cech przedmiotu
	private String zdjecie = "Click, click! \n";
	private double czas = 3;
	
	//Zmienna, do sprawdzenia ile Aparatow mamy w bazie	
	private static int liczbaAparatow;
	
	//Konstruktor do pierwszej metody
	public Aparat(String producent, double matryca, double kartaPamieci, boolean stabilizatorObrazu, double zoom) {
	this.producent = producent;
	this.matryca = matryca;
	this.kartaPamieci = kartaPamieci;
	this.stabilizatorObrazu = stabilizatorObrazu;
	this.zoom = zoom;	
	liczbaAparatow++;
	}
	
	//Metoda wyswietlajaca informacje o przedmiotach
	public void wyswietlInfo() {
	System.out.println("Aparat wyprodukowal " + producent);
	System.out.println("Posiada matryce " + matryca + " mega pikseli");
	System.out.println("Posiada karte pamieci " + kartaPamieci + " GB");
	System.out.println("Posiada stabilizator obrazu " + stabilizatorObrazu);
	System.out.println("Posiada Zoom Optyczny x" + zoom);
	}
	
	//Metody wyswietlajace cechy i wlasciwosci przedmiotow
	public String wyswietlCechePierwsza() {
	System.out.println("\n Robie zdjecie : ");
	return zdjecie;
	}
	
	public String wyswietlCecheDruga() {
	System.out.println("\n Robie piec zdjec: ");
	return zdjecie + zdjecie + zdjecie + zdjecie + zdjecie;
	}
	
	public double wyswietlCecheTrzecia() {
	System.out.println("\n Ustawiam czas samowyzwalacza na (sekundy): ");
	return czas*Math.random();
	}
	
	//Metoda sprawdzajaca ile mamy Aparatow w bazie
	public static int ileAparatow() {
		return liczbaAparatow;
	}
	
	//Metody pobierajace dane z pol
		public String pobierzProducenta() {
		return producent;
	}
	
	public double pobierzMatryce() {
		return matryca;
	}
	
	public double pobierzKartePamieci() {
		return kartaPamieci;
	}
	
	public boolean pobierzStabilizatorObrazu() {
		return stabilizatorObrazu;
	}
	
	public double pobierzZoom() {
		return zoom;
	}
	
	//Metody zmieniajace dane w polach
	public void ustawProducenta(String nowy) {
		this.producent = nowy;
	}
	
	public void ustawMatryce(double nowy) {
		this.matryca = nowy;
	}
	
	public void ustawKartePamieci(double nowy) {
		this.kartaPamieci = nowy;
	}
	
	public void ustawStabilizatorObrazu(boolean nowy) {
		this.stabilizatorObrazu = nowy;
	}
	
	public void ustawZoom(double nowy) {
		this.zoom = nowy;
	}
	
	//Metoda trzecia - toString, dzieki ktorej mozemy wyswietlic na ekranie opis przedmiotu
	public String toString() {
		return "Producent: " + producent + "\n Matryca: " + matryca + "\n Karta pamieci: " + kartaPamieci + " GB"+ "\n Stabilizator obrazu: " + stabilizatorObrazu + " Zoom optyczny x" + zoom;
	}
}