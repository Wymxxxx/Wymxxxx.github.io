/* 
 *
 * Uruchomienie: Nalezy skompilowac pliki Aparat.java, Drukarka.java, Monitor.java, oraz Naglosnienie.java, a nastepnie skompilowac i uruchomic plik Przedmioty.java LUB skompilowac i uruchomic plik Przedmioty.java
 * W IDE JCreator: kompilacja -> build -> build file, uruchomienie -> run -> run file
 *
 * Stworzono w: JCreator 5.00 Pro
 */	
class Monitor {
	
	//Deklaracja zmiennych
	private String producent;
	private String model;
	private double przekatna;
	private boolean stereoskopowy;
	private boolean pivot;
	
	//Zmienne potrzebne do opisywania cech przedmiotu
	private String tekst = "Pracownia Programowania";
	
	//Zmienna, do sprawdzenia ile Monitorow mamy w bazie
	private static int liczbaMonitorow;
	
	//Konstruktor do pierwszej metody
	public Monitor(String producent, String model, double przekatna, boolean stereoskopowy, boolean pivot) {
	this.producent = producent;
	this.model = model;
	this.przekatna = przekatna;
	this.stereoskopowy = stereoskopowy;
	this.pivot = pivot;	
	liczbaMonitorow++;
	}
	
	//Metoda wyswietlajaca informacje o przedmiotach
	public void wyswietlInfo() {
	System.out.println("Monitor wyprodukowal " + producent);
	System.out.println("Jest to model " + model);
	System.out.println("Posiada przekatna " + przekatna + " cali");
	System.out.println("Obsluguje obraz 3D " + stereoskopowy);
	System.out.println("Posiada funkcje PIVOT " + pivot);
	}
	
	//Metody wyswietlajace cechy i wlasciwosci przedmiotow
	public String wyswietlCechePierwsza() {
	System.out.println("\n Wyswietlam tekst: ");
	return tekst;
	}
	
	public String wyswietlCecheDruga() {
	System.out.println("\n Wyswietlam tekst malymi literami: ");
	return tekst.toLowerCase();
	}
	
	public String wyswietlCecheTrzecia() {
	System.out.println("\n Wyswietlam tekst duzymi literami: ");
	return tekst.toUpperCase();
	}
	
	//Metoda sprawdzajaca ile mamy Monitorow w bazie
	public static int ileMonitorow() {
		return liczbaMonitorow;
	}
	
	//Metody pobierajace dane z pol
	public String pobierzProducenta() {
		return producent;
	}
	
	public String pobierzModel() {
		return model;
	}
	
	public double pobierzPrzekatna() {
		return przekatna;
	}
	
	public boolean pobierzStereoskopowy() {
		return stereoskopowy;
	}
	
	public boolean pobierzPivot() {
		return pivot;
	}
	
	//Metody zmieniajace dane w polach
	public void ustawProducenta(String nowy) {
		this.producent = nowy;
	}
	
	public void ustawModel(String nowy) {
		this.model = nowy;
	}
	
	public void ustawPrzekatna(double nowy) {
		this.przekatna = nowy;
	}
	
	public void ustawStereoskopowy(boolean nowy) {
		this.stereoskopowy = nowy;
	}
	
	public void ustawPivot(boolean nowy) {
		this.pivot = nowy;
	}
	
	//Metoda trzecia - toString, dzieki ktorej mozemy wyswietlic na ekranie opis przedmiotu
	public String toString() {
		return "Producent: " + producent + "\n Model: " + model + "\n Przekatna: " + przekatna + " cali" + "\n Stereoskopowy obraz: " + stereoskopowy + "\n Funkcja PIVOT: " + pivot;
	}
	
	
	
	}