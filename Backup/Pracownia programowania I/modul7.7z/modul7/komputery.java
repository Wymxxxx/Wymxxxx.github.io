public class Komputery 
{  
	private String marka;
	private Procesor procesor;
	private int pamiec;
	
	public Komputery(String marka, String procesor, double taktowanie, int pamiec)
	{
		this.marka = marka;
		this.procesor = new Procesor(procesor,taktowanie);
		this.pamiec = pamiec;
	}
	
	class Procesor
	{
		private String marka;
		private double taktowanie;
		private double zajetaPamiec;
		
		public Procesor(String marka, double taktowanie)
		{
			this.marka = marka;
			this.taktowanie = taktowanie;
			zajetaPamiec = 0;
		}
		
		public void rezerwujPamiec(int ilosc)
		{
			zajetaPamiec+=ilosc;
			System.out.println("Zarezerwowano " + ilosc + "mb pami�ci");
		}
		public void zwolnijPamiec(int ilosc)
		{
			zajetaPamiec-=ilosc;
			System.out.println("Zwolniono " + ilosc + "mb pami�ci");
		}
		
		public String toString()
		{
			return "Procesor " + marka + " " + taktowanie + "Ghz \nPami�ci w u�yciu: " + zajetaPamiec +"mb z dost�pnych " + pamiec + "mb";
		}
	}
	
	public String toString()
	{
		return "Komputer firmy: " + marka + "\n" + procesor;
	}
	
    public static void main(String[] args) 
    {
        Komputery komp1 = new Komputery("Dell","Pentium core2duo",2.66,2048);
        Komputery komp2 = new Komputery("Acer","Amd Athlon X2",2.5,1024);
        komp1.procesor.rezerwujPamiec(256);
        System.out.println(komp1);
        System.out.println(komp2);
    }
}
