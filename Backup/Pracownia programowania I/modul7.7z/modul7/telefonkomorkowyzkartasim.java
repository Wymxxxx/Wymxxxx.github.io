public class TelefonKomorkowyZKartaSim 
{
	private KartaSIM sim;
	
	public TelefonKomorkowyZKartaSim(String numer) 
	{
		sim = new KartaSIM(numer);
	}

	class KartaSIM 
	{
		private String numerTelefonu;
		
		public KartaSIM(String numer) 
		{
			numerTelefonu = numer;
		}
		
		public String pobierzNumerTelefonu() 
		{
			return numerTelefonu;
		}
	}
	
	public String toString()
	{
		return "Telefon z karta SIM o numerze: " + sim.pobierzNumerTelefonu();
	}
	
	public static void main (String[] args) 
	{	
		TelefonKomorkowyZKartaSim telefonMarcina = new TelefonKomorkowyZKartaSim("507864934");
		TelefonKomorkowyZKartaSim telefonKasi = new	TelefonKomorkowyZKartaSim("679342123");
		System.out.println(telefonMarcina);
		System.out.println(telefonKasi);
	}
}
