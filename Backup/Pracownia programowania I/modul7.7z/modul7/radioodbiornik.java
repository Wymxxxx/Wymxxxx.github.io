interface Wlacza 
{
	public void wlacz();
	public void wylacz();
	public boolean czyDziala();
}

class Radio implements Wlacza
{
	private boolean dziala;
	private String marka;
	private double czestotliwosc;
	private int glosnosc;
	
	public Radio(String marka, double czestotliwosc)
	{
		this.marka = marka;
		this.czestotliwosc = czestotliwosc;
		glosnosc = 10;
		dziala = false;
	}
	
	public void wlacz()
	{
		dziala = true;
	}
	public void wylacz()
	{
		dziala = false;
	}
	public boolean czyDziala() 
	{
		return dziala;
	}
	public void glosniej()
	{
		glosnosc++;
	}
	public void ciszej()
	{
		glosnosc--;
	}
	public String toString() 
	{
		return "Radioodbiornik marki: " + marka + " jest " +	( czyDziala() ? "w��czony" : "wy��czony") +
				 "\nAktualna Cz�stotliwo�� " + czestotliwosc + "\nG�o�no��: " + glosnosc;
	}
}

public class RadioOdbiornik 
{
    public static void main(String[] args) 
    {
        Radio unitra = new Radio("Unitra",92.3);
		unitra.wlacz();
		unitra.glosniej();
		System.out.println(unitra);
    }
}
