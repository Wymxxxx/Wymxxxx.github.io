interface Wlacza 
{
	public void wlacz();
	public void wylacz();
	public boolean czyDziala();
}
interface Odtwarza 
{
	public void start();
	public void stop();
	public void pauza();
}
abstract class Odtwarzacz implements Wlacza, Odtwarza 
{
	protected int glosnosc;
	private boolean dziala;
	protected String marka;
	
	public Odtwarzacz(String marka)
	{
		this.marka = marka;
		dziala = false;
	}
	
	public void wlacz()
	{
		dziala = true;
	}
	public void wylacz()
	{
		dziala = false;
	}
	public boolean czyDziala() 
	{
		return dziala;
	}
	public abstract void glosniej();
	public abstract void ciszej();
}
class OdtwarzaczCD extends Odtwarzacz 
{
	public OdtwarzaczCD (String marka)
	{
		super(marka);
		glosnosc = 10;
	}
	
	public void glosniej()
	{
		glosnosc++;
	}
	public void ciszej()
	{
		glosnosc--;
	}
	public void start()
	{
		System.out.println("Odtwarzacz CD odtwarza");
	}
	public void stop()
	{
		System.out.println ("Odtwarzacz CD nie odtwarza");
	}
	public void pauza()
	{
		System.out.println ("Odtwarzacz CD zatrzymany");
	}
	public String toString() 
	{
		return "Odtwarzacz CD marki: " + marka + " jest " +	( czyDziala() ? "w��czony" : "wy��czony") + "\nG�o�no��: " + glosnosc;
	}
}
public class UrzadzeniaMuzyczne 
{
	public static void main (String[] args) 
	{
		OdtwarzaczCD sony = new OdtwarzaczCD("Sony");
		sony.wlacz();
		sony.start();
		sony.glosniej();
		System.out.println (sony);
	}
}