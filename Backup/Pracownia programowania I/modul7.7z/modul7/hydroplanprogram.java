interface Plywa 
{
	public void plyn();
}

interface Lata 
{
	public void lec();
}

class Hydroplan implements Plywa,Lata 
{
	public void plyn()
	{
		System.out.println ("Hydroplan p�ynie");
	}
	public void lec()
	{
		System.out.println ("Hydroplan leci");
	}
}

public class HydroplanProgram 
{
	public static void main (String[] args)
	{
		Hydroplan hydroplan = new Hydroplan();
		hydroplan.lec();
		hydroplan.plyn();
	}
}

