interface Wlacza 
{
	public void wlacz();
	public void wylacz();
	public boolean czyDziala();
}
interface Odtwarza 
{
	public void start();
	public void stop();
	public void pauza();
}
abstract class Odtwarzacz implements Wlacza, Odtwarza 
{
	protected int glosnosc;
	private boolean dziala;
	protected String marka;
	
	public Odtwarzacz(String marka)
	{
		this.marka = marka;
		dziala = false;
	}
	
	public void wlacz()
	{
		dziala = true;
	}
	public void wylacz()
	{
		dziala = false;
	}
	public boolean czyDziala() 
	{
		return dziala;
	}
	public abstract void glosniej();
	public abstract void ciszej();
}
class OdtwarzaczCD extends Odtwarzacz 
{
	public OdtwarzaczCD (String marka)
	{
		super(marka);
		glosnosc = 10;
	}
	
	public void glosniej()
	{
		glosnosc++;
	}
	public void ciszej()
	{
		glosnosc--;
	}
	public void start()
	{
		System.out.println ("Odtwarzacz CD odtwarza");
	}
	public void stop()
	{
		System.out.println ("Odtwarzacz CD nie odtwarza");
	}
	public void pauza()
	{
		System.out.println ("Odtwarzacz CD zatrzymany");
	}
	public String toString() 
	{
		return "Odtwarzacz CD marki: " + marka + " jest " +	( czyDziala() ? "w��czony" : "wy��czony") + "\nG�o�no��: " + glosnosc;
	}
}
class OdtwarzaczMp3 extends Odtwarzacz 
{
	private int pojemnosc;
	private int bateria;
	public OdtwarzaczMp3(String marka, int pojemnosc, int bateria)
	{
		super(marka);
		this.pojemnosc = pojemnosc;
		this.bateria = bateria;
		glosnosc = 10;
	}
	
	public void glosniej()
	{
		glosnosc++;
	}
	public void ciszej()
	{
		glosnosc--;
	}
	public void start()
	{
		System.out.println ("Odtwarzacz Mp3 odtwarza");
	}
	public void stop()
	{
		System.out.println ("Odtwarzacz Mp3 nie odtwarza");
	}
	public void pauza()
	{
		System.out.println ("Odtwarzacz Mp3 zatrzymany");
	}
	public String toString() 
	{
		return "Odtwarzacz Mp3 marki: " + marka + " o pojemno�ci " + pojemnosc + " jest " + ( czyDziala() ? "w��czony" : "wy��czony")  + "\nStan Baterii: " + bateria + "\nG�o�no��: "
			 + glosnosc;
	}
}

public class NoweUrzadzenieMuzyczne 
{
	public static void main (String[] args) 
	{
		OdtwarzaczMp3 creative = new OdtwarzaczMp3("Creative",1024,4);
		creative.wlacz();
		creative.start();
		creative.glosniej();
		System.out.println(creative);
	}
}