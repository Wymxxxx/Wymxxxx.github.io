import java.util.Scanner;
public class LiczbaSlownie 
{
   public static void main(String[] args) 
   	{
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj dowoln� liczb� naturaln�: ");
        String liczba = wprowadzono.nextLine();
        String[] cyfry = {"zero","jeden","dwa","trzy","cztery","pi��","sze��","siedem","osiem","dziewi��"};
        String[] liczbaSlownie = new String[100];
        for(int i=0; i<liczba.length(); i++)
        {
        	String cyferka = liczba.substring(i,i+1);
        	int cyfereczka = Integer.parseInt(cyferka);
        	for(int a=0; a<10; a++)
        	{
        		if(a==cyfereczka)
        		{
        			liczbaSlownie[i] = cyfry[a];
        			break;
        		}
        	}
        	System.out.print(liczbaSlownie[i] + " ");
        }
    }
}
