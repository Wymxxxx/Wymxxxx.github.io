import java.util.Scanner;
public class Monety 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        int kwota;
        do
        {
        	System.out.print("Podaj kwot� w z� (1...1000): ");
        	kwota = wprowadzono.nextInt();
        }
        while (kwota<1 || kwota>1000);
        System.out.println("-----------------------");
        System.out.println("monety 5z�: " + kwota/5);
        System.out.println("monety 2z�: " + (kwota%5)/2);
        System.out.println("monety 1z�: " + (kwota%5)%2);
    }
}
