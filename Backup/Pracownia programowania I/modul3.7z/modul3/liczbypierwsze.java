import java.util.Scanner;
public class LiczbyPierwsze 
{
	public static void main(String[] args) 
	{
        Scanner wprowadzone = new Scanner(System.in);
        System.out.println("Ile liczb pierwszych wy�wietli�? ");
        int ilosc = wprowadzone.nextInt();
        int[] liczbyPierwsze = new int[ilosc];
        boolean ok = true;
        int znalezioneLiczby = 0;
        for (int i=2; znalezioneLiczby<ilosc; i++)
        {
        	for (int j=2; j<((i/2)+1); j++)
        	{
        		if(i%j==0)
        		{
        			ok = false;
        		}
        	}
        	if(ok)
        	{
        		liczbyPierwsze[znalezioneLiczby] = i; 
        		znalezioneLiczby++;
        	}
        	ok = true;
        }
        for (int liczbaPierwsza : liczbyPierwsze)
        {
        	System.out.print(liczbaPierwsza + " ");
        }
    }
}
