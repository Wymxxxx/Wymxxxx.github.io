import java.util.Scanner;
public class AnalizaWyrazow 
{
    public static void main(String[] args) 
    {
    	Scanner wprowadzono = new Scanner(System.in);
    	System.out.println("Wprowad� jaki� tekst ");
    	String tekst = wprowadzono.nextLine();
        String[] slowa = tekst.split(" ");
    	for (String slowo : slowa)
    	{
    		System.out.println(slowo); 
    	}
    }
}
