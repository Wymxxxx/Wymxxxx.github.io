import java.util.Random;
public class GeneratorHasel 
{
    public static void main(String[] args) 
    {
        Random generator = new Random();
        String[] samogloski = {"e","y","u","i","o","a"};
        String[] spolgloski = {"q","w","r","t","p","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m"};
        for(int i=0; i<3; i++)
        {
        	String spolgloska = spolgloski[generator.nextInt(spolgloski.length)];
        	System.out.print(spolgloska);
        	
        	String samogloska = samogloski[generator.nextInt(samogloski.length)];
        	System.out.print(samogloska);
        }
    }
}
