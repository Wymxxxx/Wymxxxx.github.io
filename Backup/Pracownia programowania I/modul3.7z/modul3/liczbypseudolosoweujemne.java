import java.util.Random;
public class LiczbyPseudolosoweUjemne 
{
	public static void main(String[] args)
	{
		Random generator = new Random();
		for(int i=1; i<=20; i++)
		{
			int liczba = generator.nextInt((-5)-(-20))-20;
		 	System.out.println("O to liczba: " + liczba);
		}
	}
}