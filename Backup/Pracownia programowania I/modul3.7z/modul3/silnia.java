import java.util.Scanner;
public class Silnia 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj liczb� naturaln� mniejsz� lub r�wn� 20 kt�rej silnie chcesz obliczy�:");
        int liczba = wprowadzono.nextInt();
        long silnia = 1;
        for (int i=1; i<=liczba; i++)
        {
        	silnia *= i;
        }
        System.out.println("Silnia liczby: " + liczba + " wynosi: " + silnia);
    }
}
