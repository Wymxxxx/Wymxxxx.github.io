public class TabliczkaMnozenia 
{
    public static void main(String[] args) 
    {
        int liczba1,liczba2;
    	for (liczba1 = 1; liczba1 <= 12; liczba1++) 
    	{
        	for (liczba2 = 1; liczba2 <= 12; liczba2++) 
        	{
            	int cyfra = liczba1*liczba2;
            	System.out.printf("%4d",cyfra);
             	if (liczba1*liczba2 == liczba1*12) 
             	{
                	System.out.println(" ");
             	}
         	}
   		}
    }
} 