import java.util.Scanner;
public class PodatekDochodowy 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj kwote swojego rocznego wynagrodzenia Brutto: ");
        double wynagrodzenie = Double.parseDouble(wprowadzono.nextLine());
        if(wynagrodzenie <= 43405)
        {
        	double podatek = ((wynagrodzenie * 0.19) - 572.54);
        	System.out.println("Musisz zap�aci�: " + podatek + "z� podatku dochodowego");
        }
        else if(wynagrodzenie <= 85528)
        {
        	double podatek = (7674.41 + ((wynagrodzenie - 43405) * 0.3));
        	System.out.println("Musisz zap�aci�: " + podatek + "z� podatku dochodowego");
        }
        else
        {
        	double podatek = (20311.31 + ((wynagrodzenie - 85528) * 0.4));
        	System.out.println("Musisz zap�aci�: " + podatek + "z� podatku dochodowego");
        }
    }
}
