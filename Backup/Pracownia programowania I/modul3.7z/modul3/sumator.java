import java.util.Scanner;
public class Sumator 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Wprowad� kolejne liczby kt�re chcesz doda�, aby zako�czy� wpisywanie naci�nij 0");
        double[] liczby = new double[100];
        double suma = 0;
        for (int i=0; i<100; i++)
        {
        	System.out.print("Wprowad� liczb�: ");
        	liczby[i] = wprowadzono.nextDouble();
        	if (liczby[i]==0)
        	{
        		break;
        	}
        	suma+=liczby[i];
        }
        System.out.println("Suma wprowadzonych przez Ciebie liczb to: " + suma);
    }
}
