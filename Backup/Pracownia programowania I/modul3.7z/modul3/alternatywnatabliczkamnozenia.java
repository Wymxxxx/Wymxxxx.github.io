public class AlternatywnaTabliczkaMnozenia 
{
    public static void main(String[] args) 
    {
        int liczba1 = 1;
        int liczba2 = 1;
    	while (liczba1 <= 12) 
    	{
        	while (liczba2 <= 12) 
        	{
            	int cyfra = liczba1*liczba2;
            	System.out.printf("%4d",cyfra);
             	if (liczba1*liczba2 == liczba1*12) 
             	{
                	System.out.println(" ");
             	}
             	liczba2++;
         	}
         	liczba2 = 1;
         	liczba1++;
   		}
    }
} 
