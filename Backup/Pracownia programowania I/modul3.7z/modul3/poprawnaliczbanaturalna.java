import java.util.Scanner;
public class PoprawnaLiczbaNaturalna 
{
	public static void main(String[] args) 
	{
		Scanner wprowadzono = new Scanner(System.in);
		System.out.println("Wprowad� liczb� naturaln�: ");
		String liczba = wprowadzono.nextLine();
		boolean liczbaOk = true;
		for (int i=0; i<liczba.length(); i++)
		{
			char znak = liczba.charAt(i);
			if(!Character.isDigit(znak))
			{
				liczbaOk = false;
			}
		}
		if(liczbaOk)
		{
			System.out.println("Liczb� wprowadzono prawid�owo");
		}
		else
		{
			System.out.println("Liczb� wprowadzono nieprawid�owo");
		}
	}
}
