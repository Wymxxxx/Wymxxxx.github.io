import java.util.Scanner;
import java.util.Random;
public class SymulatorRzutuKostka 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        Random generator = new Random();
        System.out.println("Ile rzut�w zasymulowa�? ");
        int ilosc = wprowadzono.nextInt();
        int[] liczebnosc = {0,0,0,0,0,0};
        for (int i=1; i<=ilosc; i++)
        {
        	int rzut = generator.nextInt(7-1)+1;
        	switch(rzut)
        	{
        		case 1:
        			liczebnosc[0]++;
        			break;
        		case 2:
        			liczebnosc[1]++;
        			break;
        		case 3:
        			liczebnosc[2]++;
        			break;
        		case 4:
        			liczebnosc[3]++;
        			break;
        		case 5:
        			liczebnosc[4]++;
        			break;
        		case 6:
        			liczebnosc[5]++;
        			break;
        	}
        }
        System.out.println("Rezultat " + ilosc + " rzut�w kostk�");
        System.out.println("=============================");
        System.out.println("  Liczba Oczek  |  Liczebno��");
        System.out.println("-----------------------------");
        for(int i=0; i<6; i++)
        {
        	System.out.println("       " + (i+1) + "        |    " + liczebnosc[i]);
        }
    }
}
