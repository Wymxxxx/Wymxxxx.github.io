import java.util.Scanner;
public class ProstyKalkulator 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.print("Podaj pierwsz� liczb�:");
        double liczba1 = wprowadzono.nextDouble();
        System.out.print("Podaj drug� liczb�:");
        double liczba2 = wprowadzono.nextDouble();
        System.out.print("Podaj operator:");
        String operator = wprowadzono.next();
        if (operator.equals("+"))
        {
        	System.out.println("Wynik: " + (liczba1+liczba2));
        }
        else if (operator.equals("-"))
        {
        	System.out.println("Wynik: " + (liczba1-liczba2));
        }
        else if (operator.equals("*"))
        {
        	System.out.println("Wynik: " + (liczba1*liczba2));
        }
        else if(operator.equals("/"))
        {
        	System.out.println("Wynik: " + (liczba1/liczba2));
        }
        else
        {
        	System.out.println("Poda�e� z�y operator!");
        }
    }
}
