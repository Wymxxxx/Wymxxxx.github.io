import java.util.Scanner;
enum DaneOsobowe {NAZWISKO,IMIE,ADRES,KOD_POCZTOWY,MIEJSCOWO��};
public class KartotekaPersonalna 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        int liczbaElementowKartoteki = DaneOsobowe.values().length;
        String[] kartoteka = new String[liczbaElementowKartoteki];
        System.out.println("Wprowad� dane personalne");
        for (DaneOsobowe poleDanych : DaneOsobowe.values())
        {
        	System.out.println(poleDanych+": ");
        	kartoteka[poleDanych.ordinal()]=wprowadzono.nextLine();
        }
        System.out.println("\nDANE PERSONALNE");
        System.out.printf("%s %s, %s %s, %s\n",
        					kartoteka[DaneOsobowe.IMIE.ordinal()],
        					kartoteka[DaneOsobowe.NAZWISKO.ordinal()],
        					kartoteka[DaneOsobowe.KOD_POCZTOWY.ordinal()],
        					kartoteka[DaneOsobowe.MIEJSCOWO��.ordinal()],
        					kartoteka[DaneOsobowe.ADRES.ordinal()]);
    }
}
