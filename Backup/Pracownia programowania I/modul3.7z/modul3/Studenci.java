/*
 * Nazwa: Studenci
 * 
 * Uruchomienie: 
 *
 * cmd.exe:
 * Kompilacja poleceniem javac Studenci.java
 * Uruchomienie poleceniem java Studenci imie nazwisko wzrost waga
 */
 
//Import klas bibliotecznych
import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;

public class Studenci {
	public static void main(String[] args)
	{
//********************************Imie i nazwisko studenta (pierwsze litery wielkie, pozostale male)********************

	//Deklaracja zmiennych
	String imie, nazwisko;
	//Przypisanie wartosci parametrow do zmiennych
	imie = args[0]; //Pierwszy parametr
	nazwisko = args[1]; //Drugi parametr
	
	//Zamiana typ�w
    double wzrost = Double.valueOf(args[2]);//Wzrost, musi byc typu double, nie string
    double waga = Double.valueOf(args[3]);//Waga rowniez musi byc typu double
	
	//Funkcja zamieniaj�ca pierwsz� litere imienia na wielka
	imie = imie.substring(0,1).toUpperCase() + imie.substring(1);
	//Wyswietlenie imienia
	System.out.println("Imie studenta: " + imie);

	//Funkcja zamieniajaca pierwsza litere nazwiska na wielka
	nazwisko = nazwisko.substring(0,1).toUpperCase() + nazwisko.substring(1);
	//Wyswietlenie nazwiska
	System.out.print("Nazwisko studenta: " + nazwisko);
	
	System.out.println(" ");
	
//******************************************************KONIEC*********************************************************

//********************************Inicjaly (pierwsza litera imienia i pierwsza litere nazwiska)************************

	//Funkcja wyswietlajaca pierwsze litery imienia i nazwiska (wielka litera)  inicjaly
	System.out.println("Inicjaly: " + imie.substring(0,1).toUpperCase() + nazwisko.substring(0,1).toUpperCase());
	
	System.out.println(" ");
	
//******************************************************KONIEC*********************************************************
	
//********************************Sprawdzenie plci studenta************************************************************

	//Instrukcja warunkowa sprawdzajaca plec studenta (imiona kobiece zakonczone sa znakiem "a")
	if(imie.endsWith("a"))
		{
		System.out.println("Plec: kobieta"); //Student jest kobieta
		}
	else
		{
		System.out.println("Plec: mezczyzna"); //Student jest mezczyzna
	}
	
	System.out.println(" ");

//******************************************************KONIEC*********************************************************

//********************************Wzrost studenta w centymetrach, metrach, stopach i calach****************************

	System.out.print("WZROST: ");
	System.out.println(" ");
	
	//Wyswietlanie wzrostu w centymetrach
	System.out.print("w centymetrach: " + wzrost);
	
	System.out.println(" ");
	
	//Przeliczenie wzrostu z centymetrow na metry i wyswietlenie wyliczonej wartosci
	System.out.println("w metrach: " + wzrost/100);
	
	//Przeliczenie wzrostu z centymetrow na stopy i wyswietlenie wyliczonej wartosci
	System.out.println("w stopach: " + wzrost / 30.48);
	
	//Przeliczenie wzrostu z centymetrow na cale i wyswietlenie wartosci
	System.out.println("w calach: " + wzrost / 2.54);
	
	System.out.println(" ");

//******************************************************KONIEC*********************************************************

//********************************Waga studenta w kilogramach i funtach************************************************

	System.out.println("WAGA: ");
	
	//Wyswietlanie wagi w kilogramach
	System.out.println("w kilogramach: " + waga);

	//Przeliczenie wagi z kilogramow na funty i wyswietlenie wyliczonej wartosci
	System.out.println("w funtach: " + waga*2.20462262);
	
//******************************************************KONIEC*********************************************************

//********************************Szacowanie BMI***********************************************************************

	//Zamiana centymetrow na metry - potrzebne do wyliczenia indeksu masy ciala BMI
	wzrost = wzrost / 100;
	//Deklaracja zmiennej BMI
	double BMI;
	//Wzor na indeks masy ciala BMI
	BMI = waga / (wzrost * wzrost);
	
	System.out.println(" ");
	
	//Wyswietlenie wartosci BMI
	System.out.println("Twoj wskaznik masy ciala BMI wynosi: " + BMI);
	//Instrukcja warunkowa sprawdzajaca indeks masy ciala studenta (wartosci graniczne pobrane z http://pl.wikipedia.org/wiki/Body_Mass_Index)
		if(BMI<18.5){
		System.out.println("i jest nieprawidlowy! Masz niedowage!"); //Student ma niedowage
	}
		else if(BMI>25)
		{
			System.out.println("i jest nieprawidlowy! Masz nadwage!"); //Student ma nadwage			
		}
		else
		{
			System.out.println("i jest prawidlowy!"); //Wartosc indeksu masy ciala jest prawidlowa
		}
		
//******************************************************KONIEC*********************************************************

//********************************Losowanie ulubionego dnia************************************************************

		System.out.println(" ");
		//Lista dni tygodnia
		String[] array = {"Poniedzialek","Wtorek","Sroda", "Czwartek", "Piatek", "Sobota", "Niedziela"};
		//Wyswietlenie losowego dnia tygodnia
		System.out.println("Szczesliwy dzien tygodnia: " + array[new Random().nextInt(array.length)]);
		
//******************************************************KONIEC*********************************************************

//********************************Wczytywanie i sortowanie przedmiot�w*************************************************

		Scanner klawiatura = new Scanner(System.in);
		
		//Deklaracja zmiennych
		String przedmiot1, przedmiot2, przedmiot3, przedmiot4;
		
		//Zaczynamy wczytywac z klawiatury przedmioty
		System.out.println("Podaj pierwszy przedmiot: ");
		przedmiot1 = klawiatura.nextLine();
		System.out.println("Podaj drugi przedmiot: ");
		przedmiot2 = klawiatura.nextLine();
		System.out.println("Podaj trzeci przedmiot: ");
		przedmiot3 = klawiatura.nextLine();
		System.out.println("Podaj czwarty przedmiot: ");
		przedmiot4 = klawiatura.nextLine();
		
		//Tworzymy tablice
		String[] przedmioty = {przedmiot1, przedmiot2, przedmiot3, przedmiot4};
		//Sortujemy ja
		Arrays.sort(przedmioty);
		//Wyswietlamy posortowane przedmioty	
		System.out.println("Przedmioty w kolejnosci alfabetycznej: " + Arrays.toString(przedmioty));
		
//******************************************************KONIEC*********************************************************
		}
	}
