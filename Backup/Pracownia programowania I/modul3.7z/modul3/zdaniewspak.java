import java.util.Scanner;
public class ZdanieWspak 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Wprowad� zdanie: ");
        String zdanie = wprowadzono.nextLine();
        System.out.println("Oto zdanie kt�re wprowadzi�e� napisane wspak: ");
        for(int i=zdanie.length()-1; i>=0; i--)
        {
        	System.out.print(zdanie.charAt(i));
        }
    }
}
