import java.util.Scanner;
public class AlgorytmEuklidesa 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Algorytm Euklidesa pozwalaj�cy wyznaczy� Najwi�kszy Wsp�lny Dzielnik dla dw�ch dowolnych liczb naturalnych \nPodaj pierwsz� liczb�: ");
        int liczba1 = wprowadzono.nextInt();
        System.out.println("Podaj drug� liczb�: ");
        int liczba2 = wprowadzono.nextInt();
        int a,b,c;
        if(liczba1>=liczba2)
        {
        	a = liczba1;
        	b = liczba2;
        }
        else
        {
        	a = liczba2;
        	b = liczba1;
        }
        for(int i=0; b != 0; i++)
        {
           c = a%b;        
           a = b;
           b = c;
        }
        System.out.println("Najwi�kszym Wsp�lnym Dzielnikiem liczb " + liczba1 + " i " + liczba2 + " jest liczba " + a);
    }
}
