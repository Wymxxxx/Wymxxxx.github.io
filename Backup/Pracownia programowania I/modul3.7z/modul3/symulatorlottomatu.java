import java.util.Random;
import java.util.Scanner;
public class SymulatorLottomatu 
{
    public static void main(String[] args) 
    {
    	Random generator = new Random();
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Ile zak�ad�w chcesz pu�ci�? ");
        int ilosc = wprowadzono.nextInt();
        int[] zaklad = new int[6];
        System.out.println("  ZAK�ADY DU�EGO LOTKA");
        System.out.println("=======================");
        for (int i=1; i<=ilosc; i++)
        {
        	System.out.printf("%2d %2s",i,"/ ");
        	for (int liczba:zaklad)
       		{
       			liczba = generator.nextInt(50-1)+1;
       			System.out.printf("%3d",liczba);
       		}
       		System.out.println("");
        }
    }
}
