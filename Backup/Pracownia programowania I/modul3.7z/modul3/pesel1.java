import java.util.Scanner;
public class pesel1
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Wprowad� numer Pesel: ");
        String pesel = wprowadzono.nextLine();
        boolean poprawnosc = true;
        int[] wagi = {1,3,7,9,1,3,7,9,1,3,1};
        int suma = 0;
        int waga = 0;
        if(pesel.length()!=11)
        {
        	poprawnosc = false;
        }
        char cyfraKontrolna = pesel.charAt(10);
        if(!Character.isDigit(cyfraKontrolna))
        {
        	poprawnosc = false;
        }
       for(int i=0; i<10; i++)
        {
        	char cyfra = pesel.charAt(i);
        	if(!Character.isDigit(cyfra))
        	{
        		poprawnosc = false;
        	}
        	String cyferka = pesel.substring(i,i+1);
        	int cyfereczka = Integer.parseInt(cyferka);
        	System.out.println(cyfereczka);
            System.out.println(wagi[i]);
        	suma = cyfereczka*wagi[i];
        	System.out.println(suma);
        }
        System.out.println(suma);
        int wynik = 10 - (suma%10);
        if(wynik==10)
        {
        	wynik=0;
        }
        if(cyfraKontrolna!=wynik)
        {
        	poprawnosc = false;
        }
        if(poprawnosc)
        {
        	System.out.println("Wprowadzony numer pesel: " + pesel + " jest prawid�owy");
        }
        else
        {
        	System.out.println("Wprowadzony numer pesel: " + pesel + " jest nieprawid�owy");
        }
    }
}