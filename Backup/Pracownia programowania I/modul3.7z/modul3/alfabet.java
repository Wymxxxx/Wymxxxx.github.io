public class Alfabet 
{
    public static void main(String[] args) 
    {
    	System.out.println("O to wszystkie litery alfabetu �aci�skiego: ");
    	for (char litera='A'; litera<='Z'; litera++)
    	{
    		System.out.print(litera + " ");
    	}
    }
}
