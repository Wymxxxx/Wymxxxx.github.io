import java.util.Scanner;
public class RownanieKwadratowe 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj wsp�czynniki r�wnania kwadratowego postaci ax2 + bx + c: ");
        System.out.print("Podaj wsp�czynnik a=");
        double a = wprowadzono.nextDouble();
        System.out.print("Podaj wsp�czynnik b=");
        double b = wprowadzono.nextDouble();
        System.out.print("Podaj wsp�czynnik c=");
        double c = wprowadzono.nextDouble();
        double delta = b*b-4*a*c;
        if (delta>0)
        {
        	double x1 = (-Math.sqrt(delta)-b)/(2*a);
        	double x2 = (Math.sqrt(delta)-b)/(2*a);
        	System.out.println("Pierwiastki tego r�wnania kwadratowego to: x1=" + x1 + " oraz x2=" + x2);
        }
        else if (delta==0)
        {
        	double x = (-b)/(2*a);
        	System.out.println("Pierwiastkiem tego r�wnania kwadratowego jest: x=" + x);
        }
        else
        {
        	System.out.println("To r�wnanie kwadratowe nie ma pierwiastk�w");
        }
    }
}
