import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;
public class QuickSort 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        Random generator = new Random();
        System.out.println("Generator n liczb pseudolosowych z przedzia�u [a,b]");
        System.out.println("===================================================");
        System.out.print("Ilo�� liczb n = ");
        int n = wprowadzono.nextInt();
        System.out.print("Warto�� minimalna a = ");
        int a = wprowadzono.nextInt();
        System.out.print("Warto�� maksymalna b = ");
        int b = wprowadzono.nextInt();
        long[] zbiorLiczb = new long[n];
        for (int i=0; i<zbiorLiczb.length; i++)
        {
        	zbiorLiczb[i] = generator.nextInt(b+1-a)+a;
        }
        System.out.printf("Liczby nieuporz�dkowane (%d..%d): ",a,b);
        for (long x : zbiorLiczb)
        {
        	System.out.print(x + " ");
        }
        System.out.println();
        Arrays.sort(zbiorLiczb);
        System.out.printf("Liczby uporz�dkowane (%d..%d) : ",a,b);
        for (long x : zbiorLiczb)
        {
        	System.out.print(x + " ");
        }
        System.out.println();
    }
}
