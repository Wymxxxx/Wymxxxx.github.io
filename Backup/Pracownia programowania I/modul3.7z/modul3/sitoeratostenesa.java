import java.util.Scanner;
public class SitoEratostenesa 
{
    public static void main(String[] args) 
    {
    	Scanner wprowadzono = new Scanner(System.in);
    	int i,j;
    	System.out.print("Podaj N: ");
    	int n = wprowadzono.nextInt();
    	boolean[] tablica = new boolean[n+1];
   
    	for (i=0; i<=n; i++) tablica[i] = true;
    	for (i=2; i<=n; i++) 
    	{
            for (j=2; j<=(n/i); j++) tablica [i*j] = false;
    	}
    	System.out.println("Kolejne liczby pierwsze z przedzialu: [1.." + n + "]:");
    	for (i=2; i<=n; i++) 
    	{
        	if (tablica[i]) 
        	{
            	System.out.printf("%4d" ,i);        
    		}
    	}
    }
}