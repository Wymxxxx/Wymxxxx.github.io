import java.util.Scanner;
public class CiagFibonacciego 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Ile wyraz�w ci�gu Fibonacciego poda�? ");
        int ilosc = wprowadzono.nextInt();
        int[] liczby = new int[ilosc];
        liczby[0] = 0;
        liczby[1] = 1;
        for (int i=2; i<ilosc; i++)
        {
        	liczby[i] = liczby[i-2]+liczby[i-1]; 
        }
        for(int liczba:liczby)
        {
        	System.out.print(liczba + ", ");
        }
        System.out.print("...");
    }
}
