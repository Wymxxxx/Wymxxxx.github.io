import java.util.Scanner;
public class LiczbaParzysta 
{
    public static void main(String[] args) 
    {
    	Scanner wprowadzone = new Scanner(System.in);
    	System.out.println("Wprowad� dowoln� liczb� naturaln�: ");
    	int liczbaNaturalna = wprowadzone.nextInt();
    	boolean liczbaParzysta = liczbaNaturalna % 2 == 0 ? true:false;
    	if (liczbaParzysta)
    	{
    		System.out.printf("Liczba %d jest parzysta", liczbaNaturalna);
    	}
    	else
    	{
    		System.out.printf("Liczba %d jest nieparzysta", liczbaNaturalna);
    	}
    }
}
