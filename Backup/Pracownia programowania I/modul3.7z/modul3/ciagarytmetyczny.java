import java.util.Scanner;
public class CiagArytmetyczny 
{
    public static void main(String[] args) 
    {
    	Scanner wprowadzono = new Scanner(System.in);
    	System.out.println("Podaj r�nic� ci�gu geometrycznego: ");
    	double roznica = wprowadzono.nextDouble();
    	System.out.println("Ile wyraz�w chcesz wy�wietli�?");
    	int ilosc = wprowadzono.nextInt();
    	double wyraz = 0;
    	for (int i=1; i<=ilosc; i++)
    	{
    		wyraz = (wyraz+=roznica);
    		System.out.println("Wyraz numer " + i + " ci�gu arytmetycznego o r�nicy " + roznica + " wynosi: " + wyraz);
    	}
    	
    }
}
