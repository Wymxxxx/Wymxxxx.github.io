import java.util.Scanner;
public class OcenaSlownie 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Podaj ocen�: ");
        int ocena = wprowadzono.nextInt();
        switch(ocena)
        {
        	case 1:
        	{
        		System.out.println("Niedostateczny");
        		break;
        	}
        	case 2:
        	{
        		System.out.println("Dopuszczaj�cy");
        		break;
        	}
        	case 3:
        	{
        		System.out.println("Dostateczny");
        		break;
           	}
           	case 4:
           	{
           		System.out.println("Dobry");
           		break;
           	}
           	case 5:
           	{
           		System.out.println("Bardzo Dobry");
           		break;
           	}
           	case 6:
           	{
           		System.out.println("Celuj�cy");
           		break;
           	}
           	default:
           	{
           		System.out.println("Wpisa�e� nieprawid�ow� ocene!");
           	}
        }
    }
}
