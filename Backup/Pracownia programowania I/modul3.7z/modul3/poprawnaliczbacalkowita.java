import java.util.Scanner;
public class PoprawnaLiczbaCalkowita 
{
	public static void main(String[] args) 
	{
		Scanner wprowadzono = new Scanner(System.in);
		System.out.println("Wprowad� liczb� ca�kowit�: ");
		String liczba = wprowadzono.nextLine();
		if(liczba.matches("[0-9]*"))
		{
			System.out.println("Liczb� wprowadzono prawid�owo");
		}
		else if(liczba.matches("[0-9]*[,][0-9]*"))
		{
			System.out.println("Liczb� wprowadzono prawid�owo");
		}
		else
		{
			System.out.println("Liczb� wprowadzono nieprawid�owo");
		}
	}
}