import java.util.Scanner;
public class PismoRozstrzelone 
{
    public static void main(String[] args) 
    {
        Scanner wprowadzono = new Scanner(System.in);
        System.out.println("Wprowad� dowolny ci�g znak�w: ");
        String tekst = wprowadzono.nextLine();
        for(int i=0; i<tekst.length(); i++)
        {
        	char znak = tekst.charAt(i);
        	System.out.print(znak + " ");
        }
    }
}
