/**
 *
 *  Klasa realizujaca ramke wykresu
 */

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.*;

public class Wykresik extends JFrame {
        
    //Konstruktor przyjmujacy na wejsciu liste danych, miejsce, 
    // od ktorego dane maja byc wyswietlone oraz tytul
    public Wykresik(List dane, int n0, String tytul){
        super(tytul);
        JPanel panel;
        panel = new Szablon1(dane, n0);
        add(panel);
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    //Konstruktor przyjmujacy na wejsciu dwie listy danych, miejsce, 
    // od ktorego dane maja byc wyswietlone oraz tytul wykresu
    // pierwsza seria - kolor czerwony
    // druga seria - kolor niebieski
    public Wykresik(List dane1, List dane2, int n0, String tytul){
        super(tytul);
        JPanel panel;
        panel = new Szablon2(dane1, dane2, n0);
        add(panel);
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    //Konstruktor przyjmujacy na wejsciu dwie listy danych, miejsce, 
    //od ktorego dane maja byc wyswietlone oraz tytul wykresu
    // pierwsza seria - kolor czerwony
    // druga seria - kolor niebieski
    // trzecia seria - kolor zielony
    public Wykresik(List dane1, List dane2, List dane3, int n0, String tytul){
        super(tytul);
        JPanel panel;
        panel = new Szablon3(dane1, dane2, dane3, n0);
        add(panel);
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    //Konstruktor przyjmujacy na wejsciu wielomian, krance przedzialu oraz tytul
    public Wykresik(Wielomian f, double a, double b, String tytul){
        super(tytul);
        JPanel panel;
        panel = new Szablon0(f, a, b);
        add(panel);
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}

