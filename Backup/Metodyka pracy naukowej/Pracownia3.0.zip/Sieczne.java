/*
 * Klasa realizujaca metode siecznych
 * 
 */

import java.util.*;

public class Sieczne {
    Wielomian f;        //funkcja
    Wielomian p1;       //pierwsza pochodna
    Wielomian p2;       //druga pochodna
    double a;           //lewy kraniec przedzialu
    double b;           //prawy kraniec przedzialu
    List<Double> rozw;  //lista kolejnych przyblizen rozwiazania
    
    //Konstruktor przyjmujacy na wejsciu funkcje oraz przedzial w ktorym szukamy rozwiazania
    public Sieczne(Wielomian funkcja, double lewy_kraniec, double prawy_kraniec) {
        f = funkcja;
        p1 = f.Pochodna();
        p2 = p1.Pochodna();
        a = lewy_kraniec;
        b = prawy_kraniec;
        rozw = new ArrayList<>();
    } 
    
    //Metoda wykonujaca zadana liczbe iteracji
    public void Iteruj(int k) {
        double x_akt, x_nast;               //zmienne przechowujace kolejne rozwiazania
        double p_staly;                     //zmienna przechowujaca punkt staly
        double wart_p_staly;                //wartosc funkcji w punkcie stalym
        if(p2.ObliczWartosc(a) * f.ObliczWartosc(a) > 0) {
            p_staly = a;
            x_akt = b;
        }
        else {
            p_staly = b;
            x_akt = a;
        }
        wart_p_staly = f.ObliczWartosc(p_staly);
        rozw.add(x_akt);                    //wstawiam startowe przyblizenie rozwiazania do listy
        System.out.format("%d. \t %4.10f\n", 0, x_akt);
        for(int i = 0; i < k; i++) {
            x_nast = x_akt - (f.ObliczWartosc(x_akt) * (x_akt - p_staly) / (f.ObliczWartosc(x_akt) - wart_p_staly));
            rozw.add(x_nast);
            System.out.format("%d. \t %4.10f\n", i+1, x_nast);
            x_akt = x_nast;
        } 
    }
    
    //Metoda wykonujaca iteracje do momentu, kiedy kolejne dwa przyblizenia sa odlegle o nmniej niz eps
    public void IterujA(double eps) {
        double x_akt, x_nast;               //zmienne przechowujace kolejne rozwiazania
        double p_staly;                     //zmienna przechowujaca punkt staly
        double wart_p_staly;                //wartosc funkcji w punkcie stalym
        if(p2.ObliczWartosc(a) * f.ObliczWartosc(a) > 0) {
            p_staly = a;
            x_akt = b;
        }
        else {
            p_staly = b;
            x_akt = a;
        }
        wart_p_staly = f.ObliczWartosc(p_staly);
        rozw.add(x_akt);                    //wstawiam startowe przyblizenie rozwiazania do listy
        System.out.format("%d. \t %4.10f\n", 0, x_akt);
        double roznica = 10.0;
        int i = 0;                          //licznik iteracji
        while (roznica > eps) {
            x_nast = x_akt - (f.ObliczWartosc(x_akt) * (x_akt - p_staly) / (f.ObliczWartosc(x_akt) - wart_p_staly));
            rozw.add(x_nast);
            i++;
            System.out.format("%d. \t %4.10f\n", i, x_nast);
            roznica = Math.abs(x_nast - x_akt);
            x_akt = x_nast;
        } 
    }
}
