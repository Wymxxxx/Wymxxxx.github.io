/*
 * Klasa glowna
 * 
 */

public class Pracownia {

    public static void main(String[] args) {
        
        //S E K C J A 1//
        //Porownanie metod bisekcji, stycznych i siecznych
        
        Przyklad00 test1 = new Przyklad00();
        test1.Porownaj();
        
        
        //S E K C J A 2//
        //Przyklad calki ze skomplikowanej funkcji
        /*
        Przyklad01 test2 = new Przyklad01();
        test2.Testuj();
        */
    }
}
