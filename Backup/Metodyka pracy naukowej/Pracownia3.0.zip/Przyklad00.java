/**
 * Klasa przykladowa - metody siecznych i bisekcji
 */

public class Przyklad00 {
    Wielomian f;        //wielomian, ktorego miejsca zerowego bede szukac
    double a, b;        //przedzial, na ktorym bede szukal rozwiazania
    
    //Konstruktor klasy
    // Panstwa zadaniem na pracowni bedzie tak zmieniac wartosci krancow przedzialu [a;b]
    // by wszystkie warunki zbieznosci byly spelnione - prosze pocwiczyc w domu
    public Przyklad00(){
        //okreslam wspolczynniki wielomianu
        double[] wsp = {2.0, 6.0, -4.0, 5.0, -3.0, 1.0};
        //konstruuje wielomian
        f = new Wielomian(wsp);
        //okreslam krance przedzialu
        a = -5.0;
        b = 5.0;
    }
    
    public void Porownaj() {
        //okreslam liczbe iteracji
        int n = 50;
        //powoluje do istnienia obiekty klas Bisekcja, Sieczne i Styczne 
        // oraz przeprowadzam iteracje
        Bisekcja test1 = new Bisekcja(f, a, b);
        test1.Iteruj(n);
        Sieczne test2 = new Sieczne(f, a, b);
        test2.Iteruj(n);
        Styczne test3 = new Styczne(f, a, b);
        test3.Iteruj(n);
        
        //Rysuje wykresy wielomianu, jego pochodnej oraz drugiej pochodnej
        Wykresik wielomian = new Wykresik(f, a, b, "Wielomian");
        Wykresik pochodna = new Wykresik(f.Pochodna(), a, b, "Pierwsza pochodna");
        Wykresik druga_pochodna = new Wykresik(f.Pochodna().Pochodna(), a, b,"Druga pochodna");
        
        //Rysuje wykres przebiegu iteracji
        //pierwsza seria danych - czerwona, druga seria danych - niebieska, trzecia - zielona
        Wykresik przebieg = new Wykresik(test1.rozw, test2.rozw, test3.rozw, 0, "Porowanie metod przyblizonych");
    }
}
