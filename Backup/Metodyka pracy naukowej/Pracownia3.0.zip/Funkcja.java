/*
 * Klasa przechowujaca funkcje
 */

public class Funkcja {
    
    //Konstruktor domyslny
    public Funkcja(){
    }
    
    //Metoda wyznaczajaca wartosc funkcji
    public double ObliczWartosc(double x){
        return 5.0 * Math.sin(12.0 * x + 6.0) + Math.sqrt(3.0 + x * x);
    } 
}
