/**
 * Klasa przykladowa - metody calkowania
 */

public class Przyklad01 {
    double a;       //dolna granica calkowania
    double b;       //gorna granica calkowania
    
    //Konstruktor domyslny
    public Przyklad01(){
    }
    
    public void Testuj() {
        //okreslam krance przedzialu
        a = -4.0;
        b = 4.0;
        
        //okreslam maksymalna roznice dwoch kolejnych przyblizen
        double eps = 1.0E-5;
        
        //wywoluje obiekty odpowiednich klas, by porownac metody
        MetodaTrapezow test1 = new MetodaTrapezow(a, b);
        test1.IterujA(eps);
        MetodaParabol test2 = new MetodaParabol(a, b);
        test2.IterujA(eps);
        Metoda38Newtona test3 = new Metoda38Newtona(a, b);
        test3.IterujA(eps);
        
        //rysuje na wykresie kolejne przyblizenia wartosci calek dla kolejnych wartosci n
        //pierwsza seria danych - czerwona, druga seria danych - niebieska
        Wykresik wykresik = new Wykresik(test1.rozw,test2.rozw, test3.rozw, 0, "Porownanie metod calkowania");  
    }
}
