/**
 * Przyklad zastosowania metod rozkladu macierzy ukladu na iloczyn macierzy trojkatnych
 * oraz pomiaru czasu wykonywania sie operacji dla losowego ukladu rownan
 */

public class Rozklady {

    public static void main(String[] args) {
        // zadaje uklad definiujac macierz A oraz wektor wyrazow wolnych b z zadania 1a
        double[][] A1 = {{2.0, 2.0, -4.0, 2.0}, {2.0, 3.0, -1.0, 1.0}, {-2.0, 2.0, 15.0, -8.0}, {5.0, 6.0, -7.0, 3.0}};
        double[] b1 = {-2.0, 0.0, 5.0, -5.0};
        
        //konstruuje nowy obiekt klasy Uklad
        Uklad u1 = new Uklad(A1, b1);
        
        //wyswietlam uklad na wyjsciu
        u1.WyswietlUklad();
        
        //rozwiazuje uklad metoda Gaussa - w tym celu powoluje do istnienia nowy obiekt klasy Gauss
        Cholesky przyklad1 = new Cholesky(u1);
        
        //wykonuje rozklad macierzy A na U i L
        przyklad1.Rozklad();
        przyklad1.Wyswietl();
        
        //nastepnie rozwiazuje 2 uklady trojkatne - dolny i gorny
        przyklad1.RozwiazTrojkatnyDolny();
        przyklad1.RozwiazTrojkatnyGorny();
        
        //wyswietlam rozwiazanie
        przyklad1.WyswietlRozwiazanie();
        
        //metode Banachiewicza moge zastosowac tylko do macierzy symetrycznej
        double[][] A2 = {{1.0, -1.0, -2.0, 1.0}, {-1.0, 5.0, 4.0, -3.0}, {-2.0, 4.0, 6.0, -1.0}, {1.0, -3.0, -1.0, 7.0}};
        double[] b2 = {0.0, 10.0, 4.0, -7.0};
        
        //konstruuje nowy obiekt klasy Uklad
        Uklad u2 = new Uklad(A2, b2);
        
        //wyswietlam uklad na wyjsciu
        u2.WyswietlUklad();
        
        //rozwiazuje uklad metoda Gaussa - w tym celu powoluje do istnienia nowy obiekt klasy Gauss
        Banachiewicz przyklad2 = new Banachiewicz(u2);
        
        //wykonuje rozklad macierzy A na kwadrat macierzy U
        przyklad2.Rozklad();
        przyklad2.Wyswietl();
        
        //nastepnie rozwiazuje 2 uklady trojkatne - dolny i gorny
        przyklad2.RozwiazTrojkatnyDolny();
        przyklad2.RozwiazTrojkatnyGorny();
        
        //wyswietlam rozwiazanie
        przyklad2.WyswietlRozwiazanie();
        
        //porownamy teraz czas rozwiazywania ukladu symetrycznego rownan o 1000 niewiadomych
        int n = 1000;
        Uklad u3 = new Uklad(n);
        u3.LosujUkladSymetrycznyDodatnioOkreslony();
        
        //tworzymy odpowiednio 2 obiekty
        Cholesky przyklad3 = new Cholesky(u3);
        Banachiewicz przyklad4 = new Banachiewicz(u3);
        
        //mierzymy czas metody Cholesky'ego
        long stoper = System.currentTimeMillis();
        przyklad3.Rozklad();
        przyklad3.RozwiazTrojkatnyDolny();
        przyklad3.RozwiazTrojkatnyGorny();
        stoper = System.currentTimeMillis() - stoper;
        System.out.format("Czas rozwiazywania ukladu metoda Cholesky'ego: %4.3f s\n\n", stoper/1000.0);
        
        //mierzymy czas metody Banachiewicza
        stoper = System.currentTimeMillis();
        przyklad4.Rozklad();
        przyklad4.RozwiazTrojkatnyDolny();
        przyklad4.RozwiazTrojkatnyGorny();
        stoper = System.currentTimeMillis() - stoper;
        System.out.format("Czas rozwiazywania ukladu metoda Banachiewicza: %4.3f s\n\n", stoper/1000.0);
    }
}
