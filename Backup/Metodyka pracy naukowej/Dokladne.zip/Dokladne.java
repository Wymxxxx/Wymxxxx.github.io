/**
 * Przyklad zastosowania metod dokladnych do rozwiazania zadanego ukladu rownan
 * oraz pomiaru czasu wykonywania sie operacji dla losowego ukladu rownan
 */
public class Dokladne {

    public static void main(String[] args) {
        // zadaje uklad definiujac macierz A oraz wektor wyrazow wolnych b z zadania 1a
        double[][] A = {{0.0, 1.0, -1.0, 1.0}, {2.0, 2.0, 3.0, 5.0}, {1.0, 3.0, 0.0, -2.0}, {0.0, 1.0, -1.0, 3.0}};
        double[] b = {2.0, 1.0, 0.0, 3.0};
        
        //konstruuje nowy obiekt klasy Uklad
        Uklad u = new Uklad(A, b);
        
        //wyswietlam uklad na wyjsciu
        u.WyswietlUklad();
        
        //rozwiazuje uklad metoda Gaussa - w tym celu powoluje do istnienia nowy obiekt klasy Gauss
        Gauss przyklad1 = new Gauss(u);
        
        //metoda Gaussa dziala w 2 krokach - najpierw przeprowadzam eliminacje elementow pod przekatna...
        przyklad1.Eliminacja();
        przyklad1.Wyswietl();
        
        //2 krok to rozwiazanie ukladu trojkatnego, po czym moge sprawdzic rozwiazanie
        przyklad1.RozwiazTrojkatny();
        przyklad1.WyswietlRozwiazanie();
         
        //aby sprawdzic rozwiazanie mozna wywolac ponisza metode
        przyklad1.SprawdzRozwiazanie();
        
        //to samo rozwiazanie uzyskamy metoda Gaussa-Jordana
        GaussJordan przyklad2 = new GaussJordan(u);
        
        //metoda Gaussa-Jordana ogranicza sie wylacznie do eliminacji
        przyklad2.Eliminacja();
        przyklad2.Wyswietl();
        
        //porownamy teraz czas rozwiazywania ukladu rownan o 300 niewiadomych tymi dwoma metodami
        int n = 300;
        Uklad u2 = new Uklad(n);
        u2.LosujUklad();
        
        //tworzymy odpowiednio 2 obiekty
        Gauss przyklad3 = new Gauss(u2);
        GaussJordan przyklad4 = new GaussJordan(u2);
        
        //uruchamiamy stoper poprzez zapisanie czasu systemowego - mierzymy czas metody Gaussa
        long stoper = System.currentTimeMillis();
        przyklad3.Eliminacja();
        przyklad3.RozwiazTrojkatny();
        stoper = System.currentTimeMillis() - stoper;
        System.out.format("Czas rozwiazywania ukladu metoda Gaussa: %4.5f milisekund\n\n", stoper/1000.0);
        
        //mierzymy czas metody Gaussa-Jordana
        stoper = System.currentTimeMillis();
        przyklad4.Eliminacja();
        stoper = System.currentTimeMillis() - stoper;
        System.out.format("Czas rozwiazywania ukladu metoda Gaussa-Jordana: %4.5f milisekund\n\n", stoper/1000.0);
    }
}
