

/**
 * Przyklad zastosowania metod iteracyjnych do rozwiazania ukladow rownan
 */
public class Iteracyjne {

    public static void main(String[] args) {
        // zadaje uklad definiujac macierz A oraz wektor wyrazow wolnych b z zadania 3a
        double[][] A1 = {{4.0, -1.0, -1.0}, {1.0, 3.0, -1.0}, {2.0, -1.0, 4.0}};
        double[] b1 = {-4.0, 12.0, 8.0};
        double[] X0 = {6.0, 4.0, 0.0};
        
        //konstruuje nowy obiekt klasy Uklad
        Uklad u1 = new Uklad(A1, b1);
        
        //wyswietlam uklad na wyjsciu
        u1.WyswietlUklad();
        
        System.out.println("---------------- ITERACJA PROSTA -----------------\n");
        //powoluje do istnienia obiekt klasy IteracjaProsta
        IteracjaProsta test1 = new IteracjaProsta(u1, X0);
        
        //przygotowuje uklad do iteracji
        test1.Przygotuj();
        test1.Wyswietl();
        
        //wykonuje 3 iteracje, korzystam z normy nieskonczonosc
        test1.Iteruj(3, 0, 1);
        
        //wykonuje 10, 20 i 30 iteracji 
        test1.Iteruj(10, 0, 0);
        System.out.println("Rozwiazanie przyblizone uzyskane po 10 iteracjach:");
        test1.WyswietlRozwiazanie();
        test1.SprawdzRozwiazanie();
        test1.Iteruj(20, 0, 0);
        System.out.println("Rozwiazanie przyblizone uzyskane po 20 iteracjach:");
        test1.WyswietlRozwiazanie();
        test1.SprawdzRozwiazanie();
        test1.Iteruj(30, 0, 0);
        System.out.println("Rozwiazanie przyblizone uzyskane po 30 iteracjach:");
        test1.WyswietlRozwiazanie();
        test1.SprawdzRozwiazanie();
        
        //wykonuje iteracje do momentu, kiedy kolejne rozwiazania przyblizone
        //roznia sie co do normy nie wiecej niz o 0.001 - korzystam z normy kolumnowej
        test1.IterujA(0.001, 1);
        System.out.println("Rozwiazanie uzyskane z wykorzystaniem kryterium stopu:");
        test1.WyswietlRozwiazanie();
        test1.SprawdzRozwiazanie();
        
        System.out.println("---------------- ITERACJA SEIDELA -----------------\n");
        //powoluje do istnienia obiekt klasy IteracjaSeidela
        IteracjaSeidela test2 = new IteracjaSeidela(u1, X0);
        
        //przygotowuje uklad do iteracji
        test2.Przygotuj();
        test2.Wyswietl();
        
        //wykonuje 3 iteracje metody Seidela
        test2.Iteruj(3, 0, 1);
        
        //wykonuje 10, 20 i 30 iteracji 
        test2.Iteruj(10, 0, 0);
        System.out.println("Rozwiazanie przyblizone uzyskane po 10 iteracjach:");
        test2.WyswietlRozwiazanie();
        test2.SprawdzRozwiazanie();
        test2.Iteruj(20, 0, 0);
        System.out.println("Rozwiazanie przyblizone uzyskane po 20 iteracjach:");
        test2.WyswietlRozwiazanie();
        test2.SprawdzRozwiazanie();
        test2.Iteruj(30, 0, 0);
        System.out.println("Rozwiazanie przyblizone uzyskane po 30 iteracjach:");
        test2.WyswietlRozwiazanie();
        test2.SprawdzRozwiazanie();
        
        //wykonuje iteracje do momentu, kiedy kolejne rozwiazania przyblizone
        //roznia sie co do normy nie wiecej niz o 0.001 - korzystam z normy kolumnowej
        test2.IterujA(0.001, 1);
        System.out.println("Rozwiazanie uzyskane z wykorzystaniem kryterium stopu");
        test2.WyswietlRozwiazanie();
        test2.SprawdzRozwiazanie();
        
        //porownanie czasow wykonywania sie obu metod dla ukladu rownan o 1000 niewiadomych
        System.out.println("--------------- POROWNANIE CZASOW ----------------\n");
        int n = 1000;
        Uklad u2 = new Uklad(n);
        double[] X_start = new double[n];
        u2.LosujUkladSymetrycznyDodatnioOkreslony();
        double eps = 1.0e-6;
        
        //tworzymy odpowiednio 2 obiekty
        IteracjaProsta test3 = new IteracjaProsta(u2, X_start);
        IteracjaSeidela test4 = new IteracjaSeidela(u2, X_start);
        
        //mierzymy czas metody iteracji prostej
        long stoper = System.currentTimeMillis();
        test3.Przygotuj();
        test3.IterujA(eps, 1);
        stoper = System.currentTimeMillis() - stoper;
        System.out.format("Czas rozwiazywania ukladu metoda iteracji prostej: %4.3f s\n\n", stoper/1000.0);
        
        //mierzymy czas metody Iteracji Seidela
        stoper = System.currentTimeMillis();
        test4.Przygotuj();
        test4.IterujA(eps, 1);
        stoper = System.currentTimeMillis() - stoper;
        System.out.format("Czas rozwiazywania ukladu metoda iteracji Seidela: %4.3f s\n\n", stoper/1000.0);
    }   
}
