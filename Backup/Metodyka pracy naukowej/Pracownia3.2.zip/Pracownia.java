/*
 * Klasa glowna
 * 
 */

public class Pracownia {

    public static void main(String[] args) {
        
        //S E K C J A 1//
        //Porownanie metod siecznych, stycznych i bisekcji
                
        Przyklad1 test1 = new Przyklad1(0);
        test1.Porownaj();
        
        
        //S E K C J A 2//
        //Przyklad calki ze skomplikowanej funkcji
        /*
        Przyklad2 test2 = new Przyklad2();
        test2.Porownaj();
        */
        
        //S E K C J A 3//
        //Mozna ja wykorzstac do realizacji zadania 1
        /*
        Zadanie1 test1 = new Zadanie1();
        test1.Porownaj();
        */
        
        //S E K C J A 4//
        //Mozna ja wykorzstac do realizacji zadania 2
        /*
        Zadanie2 test2 = new Zadanie2();
        test2.Porownaj();
        */
    }
}
