/*
 * Klasa realizujaca metode bisekcji
 */

import java.util.*;

public class Bisekcja {
    Wielomian f;        //funkcja
    double a;           //lewy kraniec przedzialu
    double b;           //prawy kraniec przedzialu
    List<Double> rozw;  //lista kolejnych przyblizen rozwiazania
    
    //Konstruktor przyjmujacy na wejsciu funkcje oraz przedzial w ktorym szukamy rozwiazania
    public Bisekcja(Wielomian funkcja, double lewy_kraniec, double prawy_kraniec) {
        f = funkcja;
        a = lewy_kraniec;
        b = prawy_kraniec;
        rozw = new ArrayList<>();
    } 
    
    //Metoda wykonujaca zadana liczbe iteracji
    public void Iteruj(int k) {
        double lewy_kraniec = a;            //lewy kraniec aktualnego przedzialu poszukiwania rozwiazania
        double prawy_kraniec = b;           //prawy kraniec aktualnego przedzialu poszukiwania rozwiazania
        double wart_lewa, wart_prawa;       //wartosci funkcji na krancach aktualnego przedzialu
        wart_lewa = f.ObliczWartosc(lewy_kraniec);
        wart_prawa = f.ObliczWartosc(prawy_kraniec);
        double srodek;                      //srodek aktualnego przedzialu
        srodek = (lewy_kraniec + prawy_kraniec) / 2.0;
        rozw.add(srodek);                   //wstawiam startowe przyblizenie rozwiazania do listy
        System.out.format("%d. \t %4.10f\n", 0, srodek);
        double wart_srodek;                 //wartosc funkcji w srodku przedzialu
        for(int i = 0; i < k; i++) {
            wart_srodek = f.ObliczWartosc(srodek);
            if(wart_lewa * wart_srodek > 0) {       
                lewy_kraniec = srodek;
                wart_lewa = wart_srodek;
                srodek = (srodek + prawy_kraniec) / 2.0;
                rozw.add(srodek);
            }
            else if (wart_lewa * wart_srodek < 0) {
                prawy_kraniec = srodek;
                wart_prawa = wart_srodek;
                srodek = (srodek + lewy_kraniec) / 2.0;
                rozw.add(srodek);
            }
            else break;                     //jesli w srodku przedzialu mamy miejsce zerowe zakoncz poszukiwanie      
            System.out.format("%d. \t %4.10f\n", i, srodek);
        } 
    }
    
    //Metoda wykonujaca iteracje do momentu, kiedy kolejne dwa przyblizenia sa odlegle o nmniej niz eps
    public void IterujA(double eps) {
        double lewy_kraniec = a;            //lewy kraniec aktualnego przedzialu poszukiwania rozwiazania
        double prawy_kraniec = b;           //prawy kraniec aktualnego przedzialu poszukiwania rozwiazania
        double wart_lewa, wart_prawa;       //wartosci funkcji na krancach aktualnego przedzialu
        wart_lewa = f.ObliczWartosc(lewy_kraniec);
        wart_prawa = f.ObliczWartosc(prawy_kraniec);
        double srodek;                      //srodek aktualnego przedzialu
        srodek = (lewy_kraniec + prawy_kraniec) / 2.0;
        rozw.add(srodek);                   //wstawiam startowe przyblizenie rozwiazania do listy
        System.out.format("%d. \t %4.10f\n", 0, srodek);
        double wart_srodek;                 //wartosc funkcji w srodku przedzialu
        double roznica = 100.0;
        int i = 0;                              //licznik iteracji
        while(roznica > eps) {
            wart_srodek = f.ObliczWartosc(srodek);
            if(wart_lewa * wart_srodek > 0) {       
                lewy_kraniec = srodek;
                wart_lewa = wart_srodek;
                srodek = (srodek + prawy_kraniec) / 2.0;
                rozw.add(srodek);
            }
            else if (wart_lewa * wart_srodek < 0) {
                prawy_kraniec = srodek;
                wart_prawa = wart_srodek;
                srodek = (srodek + lewy_kraniec) / 2.0;
                rozw.add(srodek);
            }
            else break;                     //jesli w srodku przedzialu mamy miejsce zerowe zakoncz poszukiwanie      
            i++;
            roznica = Math.abs(srodek - rozw.get(i-1));
            System.out.format("%d. \t %4.10f\n", i, srodek);
        } 
    }
    
    
}
