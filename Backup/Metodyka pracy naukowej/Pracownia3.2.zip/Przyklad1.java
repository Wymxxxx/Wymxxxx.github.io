/*
 * Przyklad - porownanie metody siecznych, stycznych i bisekcji
 */

public class Przyklad1 {
    Wielomian f;        //wielomian, ktorego miejsca zerowego bede szukac
    double a, b;        //przedzial, na ktorym bede szukal rozwiazania

    //Konstruktor klasy
    public Przyklad1(int k){
        //okreslam wspolczynniki wielomianu: a0, a1, a2 oraz a3
        //ponizszy wielomian to 7.0 + 3.0 * x - 6.0 * x^2 + 3.0 * x^3
        double[] wsp = {7.0, 3.0, -6.0, 3.0};
        //konstruuje odpowiedni wielomian oraz zadaje krance przedzialu
        switch(k){
            //dobor przedzialu
            case 1: f = new Wielomian(wsp);
                    a = -5.0;
                    b = 5.0;
                    break;
            //zle dobrany przedzial - tylko bisekcja nie znajduje rozwiazania
            case 2: f = new Wielomian(wsp);
                    a = -0.6;
                    b = -0.4;
                    break;
            //zle dobrany przedzial - zadna metoda nie zbiega do rozwiazania
            case 3: wsp[0] = 1.0;
                    wsp[1] = 1.1;
                    wsp[2] = 1.0;
                    wsp[3] = 0.0;
                    f = new Wielomian(wsp);
                    a = 0.0;
                    b = 1.0;
                    break;
            //niespelniony trzeci z warunkow zbieznosci - f''(x) zmienia znak w przedziale [a;b] 
            case 4: wsp[0] = -4.41828;
                    wsp[1] = 13.806;
                    wsp[2] = -10.716;
                    wsp[3] = 2.3539;
                    f = new Wielomian(wsp);
                    a = 1.0;
                    b = 2.0;
                    break;
                //zaden z warunkow zbieznosci niespelniony    
            case 5: wsp[0] = 2.0;
                    wsp[1] = -1.0;
                    wsp[2] = 0.0;
                    wsp[3] = 1.0;
                    f = new Wielomian(wsp);
                    a = -0.5;
                    b = 2.0;
                    break;
        }
    }
    
    public void Porownaj() {
        //okreslam liczbe iteracji lub parametr eps
        int n = 40;
        //double eps = 1.0E-7;
        //powoluje do istnienia obiekty klas Sieczne, Styczne i Bisekcja oraz 
        // przeprowadzam iteracje
        Sieczne test1 = new Sieczne(f, a, b);
        test1.Iteruj(n);
        //test1.IterujA(eps);
        Styczne test2 = new Styczne(f, a, b);
        test2.Iteruj(n);
        //test2.IterujA(eps);
        Bisekcja test3 = new Bisekcja(f, a, b);
        test3.Iteruj(n);
        //test3.IterujA(eps);
        
        //Rysuje wykresy wielomianu, jego pochodnej oraz drugiej pochodnej
        Wykresik wielomian = new Wykresik(f, a, b, "Wielomian");
        Wykresik pochodna = new Wykresik(f.Pochodna(), a, b, "Pochodna");
        Wykresik druga_pochodna = new Wykresik(f.Pochodna().Pochodna(), a, b,"Druga pochodna");
        
        //Rysuje wykres przebiegu iteracji
        // pierwsza seria danych - czerwona, druga seria danych - niebieska, trzecia - zielona
        // trzeci parametr - numer pierwszej wyswietlanej iteracji
        Wykresik przebieg = new Wykresik(test1.rozw, test2.rozw, test3.rozw, 0, "Porownanie metod przyblizonych");
    }
}
