/*
 * Klasa do realizacji zadania 2
 */

public class Zadanie2 {
    double a;       //dolna granica calkowania
    double b;       //gorna granica calkowania
    
    //Konstruktor domyslny
    public Zadanie2(){
    }
    
    public void Porownaj() {
        //okreslam krance przedzialu - granice calkowania
        a = 0.0;
        b = 0.0;
        
        //okreslam parametr eps lub liczbe iteracji
        //double eps = 1.0E-4;
        //int n = 50;
        
        //wykonuje iteracje dla wybranych metod
        MetodaTrapezow test1 = new MetodaTrapezow(a, b);
        //test1.Iteruj(n);
        //test1.IterujA(eps);
        MetodaParabol test2 = new MetodaParabol(a, b);
        //test2.Iteruj(n);
        //test2.IterujA(eps);
        Metoda38Newtona test3 = new Metoda38Newtona(a, b);
        //test3.Iteruj(n);
        //test3.IterujA(eps);
        
        //rysuje na wykresie kolejne przyblizenia wartosci calek
        // pierwsza seria danych - czerwona, druga seria danych - niebieska
        // trzeci parametr - numer pierwszej wyswietlanej iteracji
        Wykresik wykresik = new Wykresik(test1.rozw, test2.rozw, 0, "Porownanie metod calkowania");  
    }
}
