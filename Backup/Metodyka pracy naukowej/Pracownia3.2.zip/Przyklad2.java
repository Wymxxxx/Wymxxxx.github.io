/*
 * Przyklad zastosowania calkowania numerycznego
 */

public class Przyklad2 {
    double a;       //dolna granica calkowania
    double b;       //gorna granica calkowania
    
    //Konstruktor domyslny
    public Przyklad2(){
    }
    
    public void Porownaj() {
        //okreslam krance przedzialu - granice calkowania
        a = -7.0;
        b = 7.0;
        
        //okreslam parametr eps lub liczbe iteracji
        double eps = 1.0E-4;
        //int n = 50;
        
        //wykonuje iteracje dla wybranych metod
        MetodaTrapezow test1 = new MetodaTrapezow(a, b);
        //test1.Iteruj(n);
        test1.IterujA(eps);
        MetodaParabol test2 = new MetodaParabol(a, b);
        //test2.Iteruj(n);
        test2.IterujA(eps);
        Metoda38Newtona test3 = new Metoda38Newtona(a, b);
        //test3.Iteruj(n);
        test3.IterujA(eps);
        
        //rysuje na wykresie kolejne przyblizenia wartosci calek
        // pierwsza seria danych - czerwona, druga seria danych - niebieska, trzecia - zielona
        // trzeci parametr - numer pierwszej wyswietlanej iteracji
        Wykresik wykresik = new Wykresik(test1.rozw, test2.rozw, test3.rozw, 0, "Porownanie metod calkowania");  
    }
}

