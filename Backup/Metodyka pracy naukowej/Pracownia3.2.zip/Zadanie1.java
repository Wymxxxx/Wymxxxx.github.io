/*
 * Klasa do realizacji zadania 1
 */

public class Zadanie1 {
    Wielomian f;        //wielomian, ktorego miejsca zerowego bede szukac
    double a, b;        //przedzial, na ktorym bede szukal rozwiazania

    //Konstruktor klasy
    public Zadanie1(){
        //okreslam wspolczynniki wielomianu: a0, a1, a2 oraz a3
        double[] wsp = {0.0, 0.0, 0.0, 0.0};
        //konstruuje odpowiedni wielomian oraz zadaje krance przedzialu
        f = new Wielomian(wsp);
        a = 0.0;
        b = 0.0;
    }
    
    public void Porownaj() {
        //okreslam liczbe iteracji lub parametr eps
        //int n = 50;
        //double eps = 1.0E-7;
        
        //powoluje do istnienia obiekty odpowiednich klas oraz przeprowadzam iteracje
        Sieczne test1 = new Sieczne(f, a, b);
        //test1.Iteruj(n);
        //test1.IterujA(eps);
        Styczne test2 = new Styczne(f, a, b);
        //test2.Iteruj(n);
        //test2.IterujA(eps);
        Bisekcja test3 = new Bisekcja(f, a, b);
        //test3.Iteruj(n);
        //test3.IterujA(eps);
        
        //Rysuje wykresy wielomianu, jego pochodnej oraz drugiej pochodnej
        Wykresik wielomian = new Wykresik(f, a, b, "Wielomian");
        Wykresik pochodna = new Wykresik(f.Pochodna(), a, b, "Pochodna");
        Wykresik druga_pochodna = new Wykresik(f.Pochodna().Pochodna(), a, b,"Druga pochodna");
        
        //Rysuje wykres przebiegu iteracji
        // pierwsza seria danych - czerwona, druga seria danych - niebieska
        // trzeci parametr - numer pierwszej wyswietlanej iteracji
        Wykresik przebieg = new Wykresik(test1.rozw, test2.rozw, 0, "Porownanie metod przyblizonych");
    }
}
