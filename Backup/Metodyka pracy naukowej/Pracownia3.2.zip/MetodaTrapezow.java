/*
 * Klasa realizujaca metode trapezow
 */

import java.util.*;

public class MetodaTrapezow {
    int n;              //liczba podprzedzialow
    double h;           //krokw wzdluz osi
    double a;           //dolna granica calki
    double b;           //gorna granica calki
    Funkcja f;          //funkcja podcalkowa
    List<Double> rozw;  //lista kolejnych przyblizen calki
    
    //Konstruktor
    public MetodaTrapezow(double dolna_granica, double gorna_granica){
        a = dolna_granica;
        b = gorna_granica;
        f = new Funkcja();
        rozw = new ArrayList<>();
    }
    
    //Metoda obliczajaca calke dla zadanej liczby podprzedzialow
    public double Calkuj(int podprzedzialy){
        double calka;           //zmienna przechowujaca wartosc przyblizenia calki
        n = podprzedzialy;
        h = 1.0 * (b - a) / n;
        calka = f.ObliczWartosc(a) + f.ObliczWartosc(b);
        for(int i = 1; i < n; i++) calka += 2*f.ObliczWartosc(a + i * h);
        return h * calka / 2;
    }
    
    //Metoda wykonujaca zadana liczbe iteracji
    public void Iteruj(int max_n){
        double calka;
        for(int i = 1; i < max_n + 1; i++) {
            calka = Calkuj(i);
            rozw.add(calka);
            System.out.format("%d. \t %4.10f \n", i, calka);
        }
    }
    
    //Metoda zwiekszajaca liczbe podzialow do momentu, gdy kolejne dwie calki 
    // roznia sie o mniej niz eps
    public void IterujA(double eps){
        double calka_akt, calka_poprz;
        double roznica = 10.0;
        int i = 1;
        calka_akt = Calkuj(i);
        rozw.add(calka_akt);
        System.out.format("%d. \t %4.10f \n", i, calka_akt);
        while(roznica > eps) {
            calka_poprz = calka_akt;
            i++;
            calka_akt = Calkuj(i);
            rozw.add(calka_akt);
            System.out.format("%d. \t %4.10f \n", i, calka_akt);
            roznica = Math.abs(calka_akt - calka_poprz);
        }
    }
}
