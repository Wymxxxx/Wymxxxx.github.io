/*
 * Klasa przechowujaca wielomian
 * 
 */

public class Wielomian {
    int n;              //stopien wielomianu
    double[] a;         //tablica wspolczynnikow, a[i] - element stojacy przy x^i
    
    //Konstruktor przyjmujacy na wejsciu tablice wspolczynnikow
    public Wielomian(double[] wsp){
        n = wsp.length - 1;
        a = new double[n + 1];
        System.arraycopy(wsp, 0, a, 0, n+1);
    }
    
    //Konstruktor kopiujacy
    public Wielomian(Wielomian funkcja) {
        this.n = funkcja.n;
        this.a = new double[n+1];
        System.arraycopy(funkcja.a, 0, this.a, 0, this.n + 1);
    }
    
    //Metoda wyznaczajaca wartosc wielomianu w punkcie
    public double ObliczWartosc(double x){
        double wartosc = a[0];
        for(int i = 1; i < n+1; i++) wartosc += a[i] * Math.pow(x, i);
        return wartosc;
    }
    
    //Metoda wyznaczajaca pochodna wielomianu
    public Wielomian Pochodna(){
        Wielomian poch;
        double[] wsp = new double[n];
        for(int i = 0; i < n; i++){
            wsp[i] = a[i+1] * (i + 1);
        }
        poch = new Wielomian(wsp);
        return poch;
    }
    
}
