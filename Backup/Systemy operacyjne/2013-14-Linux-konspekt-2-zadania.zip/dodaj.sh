echo $1 $2 >> lista.txt
cat lista.txt | sort > listaa.txt
rm lista.txt
mv listaa.txt lista.txt
echo "Na liscie mamy" $( cat lista.txt | wc -l ) "osob"
