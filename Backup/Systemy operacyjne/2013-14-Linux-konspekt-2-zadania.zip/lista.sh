#!/bin/bash

cp lista1.txt listaa.txt
cat lista2.txt >> listaa.txt
sort listaa.txt > lista.txt
rm listaa.txt
cat  lista.txt
