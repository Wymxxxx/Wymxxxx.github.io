#!bin/bash

cat lista.txt | cut -c1-3 > a.txt
cat lista.txt | cut -d ' ' -f 2-  > b.txt
cat b.txt | cut -c1-3 > c.txt
paste -d ""  a.txt c.txt > lista.id
rm a.txt
rm b.txt
rm c.txt
cat lista.id

