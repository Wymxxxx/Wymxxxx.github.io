sort kolokwium1.txt > kolokwium11.txt
sort kolokwium2.txt > kolokwium22.txt
cat kolokwium22.txt | cut -d ' ' -f 3- > kol.txt 
paste -d " " kolokwium11.txt kol.txt > kolokwiaa.txt

awk '{if ($3 > $4) print $1,$2,$4,$3; else print $1,$2,$3,$4}' kolokwia.txt

rm kolokwium11.txt | rm kolokwium22.txt | rm kol.txt | rm kolokwiaa.txt 	

