#!bin\bash

grep $1 lista.txt > osoby.txt

grep -v -f osoby.txt lista.txt > listaa.txt

rm lista.txt

mv listaa.txt lista.txt

cat lista.txt

echo "Usunieto" $( cat osoby.txt | wc -l) " osoby"

rm osoby.txt
