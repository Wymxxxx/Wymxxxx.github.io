cut -f1 -d" " lista.txt | cut -c1 > temp1.txt
cut -f2 -d" " lista.txt | cut -c1 > temp2.txt
paste -d"." temp1.txt temp2.txt > inicjaly.id
cat inicjaly.id | sed 's/$/./g'
rm temp*.txt
