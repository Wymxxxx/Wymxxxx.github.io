echo $1 $2 >> lista.txt
sort lista.txt
Licz=`cat lista.txt | wc -l`
echo Na liscie mamy $Licz osob
