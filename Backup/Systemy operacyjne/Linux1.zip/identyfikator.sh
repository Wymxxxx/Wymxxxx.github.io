cut -f1 -d" " lista.txt | cut -c1-3 > temp1.txt
cut -f2 -d" " lista.txt | cut -c1-3 > temp2.txt
paste -d"\0" temp1.txt temp2.txt > lista.id
cat lista.id
rm temp*.txt
