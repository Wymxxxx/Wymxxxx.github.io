grep $1 -i lista.txt > temp.txt
cat temp.txt
Licz=`cat temp.txt | wc -l`
echo Na znaleziono $Licz osob
rm temp.txt
