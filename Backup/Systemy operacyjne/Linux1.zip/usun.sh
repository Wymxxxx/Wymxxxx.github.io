grep $1 -i lista.txt > usuniete.txt
grep -v $1 lista.txt > temp.txt
cat temp.txt > listau.txt
Licz=`cat usuniete.txt |wc -l`
cat usuniete.txt
echo Usunieto $Licz osob
rm usuniete.txt
rm temp.txt

