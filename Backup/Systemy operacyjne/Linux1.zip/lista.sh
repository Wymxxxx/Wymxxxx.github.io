cat lista1.txt > lista.txt
cat lista2.txt >> lista.txt
cat lista.txt | sort
