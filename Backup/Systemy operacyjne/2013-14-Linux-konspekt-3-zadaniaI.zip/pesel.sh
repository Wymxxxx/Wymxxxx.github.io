echo -n "Podaj pesel: "
read pesel
pesl=`echo $pesel | grep -E "^[[:digit:]]{11}$"`
tab=()
for((I=1;I<12;I++))
do
zmienna=`echo "$pesel" | cut -c$I`
tab[$I]="$zmienna"
done

let "a=${tab[1]}+(${tab[2]}*3)+(${tab[3]}*7)+(${tab[4]}*9)"
let "b=$a+${tab[5]}+(${tab[6]}*3)+(${tab[7]}*7)+(${tab[8]}*9)"
let "c=$b+${tab[9]}+(${tab[10]}*3)"
let "d=$c%10"
let "e=10-$d"

if [ "$pesel" == "$pesl" ] && [ "$e" == "${tab[11]}" ];
then
echo "Podales dobry pesel"
else
echo "Podales zly pesel"
fi
