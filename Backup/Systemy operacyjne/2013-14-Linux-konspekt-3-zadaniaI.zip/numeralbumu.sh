cat mojrok.4 | cut -d: -f1 > a
cat mojrok.4 | cut -d: -f2 > n
cat mojrok.4 | cut -d: -f3 > i
sed "s/s//g" a > aa
paste -d: n i > m
paste -d: m aa > mojrok.txt
rm a | rm n | rm i | rm m | rm aa
