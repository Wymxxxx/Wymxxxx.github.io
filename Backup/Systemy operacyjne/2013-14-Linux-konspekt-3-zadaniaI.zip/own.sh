zmienna=$1
if [ $# -eq 0 ];
then
echo -n "Brak nazwy pliku. Podaj nazwe: "
read zmienna
until [ -r "$zmienna" ]
do 
echo -n "Plik nie istnieje. Podaj poprawna nazwe: "
read zmienna
done
fi

echo -n "Plik istnieje. Podaj pierwsza litere: "
read litera
if test -z "$litera"
then
echo "Nie podales litery. Domyslna litera A"
litera='A'
else
echo "Podales litere \"$litera\" "
fi

echo -n "Podaj druga litere: "
read litera2
if test -z "$litera2"
then
echo "Nie podales drugiej litery. Domyslna litera Z"
litera2=`Z`
else 
echo "Podales druga litere \"$litera2\""
fi

wysw=`cat $zmienna | grep -E "^[$litera-$litera2]{1}" | sort`
echo  "Nazwiska z przedzialu od \"$litera\" do \"$litera2\""
echo  " "
echo -n "$wysw"
echo  " "

echo "Zapisac do pliku? Wcisnij T jako Tak lub N jako nie"
read zapis
if [ $zapis = 'T' ]
then
echo "Podaj nazwe pliku: "
read nazwa
cat $zmienna | grep -E "^[$litera-$litera2]{1}" | tr " " "\n"  > $nazwa
echo "Plik zapisany. Koniec programu"
elif [ $zapis = 'N' ]
then
echo "Koniec programu"
else 
echo "Zla litera. Koniec programu"
fi	

