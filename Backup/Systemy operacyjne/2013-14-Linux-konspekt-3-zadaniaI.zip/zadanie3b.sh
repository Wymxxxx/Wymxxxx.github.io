cat mojrok.2 | cut -d: -f1 > a
cat mojrok.2 | cut -d: -f2 > c
cat c | cut -d " " -f1 > i
cat c | cut -d " " -f2 > n
sed "s/,//g" n > nn
paste -d: a nn > t
paste -d: t i > mojrok.3
rm a | rm c | rm i | rm n | rm t | rm nn
