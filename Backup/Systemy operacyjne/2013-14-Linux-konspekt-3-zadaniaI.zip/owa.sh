zmienna=$1
if [ $# -eq 0 ];
then
echo -n "Brak nazwy pliku. Podaj nazwe: "
read zmienna
until [ -r "$zmienna" ]
do 
echo -n "Plik nie istnieje. Podaj poprawna nazwe: "
read zmienna
done
fi

echo -n "Plik istnieje. Podaj pierwsza liczbe: "
read liczba1

echo -n "Podaj druga liczbe: "
read liczba2

awk -F ":" '{print $3", "$1", "$2}' $zmienna > mojrok2.txt
awk -v l1=$liczba1 -v l2=$liczba2 '{ if ( $1 >= l1 && $1 <= l2 ) print;}' mojrok2.txt

echo "Zapisac do pliku? Wcisnij T jako Tak lub N jako nie"
read zapis
if [ $zapis = 'T' ]
then
echo "Podaj nazwe pliku: "
read nazwa
awk -v l1=$liczba1 -v l2=$liczba2 '{ if ( $1 >= l1 && $1 <= l2 ) print;}' mojrok2.txt > $nazwa
echo "Plik zapisany. Koniec programu"
elif [ $zapis = 'N' ]
then
echo "Koniec programu"
else 
echo "Zla litera. Koniec programu"
fi	

