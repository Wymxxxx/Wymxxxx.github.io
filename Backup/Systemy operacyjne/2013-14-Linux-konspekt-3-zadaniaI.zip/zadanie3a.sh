cat passwd | grep -E "^s[[:digit:]]{6}" > mojrok
grep "r10" mojrok > mojrok.1
cat mojrok.1 | cut -d: -f1,5 > mojrok.2
rm mojrok
