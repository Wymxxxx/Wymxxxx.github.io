cat mojrok.3 | grep -E "^s[[:digit:]]{6}:[[:alpha:]]{1,15}:[[:alpha:]]{1,15}$" > mojrok.4
#wytnij=`cat mojrok.3 | cut -f1`

#if [ "$czysc" == "$wytnij" ]
#then
#echo "$czysc"
#fi

grep -v mojrok.4 mojrok.3 > mojrok.error
