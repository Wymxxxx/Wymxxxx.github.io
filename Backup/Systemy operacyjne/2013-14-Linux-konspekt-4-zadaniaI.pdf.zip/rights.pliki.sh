for f in prwx prw- pr-x pr-- p-wx p-w- p--x p---
do

cat $f | cut -d " " -f2 | sed "s/-//g" > a
plik=$( cat a | cut -c2- )
chmod a-rwx $f
chmod u+$plik $f

done
rm a
