for f in prwx prw- pr-x pr-- p-wx p-w- p--x p---
do

echo "Piszę: $f"
echo "# Piszę" >> $f

done
