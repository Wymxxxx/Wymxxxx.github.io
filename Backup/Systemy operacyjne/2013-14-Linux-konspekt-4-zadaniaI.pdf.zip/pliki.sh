for f in prwx prw- pr-x pr-- p-wx p-w- p--x p---
do

touch $f
echo "Jestem $f" > $f

done
