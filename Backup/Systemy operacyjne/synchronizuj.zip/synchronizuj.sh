par1=$1
par2=$2

echo "Podane katalogi to \"$par1\" i \"$par2\""

find $par1 -type f -printf "%f:%AY-%Am-%Ad;%AT\n" | sed "s/.0000000000//g" | sort > tmp1

find $par2 -type f -printf "%f:%AY-%Am-%Ad;%AT\n" | sed "s/.0000000000//g" | sort > tmp2
 
find $par1 -type f -printf "%f\n" | sort > a

find $par2 -type f -printf "%f\n" | sort > b

for aa in `comm -23 a b`
do
grep -E "^$aa:.*$" tmp1 | tr " " "\n" >> tylko-w-katalogu1.txt 
done

for bb in `comm -13 a b`
do 
grep -E "^$bb:.*$" tmp2 | tr " " "\n" >> tylko-w-katalogu2.txt
done

comm -12 tmp1 tmp2 > wspolne.txt

for ff in `comm -12 a b`
do
if [ $par1/$ff -nt $par2/$ff ]
then
grep -E "^$ff:.*$" tmp1 | tr " " "\n" >> nowsze-w-katalogu1.txt
fi
done

for fg in `comm -12 a b`
do
if [ $par2/$fg -nt $par1/$fg ]
then
grep -E "^$fg:.*$" tmp2 | tr " " "\n" >> nowsze-w-katalogu2.txt
fi
done

echo "Pliki znajdujace sie tylko w \"$par1\" to: "
echo $(cat tylko-w-katalogu1.txt | cut -d ":" -f1 )
echo "Pliki znajdujace sie tylko w \"$par2\" to: "
echo $(cat tylko-w-katalogu2.txt | cut -d ":" -f1 )
echo "Pliki WSPOLNE dla \"$par1\" i \"$par2\" to: "
echo $(cat wspolne.txt | cut -d ":" -f1 )

echo "Dokonac synchronizacji folderow ? Wpisz T jako Tak, lub N jako Nie "
read wybor

if [ $wybor == 'T' ]
then

for f1 in $par1/*
do
	for f2 in $par2/*
	do
if [ $a == $b ] && [ $f1 -nt $f2 ]
then
rsync -a $par1/ $par2/
fi

if [ $a == $b ] && [ $f2 -nt $f1 ]
then
rsync -a $par2/ $par1/
fi
done
done
echo "Foldery zsynchronizowane. Koniec programu!"
elif [ $wybor = 'N' ]
then
echo "Folder nie zsynchronizowane. Koniec programu!"
else
echo "Zla litera. Koniec programu!"
fi	

rm tmp1
rm tmp2
rm a
rm b
