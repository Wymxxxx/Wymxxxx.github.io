

import java.awt.Color;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.imageio.ImageIO;

class Zad5 extends JFrame{ 
    
    private JLabel lInfo, lDolar, lEuro, lObraz;
    private JTextField tKursDolar, tKursEuro;
    public Zad5 (){
       
        lDolar = new JLabel("");
        lDolar.setText("Kurs dolara amerykańskiego: ");
        lDolar.setForeground(Color.BLACK);
        lDolar.setBounds(10, 0, 180, 50);
        add(lDolar);
       
        tKursDolar = new  JTextField();
        tKursDolar.setBounds(180, 15, 60, 20);
        tKursDolar.setEditable(false);
        add(tKursDolar);
        
        lEuro = new JLabel("");
        lEuro.setText("Kurs euro:");
        lEuro.setForeground(Color.BLACK);
        lEuro.setBounds(10, 30, 75, 50);
        add(lEuro);
        
         
        tKursEuro = new  JTextField();;      
        tKursEuro.setBounds(75, 45, 60, 20);
        tKursEuro.setEditable(false);
        add(tKursEuro);
        
        lInfo = new JLabel("");
        lInfo.setText("Informacje pobrano ze strony nbp.pl");
        lInfo.setForeground(Color.BLACK);
        lInfo.setBounds(10, 70, 230, 20);
        add(lInfo); 
        
        try{
            Image image = ImageIO.read(new URL("https://www.nbp.pl/img/nbp-logo.png"));
            lObraz = new JLabel( new ImageIcon(image) );
        }catch(IOException e) {}
        lObraz.setBounds(5, 80, 290, 110);
        add(lObraz);
        
       
        setLayout(null);
        setSize(300,220);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Aktualne kursy walut");
        setVisible(true);
        
        
        Do zadanie = new Do();
        zadanie.execute();
        
   } 
    
  private class Do extends SwingWorker<Void, String> {
            @Override
            protected Void doInBackground() throws Exception {
                URL url;
                InputStream is = null;
                BufferedReader br;
                String wiersz;
                
                try {
                    url = new URL("http://www.nbp.pl/Kursy/KursyA.html");
                    is = url.openStream();  // IOException
                    br = new BufferedReader(new InputStreamReader(is)); 
                    int usd1 = 0, eur = 0, kurs = 0;
                    
                    while ((wiersz = br.readLine()) != null) {
                       
                        usd1 = wiersz.indexOf("EUR");
                        eur = wiersz.indexOf("USD");
                        
                        /*
                        jezeli szukany ciag zostanie znaleziony to do metody process
                        zostanie przeslana nastepna linia tekstu
                        */
                        
                        if(usd1 != -1 || eur != -1) 
                        {
                         kurs = 1;
                        }
                        else if (kurs == 1)
                        {
                            kurs = 0;
                            publish(wiersz.substring(38,44) );       
                        }
                    }
                } catch (MalformedURLException mue) {
                     mue.printStackTrace();
                } catch (IOException ioe) {
                     ioe.printStackTrace();
                } finally {
                    try {
                        if (is != null) is.close();
                    } catch (IOException ioe) {}
                }
                          return null;  
         }
        @Override
        protected void process(java.util.List<String> lista) {
            boolean check = true;
            for (String wiadomosc : lista) {
                // wyswietlenie przeslanych danych
                if(check)
                {
                     tKursDolar.setText(wiadomosc);
                     check = false;
                }
                else
                {
                    tKursEuro.setText(wiadomosc);
                } 
            }
        }
          
        }
       
            
        
        public static void main(String[] args) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
               public void run() {
                new Zad5();
            }
            });
        }
    
}