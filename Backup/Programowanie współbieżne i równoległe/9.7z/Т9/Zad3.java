
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.beans.*;
import java.util.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

/*
Program wylistowujący zawartosc podanego pliku txt
*/

class Zad3 extends JFrame implements ActionListener {
    
    private JLabel lSciezka, lStan, lWyswietlono;
    private JTextArea taPole;
    private JTextField tSciezka;
    private JButton bOtworz;
    public Zad3(){
        
        lSciezka = new JLabel("");
        lSciezka.setText("Ścieżka do pliku:");
        lSciezka.setForeground(Color.BLACK);
        lSciezka.setBounds(200, 0, 130, 80);
        add(lSciezka);
        setLayout(null);
        tSciezka = new  JTextField();
        tSciezka.setToolTipText("jeżeli plik nie wyświetla polskich znaków, sprawdź czy wykorzystuje kodowanie UTF-8");
        tSciezka.setBounds(310, 30, 200, 20);
        add(tSciezka);
                     
        bOtworz = new JButton("Otwórz");
        bOtworz.setBounds(520, 15, 100, 50);
        add(bOtworz);
        bOtworz.addActionListener(this);
        
        
        taPole = new JTextArea(20, 10);
        
        JScrollPane sp = new JScrollPane(taPole);
        sp.setBounds(0, 110, 890, 600);
        add(sp);
        
        lStan = new JLabel("");
        lStan.setText("Wyświetlono wierszy:");
        lStan.setForeground(Color.BLACK);
        lStan.setBounds(200, 80, 430,30);
        add(lStan);
        
        lWyswietlono = new JLabel("");
        lWyswietlono.setText("0");
        lWyswietlono.setForeground(Color.BLACK);
        lWyswietlono.setBounds(330, 80, 430,30);
        add(lWyswietlono);
        
        getContentPane().setBackground(Color.WHITE);
        setSize(910,750);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Otwieracz plików .txt");
        setVisible(true);   
    }

    @Override
   public void actionPerformed(ActionEvent e) {
        taPole.setText("");
        Dzialanie zadanie = new Dzialanie();
        zadanie.execute();
        bOtworz.setEnabled(false);
    }
       
       private class Dzialanie extends SwingWorker<Void, String> {
            @Override
            protected Void doInBackground() throws Exception {
                String plik = tSciezka.getText();
                FileReader fileReader = new FileReader(plik);
                BufferedReader bufferedReader = new BufferedReader(fileReader);
                int i = 0; 
                String wiersz = null;
                
                try {
                  wiersz = bufferedReader.readLine();
                  
                  do {
                    publish(wiersz);

                    wiersz = bufferedReader.readLine();
                    lWyswietlono.setText( (i + 1) + "");
                    i++;
                    Thread.sleep(100);
                  } while (wiersz != null);
                } catch (Exception e) { }
                finally {
                  bufferedReader.close();
                } 
                return null;
            }
            @Override
            protected void done() {
                bOtworz.setEnabled(true);
            }
            @Override
            protected void process(java.util.List<String> lista) {
                for (String wiadomosc : lista) {
                    taPole.append(wiadomosc + "\n");
                }
            }
          
        }
        
        public static void main(String[] args) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
               public void run() {
                new Zad3();
            }
            });
        }
    
}
