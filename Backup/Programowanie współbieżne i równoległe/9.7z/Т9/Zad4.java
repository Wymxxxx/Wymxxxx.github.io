
import java.awt.Color;
import java.awt.Font;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;


class Zad4 extends JFrame implements ActionListener {
    
    private JLabel lPlik,lKatalog, lStan, lIloscKatalog, lPrzeszukane;
    private JTextArea taPole;
    private JTextField tPlik, tKatalog;
    private JButton bSzukaj;
    public Zad4(){
        
        lPlik = new JLabel("");
        lPlik.setText("Słowo:");
        lPlik.setForeground(Color.BLACK);
        lPlik.setBounds(10, 0, 75, 50);
        add(lPlik);
        setLayout(null);
        tPlik = new  JTextField();
        tPlik.setToolTipText("Podaj jakie słowo ma występować w pliku");
        tPlik.setBounds(70, 15, 200, 20);
        add(tPlik);
        
        lKatalog = new JLabel("");
        lKatalog.setText("Szukaj w:");
        lKatalog.setForeground(Color.BLACK);
        lKatalog.setBounds(10, 30, 75, 50);
        add(lKatalog);
        setLayout(null);
        tKatalog = new  JTextField();
        tKatalog.setToolTipText("Podaj ścieżkę do katalogu");
        tKatalog.setBounds(70, 45, 200, 20);
        add(tKatalog);
        
        bSzukaj = new JButton("Szukaj");
        bSzukaj.setBounds(300, 15, 100, 50);
        add(bSzukaj);
        bSzukaj.addActionListener(this);
        
        
        taPole = new JTextArea(10, 40);
        
        JScrollPane sp = new JScrollPane(taPole);
        sp.setBounds(0, 110, 425, 280);
        add(sp);
        
        lStan = new JLabel("");
        lStan.setText("Aktualny stan wyszukiwania: ");
        lStan.setForeground(Color.BLACK);
        lStan.setBounds(70, 80, 430,30);
        add(lStan);
        
        lPrzeszukane = new JLabel("");
        lPrzeszukane.setText("0   /");
        lPrzeszukane.setForeground(Color.BLACK);
        lPrzeszukane.setBounds(235, 80, 430,30);
        add(lPrzeszukane);
        
        lIloscKatalog = new JLabel("");
        lIloscKatalog.setText("0");
        lIloscKatalog.setForeground(Color.BLACK);
        lIloscKatalog.setBounds(260, 80, 430,30);
        add(lIloscKatalog);
        
        
        
        getContentPane().setBackground(Color.WHITE);
        setSize(435,420);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Wyszukiwarka");
        setVisible(true);
        
            
        
        
         
    }

    @Override
   public void actionPerformed(ActionEvent e) {
        taPole.setText("");
        Wykonanie zadanie = new Wykonanie();
        zadanie.execute();
        bSzukaj.setEnabled(false);
    }
       
       private class Wykonanie extends SwingWorker<Void, String> {
            @Override
            protected Void doInBackground() throws Exception {
                String wiersz;
                String slowo = tPlik.getText();
                String katalog = tKatalog.getText();
                
                File fKatalog = new File(katalog);
                String[] zawartoscKatalogu = fKatalog.list();
                int index;
                if (zawartoscKatalogu == null) 
                {
                    publish("Podany katalog nie istnieje albo nie jest katalogiem");
                }
                for (int i = 0; i < zawartoscKatalogu.length; i++) 
                {
                    String filename = zawartoscKatalogu[i];
                    
                    lIloscKatalog.setText(zawartoscKatalogu.length + " ");
                    
                    try {
                        //otwarcie podanego pliku
			BufferedReader bf = new BufferedReader(new FileReader(katalog + "\\" + filename));
                        index = -1;
			// sparwadzenie czy w pliku występuje szukane słowo.
			while (   (wiersz = bf.readLine()) != null && index == -1   )
			{       
                            
                            index = wiersz.indexOf(slowo);
                            if (index!= -1) { // jeżeli > -1 to znaczy, że znaleziono slowo
                                    publish(filename);      
    				}
			}
                        // po zakończeniu przeszukiwania zamknięcie pliku
			bf.close();
                    }
                    catch (IOException e) { }
                    lPrzeszukane.setText( (i + 1) + "   / ");
                    Thread.sleep(1000);
                }
              return null;  
            }
            @Override
            protected void done() {
                bSzukaj.setEnabled(true);
            }
            @Override
            protected void process(java.util.List<String> lista) {
                for (String wiadomosc : lista) {
                    taPole.append(wiadomosc + "\n");
                }
            }
          
        }
        
        public static void main(String[] args) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
               public void run() {
                new Zad4();
            }
            });
        }
    
}

/* odczytanie zawartości pliku z podanej ścieżki wiersz po wierszu
FileReader fileReader = new FileReader(filePath);
  BufferedReader bufferedReader = new BufferedReader(fileReader);
  
  try {
    String textLine = bufferedReader.readLine();
    do {
      System.out.println(textLine);
  
      textLine = bufferedReader.readLine();
    } while (textLine != null);
  } finally {
    bufferedReader.close();
  }


try { // każde słowo, ale bez polskich znaków
			// Open the file c:\test.txt as a buffered reader
			BufferedReader bf = new BufferedReader(new FileReader("C:\\Users\\Patrycja01\\Desktop\\kolokwium.txt"));
			
			// Start a line count and declare a string to hold our current line.
			int linecount = 0;
    			String line;

			// Let the user know what we are searching for
			System.out.println("Searching for " + "kobiet" + " in file...");

			// Loop through each line, stashing the line into our line variable.
			while (( line = bf.readLine()) != null)
			{
    				// Increment the count and find the index of the word
    				linecount++;
    				int indexfound = line.indexOf("kobiet");

    				// If greater than -1, means we found the word
    				if (indexfound > -1) {
    				     System.out.println("Word was found at position " + indexfound + " on line " + linecount);
    				}
			}

			// Close the file after done searching
			bf.close();
		}
		catch (IOException e) {
			System.out.println("IO Error Occurred: " + e.toString());
		}

searching a directory for a file name
 File dir = new File("C:\\Users\\Patrycja01\\Desktop\\");
      FilenameFilter filter = new FilenameFilter() {
         public boolean accept
         (File dir, String name) {
            return name.startsWith("k");
        }
      };
      String[] children = dir.list(filter);
      if (children == null) {
         System.out.println("Either dir does not exist or is not a directory");
      } 
      else {
         for (int i=0; i < children.length; i++) {
            String filename = children[i];
            System.out.println(filename);
         }
      } 

*/