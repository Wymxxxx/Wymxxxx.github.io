
import java.util.concurrent.Semaphore;
/*
# każdy filozof najpierw bierze widelec po jego prawej stronie
#          F1
#       W4    W1
      F4        F2
#       W3    W2
#          F3
    F1 --> w5,w1   F3 --> w2,w3    F5 --> w4,w5
    F2 --> w1,w2   F4 --> w3,w4
#
*/
 class Filozof1 extends Thread {
     private String nazwa;
    //czas uspienia watku
    private static final int czas = 1000;

   private static Widelec[] widelce = {
                new Widelec("widelec 1"),
                new Widelec("widelec 2"),
                new Widelec("widelec 3"),
                new Widelec("widelec 4"),
                new Widelec("widelec 5"),
        };

    private int widelecPrawy, widelecLewy;

    
    public Filozof1(String name, int p, int l) {
        nazwa = name;
        widelecPrawy = p;
        widelecLewy = l;
    }

    public void run() {

        
        for(;;) {
           System.out.println(nazwa + " myśli... ");
            //poczekaj na pozwolenie do jedzenia
            if (pozwolenie()) {

                //kiedy twoja kolej podnosisz widelce po obu stronach i zaczynasz jesc
                System.out.println(nazwa + " zgłodniał... ");
                System.out.println(nazwa + " bierze " + widelce[widelecPrawy].pobierzNazwe() +
                                   " i " + widelce[widelecLewy].pobierzNazwe() +  " i zaczyna jeść..."); 
                czekaj(czas);

                //kiedy konczy jesc to odkłada widelce, inny filozof moze je podniesc
                System.out.println(nazwa + " zjadł");
                widelce[widelecPrawy].release();
                widelce[widelecLewy].release();
                czekaj(czas);
            }
            else
            System.out.println(nazwa + " ojoj nie dostałem się");
        }
    }
    /**
     * poczekaj na kolej do jedzenia
     * @return zwraca prawde jezeli masz uprawnienia do jedzenia
     */
    private boolean pozwolenie(){
        try {
            widelce[widelecPrawy].acquire();
            widelce[widelecLewy].acquire(); // wstrzymuje działanie i czeka na pozwlenie jak nie ma 1 
            
            if(widelce[widelecPrawy].availablePermits() == 0 && widelce[widelecLewy].availablePermits() == 0) 
                return true;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * uspienie biezacego watku na czas time
     */
    private void czekaj(int time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
 class Widelec extends Semaphore {
   
    private String nazwa;

    public Widelec(String n) {
        // dajemy jedno uprawnienie i kolejkujemy watki
        super(1, true);
        this.nazwa = n;
    }

    public String pobierzNazwe() {
        return nazwa;
    }
}
 class Zad4 {

    public static void main(String[] args) {
       
                new Filozof1("Filozof 1", 4, 0).start();
                new Filozof1("Filozof 2", 0, 1).start();
                new Filozof1("Filozof 3", 1, 2).start();
                new Filozof1("Filozof 4", 2, 3).start();
                new Filozof1("Filozof 5", 3, 4).start();
  
    }
}
