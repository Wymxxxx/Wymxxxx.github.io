

import java.util.concurrent.Semaphore;
 
 
class Zwierze extends Thread { 
    private static final Semaphore semafor = new Semaphore(1, true); 
    private String nazwa; 
    
    public Zwierze(String nazwa) { 
        this.nazwa = nazwa; 
    } 

    public void run() {
       
        while(true)
            {
        try{ 
            
                semafor.acquire(); 
                System.out.println(nazwa + " jest w ogrodzie");
                
            
         }catch (InterruptedException e) { System.out.println("Błąd"); 
         }finally { 
                System.out.println( nazwa + " opuścił ogród"); 
		semafor.release(); 
		} 
            }
    }
 
}
 
 

public class Zad1 {
 
    public static void main(String args[]) {
 
    new Zwierze("pies").start();
    new Zwierze("kot").start();
 
 
    }
 
 
}
