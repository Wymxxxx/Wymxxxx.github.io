

import java.util.concurrent.Semaphore;
import java.util.*;
class Samochod extends Thread{
   private String nazwa; 
   private parkingS parking;
   double czekaj; 
   public Samochod(String n, parkingS p){
       nazwa = n;  
       parking = p;
   }
   
   public void run() {
       
       try {
           System.out.println(nazwa + " próbuje wjechać na parking... ");
       if (parking.availablePermits() == 0)
       {   
           System.out.println("Brak miejsc " + nazwa + " czeka na wolne miejsce... ");
           czekaj = Math.random();
           if (czekaj < 0.75)
           {
               System.out.println(nazwa + " jedzie na innych parking... ");
               return;
           }  
       }
            parking.acquire();
            System.out.println(nazwa + " parkuje... ");
             sleep((long)(Math.random()*10000)); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally{
             System.out.println(nazwa + " opuszcza parking... ");
             parking.release(); 
       }
        
       
   }
   
}

class parkingS extends Semaphore{
    
    public parkingS() {
        
        super(20, true);
    }
}

class Demon extends Thread{
    private parkingS p;
    
    public Demon(parkingS p){
        setDaemon(true);
        this.p = p;
    }
    public void run() { 
        while (true) 
        { 
            System.out.println("Demoniczne wiadomości z ostatniej chwili"); 
            System.out.println("Wolnych miejsc na prakingu: " 
                    + p.availablePermits() + " Aktualna kolejka: " + p.getQueueLength());
            try { 
                sleep(5000); // 5 s 
            } catch (InterruptedException e) { 
            } 
        } 
    }  
}
public class Zad2 {
    
    public static void main(String[] args) 
    { 
        parkingS parking = new parkingS();
        new Demon(parking).start();
        for(int i = 1; i <= 100; i++) 
        {
          
            new Samochod("Samochód " + i, parking).start();
            try { 
                Thread.sleep((long)(Math.random()*10000)); 
            } catch(InterruptedException e) 
            { System.out.println("Błąd"); 
            } 
        } 
        
    }
}