
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.Semaphore;
 
class Wyswietlacz extends Thread {
 
    private String nazwa;
    private Semaphore semafor;
 
    public Wyswietlacz(String l, Semaphore s) {
        nazwa = l;
        semafor = s;
        Zad3.listaWatkow.add(this); // dodanie obiektu do listy
    }
    public void run() {
        while (true)
        {
            try {
                    semafor.acquire();
                    System.out.println(nazwa);

                    Wyswietlacz w = (Wyswietlacz) Zad3.listaWatkow.pobierzIterator().next(); // next zwraca kolejny element
                    
                    w.pobierzSemafor().release(); 
                    this.sleep((long) (Math.random()*400)); 
                    
            } catch (Exception e) {}
        
        }
    }
 
    public Semaphore pobierzSemafor() {
        return semafor;
    }
}                                                           
class Lista<T> extends ArrayList<T> implements Iterable<T>{ 
                                      
                                      
    Iterator iterator = iterator();
    
    public Iterator pobierzIterator() {
        return iterator;
    }
    @Override 
    public Iterator<T> iterator(){    // to wszystko trzeba nadpisać       
       
        Iterator<T> iteratorFIRST = new Iterator<T>() {
             
            public int i = 0;
            @Override
            public boolean hasNext() { 
                if (size()!= 0)
                {
                    return true;
                }
                else return false;
            }
            @Override
            public T next() {  
                if ( i + 1 > size() )
                {
                    i = 0;
                }
                return get(i++);            
            }
        };
        return iteratorFIRST; 
    }
}
 
public class Zad3 {
 
    static Lista<Wyswietlacz> listaWatkow = new Lista<>();
 
    public static void main(String[] args) {
        new Wyswietlacz("A", new Semaphore(1)).start();
        new Wyswietlacz("B", new Semaphore(0)).start();
        new Wyswietlacz("C", new Semaphore(0)).start();
    }
}