

class Watek6 extends Thread {
	
	private String tekst;
	private int liczbaTabulacji;
	private String napis = "";

	public Watek6(String tekst, int liczbaTabulacji){
		
            this.tekst = tekst;
	    this.liczbaTabulacji = liczbaTabulacji;
            
               for (int i=0; i<liczbaTabulacji; i++) {
			napis += "\t";
		}
		napis += tekst;
		
		
	}
	
	public void run() {
		for (int i=1; i<500; i++) {
			synchronized (System.out){
			
			for (int x=0; x < napis.length(); x++) System.out.print (napis.charAt(x));
			System.out.println(i);
			
		}
		
                }
	}
}


public class Zad1 {
	public static void main (String [] args) {
		
		new Watek6("Marek", 1).start();
		new Watek6("Kasia", 2).start();
		new Watek6("Andrzej", 3).start();
		new Watek6("Natalia", 4).start();

		
	}
}
