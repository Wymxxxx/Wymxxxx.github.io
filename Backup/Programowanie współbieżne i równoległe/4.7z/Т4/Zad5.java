
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;
 
class ZakladFryzjerski
{
    private int liczbaKrzesel;
    private List<Klient> listaKlientow;
 
    public ZakladFryzjerski()
    {
        liczbaKrzesel = 3;
        listaKlientow = new LinkedList<Klient>();
    }
 
    public void obetnijWlosy()
    {
        Klient klient;
         boolean czySpal;
        
        synchronized (listaKlientow)
        {
            czySpal = false;
            while(listaKlientow.size()== 0)
            {
                System.out.println("Brak klientów, fryzjer idzie spac."); //fryzjer czeka na klienta
                try
                {
                    listaKlientow.wait(); 
                }
                catch(InterruptedException e) {}
                czySpal = true;
            }
             if(czySpal)
                System.out.println("Klient budzi fryzjera");
             
            System.out.println("Fryzjer zaprasza klienta na fotel.");
            
            klient = (Klient)((LinkedList<?>)listaKlientow).poll(); 
        }                                                          
                                                 
        try                                                    
        {    
            System.out.println("Obcinanie włosów klientowi : "+ klient.pobierzImie());
            TimeUnit.SECONDS.sleep((long)(Math.random()*10));
        }
        catch(InterruptedException e) {}
        System.out.println("klient wychodzi : "+klient.pobierzImie() );
    }
 
    public void dodaj(Klient klient)
    {
        System.out.println("Klient : "+klient.pobierzImie()+ " wszedł do sklepu");
 
        synchronized (listaKlientow)
        {
            if(listaKlientow.size() == liczbaKrzesel)
            {
                System.out.println("Brak miejsca dla  "+klient.pobierzImie());
                System.out.println("Klient "+klient.pobierzImie()+" wychodzi...");
                return ;
            }
 
            ((LinkedList<Klient>)listaKlientow).offer(klient); 
            System.out.println("Klient : "+klient.pobierzImie()+ " siada na krzesle.");
             
           
               
                listaKlientow.notify();  
        }
    }
}

class Fryzjer implements Runnable
{
    private ZakladFryzjerski zfryzjerski;
 
    public Fryzjer(ZakladFryzjerski zfryzjerski)
    {
        this.zfryzjerski = zfryzjerski;
    }
    public void run()
    {
        try
        {
            Thread.sleep(10000); //10 s
        }
        catch(InterruptedException e){}
        System.out.println("Fryzjer zaczyna pracę ...");
        while(true)
        {
            zfryzjerski.obetnijWlosy();
        }
    }
}
class Klient implements Runnable
{
    private String imie;
    private ZakladFryzjerski zfryzjerski;
 
    public Klient(ZakladFryzjerski zfryzjerski)
    {
        this.zfryzjerski = zfryzjerski;
    }
 
    public String pobierzImie() {
        return imie;
    }
    public void ustawImie(String imie) {
        this.imie = imie;
    }
    public void run()
    {
        idzObciacWlosy();
    }
    private synchronized void idzObciacWlosy()
    {
        zfryzjerski.dodaj(this); // dodaje klientów do listy
    }
}
 
class WygenerujKlienta implements Runnable
{
    private ZakladFryzjerski zf;
 
    public WygenerujKlienta(ZakladFryzjerski zf)
    {
        this.zf = zf;
    }
 
    public void run()
    {
        while(true)
        {
            Klient klient = new Klient(zf);
            Thread thKlient = new Thread(klient);
            klient.ustawImie("Klient "+thKlient.getId());
            thKlient.start();
 
            try
            {
                TimeUnit.SECONDS.sleep((long)(Math.random()*10));
            }
            catch(InterruptedException e) {}
        }
    }
}
class Zad5 {
 
    public static void main(String a[])
    {
        ZakladFryzjerski zfryzjerski = new ZakladFryzjerski();
        Fryzjer f = new Fryzjer(zfryzjerski);
        WygenerujKlienta generuj = new WygenerujKlienta(zfryzjerski);
 
        Thread thfryzjer = new Thread(f);
        Thread thgeneruj = new Thread(generuj);
        thgeneruj.start();
        thfryzjer.start();
    }
}