

 class Schowek { 
private int wartosc; 
 
public synchronized int zmien() 
 { 
	wartosc += 10; 
	wartosc -= 10;
	return wartosc; 
 } 
 
public String toString() 
 { 
	return ("Aktualna wartość przechowywana w schowku: " + wartosc); 
 } 
 
}
class Zmiennik extends Thread {
 
	private Schowek s;
	public Zmiennik( Schowek s)
	{
		this.s = s;
 
	}
	public void run(){
 
		for (int i = 0; i < 1000; i++)
		{
		 s.zmien();
		}
 
	}	
 
}
 
public class Zad3 {
  public static void main(String args[]) 
  	{ 
  		Schowek s = new Schowek();
  			System.out.println("Wartość początkowa: " + s);
  		new Zmiennik(s).start();
  		new Zmiennik(s).start();
  		new Zmiennik(s).start();
  		new Zmiennik(s).start();
 
  		System.out.println("Wartość końcowa: " + s);
  	} 
 }
