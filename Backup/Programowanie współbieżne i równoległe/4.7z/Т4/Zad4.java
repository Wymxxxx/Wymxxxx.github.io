
import java.util.*;

 
class Towar { 
    private int kod;
    private double cena;
    public Towar() 
    { 
        kod = (int)(Math.random() * 100000); 
        cena = (Math.random() * 1000); 
    } 
    public String toString() 
    { 
        return "Kod towaru:" + kod + " Cena: " + cena; 
    } 
}
class Producent implements Runnable {
 
    private List<Towar> pojemnik;
    private int max=2; 
    Towar t;
    public Producent(List<Towar> p) {
        this.pojemnik = p;
    }
 
    
    public void run() {
        for (int i = 1; i <= 10; i++) {  
         try {
             produkuj();
         } catch (InterruptedException e) {    }
        }
}
 
    private void produkuj() throws InterruptedException {
    
       synchronized (pojemnik) {
           
           while (pojemnik.size() == max) {
             System.out.println("Pojemnik jest pełen, producent czeka na "
                     + "konsumcję produktów przez konsumenta");
             pojemnik.wait();
         }
          
        
            t = new Towar();
           System.out.println("Produkcja : " + t + "przez " + Thread.currentThread().getName());
           pojemnik.add(t);
         Thread.sleep((long)(Math.random() * 1000));
         pojemnik.notify();
        }
    }
}
 

class Konsument implements Runnable {
    private List<Towar> pojemnik;
    public Konsument(List<Towar> p) {
        this.pojemnik = p;
    }
   
    
    public void run() {
        while (true) {
         try {
             konsumuj();
             Thread.sleep(10000);
         } catch (InterruptedException e) {  e.printStackTrace();   }
        }
    }
 
    private void konsumuj() throws InterruptedException {
      
       synchronized (pojemnik) {
           
           while (pojemnik.size() == 0) {
                  System.out.println("Pojemnik pusty, konsument czeka na "
                               + "produkcję");
             pojemnik.wait();
         }
       
       
 
    
       
           Thread.sleep((long)(Math.random() * 2000));
         System.out.println("Skonsumowano : "+ pojemnik.remove(0) +" przez  "+ Thread.currentThread().getName());
         pojemnik.notify();
        }
    }
   
}
 

public class Zad4 {
 
    public static void main(String args[]) {
       List<Towar> pojemnik = new LinkedList<Towar>(); 
       Producent p =new Producent(pojemnik);
       Konsument c =new Konsument(pojemnik);
      
        Thread pTh = new Thread(p, "Producent 1");
        Thread pTh1 = new Thread(p, "Producent 2 ");
        Thread cTh = new Thread(c, "Konsument 1");
        Thread cTh1 = new Thread(c, "Konsument 2");
        Thread cTh2 = new Thread(c, "Konsument 3");
        
        pTh.start();
        pTh1.start();
        
        cTh.start();
        cTh1.start();
        cTh2.start();
    }
}
