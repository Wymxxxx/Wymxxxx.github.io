
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
 class Drawing extends JPanel{

    int FONTSIZE = 32, SCREENSIZE = 700;
    Location[] thArr = new Location[SCREENSIZE/FONTSIZE];
    Drawing(){
       for (int i = 0; i < thArr.length; i++) {
            thArr[i] = new Location(i*FONTSIZE);
        }
    }

    public void paint(Graphics g)
    {
        //super.paint(g); // wywołanie konstruktora JPanel
        Graphics2D g2 = (Graphics2D) g;
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, SCREENSIZE, SCREENSIZE);
       
        Font font = new Font("Monospaced", Font.BOLD, FONTSIZE); // (String name,int style,int size)
        g2.setFont(font);
        for (int i = 0; i < thArr.length; i++) {
            if(thArr[i].y > 700){
                thArr[i] = new Location(i*FONTSIZE);
            }
            drawThread(g2,thArr[i]);
        }

        try{Thread.sleep(30);}catch(Exception ex){}

        repaint();
    }
    public void drawThread(Graphics2D g2, Location th){
        int fontsize = g2.getFont().getSize();
        for (int i = 0; i < th.len; i++) {
            if(th.randInt(0, th.len) == i)
                th.chArr[i][0] = th.randChar();
            if(i == th.len-1)
                g2.setColor(Color.WHITE);
            else
                g2.setColor(Color.GREEN);
            g2.drawChars(th.chArr[i] ,0 ,1 ,th.x , th.y + (i*fontsize));
        }
        th.y+=th.vel;
    }

    public class Location{
        int vel, len, x, y, yBottom;
        char[][] chArr;

        Location(int x){

            this.x = x;
            len = randInt(5,30);
            chArr = new char[len][1];
            chArr = populateArrWithChars(chArr);
            vel = randInt(1,5);
            this.y = (-1)*len*FONTSIZE;
        }
        public char[][] populateArrWithChars(char[][] arr){
            for (int i = 0; i < arr.length; i++) {
                arr[i][0] = randChar();
            }
            return arr;
        }
        public char randChar(){
            final String alphabet = "0123456789QWERTYUIOPASDFGHJKLZXCVBNM";
            final int N = alphabet.length();
            Random r = new Random();
            return alphabet.charAt(r.nextInt(N));
        }
        public int randInt(int min, int max) {
            Random rand = new Random();
            int randomNum = rand.nextInt((max - min) + 1) + min;
            return randomNum;
        }
    }
}

public class Zad4 extends JPanel{
     public static void main(String[] args)
     {
         JFrame jf = new JFrame("Matrix raining code ");
         jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         jf.setSize(700,700);
         jf.setResizable(false);
         jf.add(new Drawing());
         jf.setVisible(true);
      }
}