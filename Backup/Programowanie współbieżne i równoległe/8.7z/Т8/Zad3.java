
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.*; 
import java.awt.event.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;
import java.util.Calendar;
import java.util.TimeZone;

class Zegar extends JFrame implements ActionListener{
    
    public JLabel jZegar;
    private JButton bStart, bStop;
    private boolean started = false;
    private Watek watek;
    public Zegar(){
        jZegar = new JLabel("");
        setLayout(null);
    
        jZegar.setFont(new Font("Comic Sans MS", Font.BOLD, 25 )); 
        jZegar.setForeground(Color.WHITE);
        jZegar.setBounds(200, 0, 160, 160);
        add(jZegar);
        //pack();
        watek = new Watek(this);
        
        bStart = new JButton ("Start");
        bStart.setBounds(150, 110, 100, 40);
        add(bStart);
        bStart.addActionListener(this);
        bStop = new JButton ("Stop");
        bStop.setBounds(250, 110, 100, 40);
        add(bStop);
        bStop.addActionListener(this);
        getContentPane().setBackground(Color.BLUE);
        setSize(500,200);
        setResizable(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Zegar");
        setVisible(true); 
        
       
   } 
     


    @Override
    public void actionPerformed(ActionEvent e) {
        Object zrodlo = e.getSource();
        if(zrodlo == bStart)
        {
            if (started == false)
            {
                watek.start();
                started = true;
            }
            else
            {
                watek.resume();
                
            }    
        }
        else if (zrodlo == bStop)
        {
                watek.suspend();     
        }
    }   
}


class Watek extends Thread{
    Zegar zegar;
    String czas;
    Date data;
    
    
 
    public Watek(Zegar z){
        zegar = z;
        
    }
    
    
    public void run(){
        
        while (true)
        {
            data = new Date();
            czas = "" + data.getHours();
            czas += ":" + data.getMinutes();
            czas += ":" + data.getSeconds();
            zegar.jZegar.setText(czas);
        }        
    }
}

public class Zad3 {
   public static void main(String[] args)
     {
         new Zegar(); 
         
         
         
         
         
     } 
}
