

class Watek extends Thread {
    
    private String nazwa;
    
    public Watek (String nazwa)
    {
        this.nazwa = nazwa;
    }
            
    public void run()
    {
        for (int i = 0; i < 5; i++)
        {
            System.out.println("Wątek " + nazwa);
            try { 
                sleep(1000); 
            } catch(InterruptedException e){}
        }
  
    }
    
} 

public class Zad1 {
    public static void main (String[] args) 
    {
    Watek[] tablicaWatkow = new Watek[10];
    
     
    
    
    
    for (int i = 0; i < 10; i++)
    {
        tablicaWatkow[i] = new Watek ("W" + (i +1));
        tablicaWatkow[i].start();
    }
     
    
    } 
}
