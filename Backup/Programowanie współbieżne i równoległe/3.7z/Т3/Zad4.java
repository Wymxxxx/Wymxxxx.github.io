


class Watek3 extends Thread{
    
    private String napis = "";
    private String tekst;
    private int liczbaTabulacji;
    
    public Watek3 (String tekst, int liczbaTabulacji)
    {
        
        this.tekst = tekst;
        this.liczbaTabulacji = liczbaTabulacji;
        
        for (int i=0; i<liczbaTabulacji; i++) {
			napis += "\t";
		}
        
        
        napis += tekst;
        
    }
            
    public void run()
    {
        for(int i = 1; i <= 500; i++)
        {
            
            for(int x=0; x < napis.length(); x++)  System.out.print (napis.charAt(x));
            
               
            System.out.println (i);
            try { 
                sleep((int)(Math.random()*1000)); 
            } catch(InterruptedException e){}
            
        }
        
  
    }
    
} 

public class Zad4 {
    public static void main (String[] args) 
    {
    
        new Watek3("Marek", 1).start();
	new Watek3("Kasia", 2).start();
	new Watek3("Andrzej", 3).start();
	new Watek3("Natalia", 4).start();
    
    } 
}
