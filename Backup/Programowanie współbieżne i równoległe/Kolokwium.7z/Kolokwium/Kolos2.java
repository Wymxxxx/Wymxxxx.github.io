
import java.util.concurrent.Semaphore;

class Pociag extends Thread{
    
 private String nazwa;
 private Stacja s;
 public Pociag(Stacja s, String n){
     this.s =s;
     nazwa = n;    
 }
 public void run() {
      try{
            System.out.println("Aktualny stan dworca:  pozwolenia: " + s.availablePermits()  + " Aktualna kolejka: " + s.getQueueLength());
            System.out.println(nazwa + " próbuje uzyskać pozwolenie na wjazd...");
            
            if (s.availablePermits() == 0 )
            {
                System.out.println("Brak wolnych torów, nie można wjechać");
            }
                s.acquire();
                System.out.println(nazwa + " wjeżdża na stację");
                
                System.out.println(nazwa + " Postój");
                sleep((long)(Math.random()*10000));  
     }catch (InterruptedException e) {
     }finally {
         System.out.println(nazwa + " odjazd...");
         s.release();
         
     }  
 }      
}
class Stacja extends Semaphore {
    
    public Stacja(){
        super(2,true);
        
    }  
}
public class Kolos2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       Stacja s = new Stacja();
    
        for (int i = 0; i < 20; i++)
        {
            new Pociag(s, "Pociąg P" + (i + 1) ).start();
            try { 
                Thread.sleep((long)(Math.random()*10000));  
            } catch(InterruptedException e) 
            { System.out.println("Błąd"); }
        }
        
        
        
    }
    
}
