

import java.util.concurrent.Semaphore;

class Smoker extends Thread {
    private String nazwa;
    public static Semaphore[] semaphore = {
        new Semaphore(0,true),
        new Semaphore(0,true),
        new Semaphore(0,true),
        
    };
    public static final Agent1 agent = new Agent1();
    int nr;
    public Smoker (String n, int nr){
        nazwa = n;
        this.nr = nr;
        
    }
    
    public void run (){
        while (true)
        {
            if (semaphore[nr].availablePermits() == 0)
                System.out.println("czekam");
            
            
            try{
                semaphore[nr].acquire();
                System.out.println("Mam " + nazwa + " pale.");
                sleep((long) (Math.random() * 3000));
                System.out.println("Skonczylem palic");
                
                
            }catch (InterruptedException e) {
            }finally {
                synchronized (agent){
                agent.notify();
            }
                
            }
            
            
            
        }
        
        
    }
    
           
    
}

class Agent1 extends Thread{
    
    public Agent1(){
        
        setDaemon(true);
    }
    
    public void run(){
        while (true)
        {
            double random = Math.random();
                int nrPalacza;
 
                if (random < 0.3) 
                {
                    nrPalacza = 0;
                } 
                else if (random > 0.3 && random < 0.6) 
                {
                    nrPalacza = 1;
                } 
                else 
                {
                    nrPalacza = 2;
                }
                System.out.println("powiadamiam palacza nr " + nrPalacza);
                Smoker.semaphore[nrPalacza].release();
                
                synchronized (this) {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        return;
                    }
                }
        } 
        
    }
    
}


public class ToDo {
     public static void main(String args[]) {
         
        new Smoker("tyton",0).start();
        new Smoker("papier",1).start();
        new Smoker("zapalki",2).start();
         
       Smoker.agent.start();
     }
    
}
