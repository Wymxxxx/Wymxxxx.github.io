
import java.util.concurrent.Semaphore;

class Turysta extends Thread {
    private String nazwa;
    private Ciuchcia c;
    private boolean miejsce;
    public Turysta(String n, Ciuchcia c){
        nazwa = n;
        this.c = c;
        
    }
    public void run(){
         try{
            System.out.println(nazwa + " zwiedza...");
            sleep((long)(Math.random()*10000));  
            
            System.out.println(nazwa + " chce sie przejechac ciuchcią...");
            System.out.println("Wolne miejsca: " + c.availablePermits() );
            c.acquire();
          
            if (c.availablePermits() != 0)
            {
                System.out.println(nazwa + " wsiadłem,  czekam na zapełnienie się ciuchci");
                System.out.println("Pozostało wolnych miejsc: " + c.availablePermits() );
            }
            else
            {
                System.out.println("CIUCHCIA PEŁNA, RUSZA ...");
                sleep((long)(Math.random()*10000));
            }
                
                
                
            

        }catch (InterruptedException e) {  System.out.println("BŁĄD     ");
        }finally {
             if (c.availablePermits() == 0)
             {
                System.out.println(".....CIUCHCIA WRACA NA STACJE ...");
                c.release(10); 
                
                   
             }
        
        }
            
        
    
    
    }
        
        
   
}


class Ciuchcia extends Semaphore {
    
    public Ciuchcia(){
        super(10,true);
        
    }
    
}




public class Kolos6 {
    public static void main(String[] args) {
        Ciuchcia c = new Ciuchcia();
        
        for(int i = 0; i < 100; i++)
        {
            new Turysta("Turysta " + ( i + 1), c).start();
            try { 
                Thread.sleep((long)(Math.random()*10000));  
            } catch(InterruptedException e) 
            { System.out.println("Błąd"); }
        }
        
        
        
    }
    
}
