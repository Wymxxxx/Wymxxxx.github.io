
import java.util.ArrayList;
class Kucharz extends Thread{
    private Kociol k;
    private String nazwa;
    
    public  Kucharz(Kociol k, String n)
    {
        this.k = k;
        nazwa = n;
    }
    public void run(){
        while (true) {
        try {
            k.dodaj();
            Thread.sleep((long)(Math.random() * 1000));
         } catch (InterruptedException e) {  e.printStackTrace();   }
      }
    }
            
}
class Kociol{
    public static final ArrayList<String> k = new ArrayList<>();
    private int max = 5;
    
    public void dodaj(){
        synchronized(k){
            try{ 
        if(k.size() == max)
        {
            System.out.println("Kociol pelny, zjedzcie to");
        
           
                k.wait(); //spi
            
          }
       
        while( k.size() != max )
        {
           
                   
                String stek = "stek";
                System.out.println("Produkcja : " + stek);
                k.add(stek);
                Thread.sleep((long)(Math.random() * 1000));
          
        }
        k.notify();
        }catch (InterruptedException e) {}
      }
        
    }
    
    void konsumuj() throws InterruptedException {
      
       synchronized (k) {
           
           while (k.size() == 0) {
                  System.out.println("pusto budzić kucharza!!!");
            k.wait();
         }

           Thread.sleep((long)(Math.random() * 2000));
         System.out.println("Skonsumowano : "+ k.remove(0) +" przez  "+ Thread.currentThread().getName());
         k.notify();
        }
    }
    
    
    
}


class Ludozerca extends Thread{
    private Kociol k;
    public  String nazwa;
    
    public Ludozerca(Kociol k, String n)
    {
        this.k = k;
        nazwa = n;
    }
    public void run(){
        //while (true) {
        try {
             k.konsumuj();
              Thread.sleep((long)(Math.random() * 2000));
         } catch (InterruptedException e) {  e.printStackTrace();   }
      //}
    }
     
}

public class Kolos8 {
    
    public static void main(String[] args) 
    { 
        Kociol k = new Kociol();
        new Kucharz(k, "kucharz ").start();
        for (int i = 1; i < 101; i++)
        {
                new Ludozerca(k, "ludozerca " + i).start();    
        }
        
    }
    
}
