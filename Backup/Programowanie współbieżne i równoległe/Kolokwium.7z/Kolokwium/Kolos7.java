
import java.util.concurrent.Semaphore;
import java.util.ArrayList;
class Ludz extends Thread{

 private Lazienka l = new Lazienka();
 String[] plec = {
             "Kobieta",
             "Mezczyzna"
         };
 private int nrPlci;
 public static final ArrayList<String> ludz = new ArrayList<>();
 private int nr;
 public Ludz (int n, int nr, Lazienka l){
     nrPlci = n;
     this.nr = nr;
     this.l = l;
     ludz.add(plec[nrPlci]);
 }
 String pokaz,pokaz1;
  public void run(){
        
         try{
             System.out.println(plec[nrPlci] +" " + nr + " wchodzi do lazienki...");
             l.acquire();
            
             if( l.availablePermits() == 0 &&  nrPlci == 1  && ludz.get(0) == "Kobieta" )
             {
                 System.out.println("nie można wejść, baba siedzi, wychodze");
		
             }
             else if (l.availablePermits() == 0 &&  nrPlci == 0  && ludz.get(0) == "Mezczyzna")
             {
                 System.out.println("nie można wejsc, chłop siedzi, wychodze");
		 
             }
             else if( nrPlci == 0 )
             {
                 System.out.println("Kobieta" +" " + nr +  " myje sie");
		 sleep((long)(Math.random()*10000));
             }
             else if ( nrPlci == 1 )
             {
                 System.out.println("Mezczyzna" +" " + nr +  " myje sie");
		 sleep((long)(Math.random()*10000));
             }
             else if ( l.availablePermits() == 0)
             {          
                 System.out.println(plec[nrPlci] + " " + nr + " brak miejsc");   
             }          
     }catch (InterruptedException e) {
     }finally {
             System.out.println(plec[nrPlci] + " " + nr + " Wychodzi...");
             ludz.remove(plec[nrPlci]);
              l.release();
         }
        
      
      
  }   
    
}
class DemonLazienkowy extends Thread{
    
    private Lazienka l;
    
    public DemonLazienkowy(Lazienka l){
        setDaemon(true);
        this.l = l;
    }
    public void run() { 
        while (true) 
        { 
            System.out.println("Demoniczne wiadomosci z  Lazienek"); 
            System.out.println("Wolnych miejsc: " 
                    + l.availablePermits() + "\n");
            try { 
                sleep(5000); // 5 s 
            } catch (InterruptedException e) { 
            } 
        } 
    }  
}


class Lazienka extends Semaphore {
    
    public Lazienka(){
        super(2,true);
        
    }  
}

public class Kolos7 {
     public static void main(String[] args) {
         Lazienka l = new Lazienka();
         
         int losujPlec;
         new DemonLazienkowy(l).start();
         for(int i = 0; i < 40; i++){
             
             losujPlec = (int) (Math.random()*2);
             new Ludz(losujPlec,(i + 1) ,l).start();
             try { 
                Thread.sleep((long)(Math.random()*10000));  
            } catch(InterruptedException e) 
            { System.out.println("Błąd"); }
         }
         
     }
    
}
