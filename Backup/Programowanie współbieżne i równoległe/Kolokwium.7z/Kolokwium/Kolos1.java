


class Obiekt {
    private int liczba;
    public void licz() {
        liczba = liczba + 10;
        System.out.println("Wykonuję obliczenia...");
        liczba = liczba - 10;
    }
    public String toString() {
        return "Wartość zmiennej liczba = " + liczba;
    }
}

class Watek implements Runnable{
    
    private Obiekt o;
    public Watek(Obiekt o){
        this.o = o;
    }
    public void run (){
      
        for (int i = 0; i < 10; i++)
        {
            
            synchronized (o){
                try{
                    System.out.println("Wywołanie z watku " + Thread.currentThread().getName() );
                    o.licz();
                    //o.wait();
                    Thread.sleep( (int)(Math.random() * 2000) );
                }catch (InterruptedException e) {}
               // o.notify();
            }
        }  
    }
}



public class Kolos1 {
    public static void main(String[] args) {
       
        Obiekt o = new Obiekt();
        
        Thread[] tab = new Thread[20];
        Watek[] w = new Watek[20];
       for (int i = 0; i < 20; i++)
       {
           
           w[i] = new Watek(o);
           
           tab[i] = new Thread( w[i], "W" + (i + 1) );
           
       }
        
       for (int i = 0; i < 20; i++)
       {
           
           tab[i].start();
           
           try{
               tab[i].join();
               //System.out.println(o);
           }catch (InterruptedException e) {}
           System.out.println(o + "\n");
       } 
        
    }
    
}
