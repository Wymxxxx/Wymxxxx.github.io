
import java.util.concurrent.ExecutorService; 
import java.util.concurrent.Executors;

 
 
class Klient implements Runnable{
 
private String nazwa;
 
public Klient (String nazwa){
this.nazwa = nazwa;
}
 private void czynnosci(String tekst)
 {
 try{
       	System.out.println("Klient" + nazwa + tekst);
 
 
 
       	 Thread.sleep( (long) (Math.random() * 1000));
       } catch (InterruptedException e)   {} ;
 
 }
public void run(){
 
       	czynnosci(" wchodzi");
       	czynnosci(" siada");
       	czynnosci(" wybiera z menu");
        czynnosci(" zamawia");
        czynnosci(" płaci");
        czynnosci(" wychodzi");

    } 
}
public class Zad2 {
 
     public static void main(String args[]) {
 
     	int lkrzeseł = 10;
		ExecutorService executor = Executors.newFixedThreadPool(3);
     	for (int i = 0; i < lkrzeseł; i++) 
     	 { 
     	 	Runnable watek = new Klient("K " + i); 
            executor.execute(watek);
     	 }
 
         executor.shutdown(); 
        while(!executor.isTerminated()) {} 
 
        System.out.println("Wszystkie wątki zakończyły pracę.");
 
 
     }
 
 
 
}