

import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService; 
import java.util.concurrent.Executors;
import java.util.concurrent.Callable;
 
 
class Sprawdz implements Runnable{
 
private String host;
 
public Sprawdz (String host){
this.host = host;
}
 
public void run(){
Socket socket = null;
    boolean reachable = false; 
    	try { 
    		socket = new Socket(host, 80);
    		 reachable = true; 
    		} catch (UnknownHostException e) { } 
    		  catch (IOException e) { }
    		  finally { 
    		    if (socket != null) 
    		    	try { 
    		    		socket.close(); 
    		    	    } catch(IOException e) {} 
                          }
 System.out.println( "host " + host + (reachable ? " jest osiągalny" : " nie jest osiągalny"));
}
 

}
 
 
public class Zad1 {
 
     public static void main(String args[]) {
 
     	String[] hosty = {"onet.pl", "gazeta.pl", "pudelek.pl", "facebook.com", "plotek.pl", "wp.pl", "deadoralive.pl"};
 
     	ExecutorService executor = Executors.newFixedThreadPool(3);
     	for (int i = 0; i < hosty.length; i++) 
     	 { 
     	 	Runnable watek = new Sprawdz(hosty[i]); 
            executor.execute(watek);
     	 }
 
         executor.shutdown(); 
        while(!executor.isTerminated()) {} 
 
        System.out.println("Wszystkie wątki zakończyły pracę.");
 
 
 
     }
 
 
 
}