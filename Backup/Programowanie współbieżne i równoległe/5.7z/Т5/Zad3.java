
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Callable;


class ZadanieJ implements Callable<Integer>{
    private int poczatek;
    private int koniec;
    private int[] tablica;
    
    public ZadanieJ(int[] tablica, int poczatek, int koniec){
        this.poczatek = poczatek;
        this.koniec = koniec;
        this.tablica = tablica;
    }
    public Integer call() throws Exception {
    int wynik = 0;
    for(int i = poczatek ; i < koniec; i++)
    {
        wynik += tablica[i];
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
        System.out.println("Błąd");
        }
    }
    System.out.println("Liczyłem sumę od zakresu: " + poczatek + " do zakresu: " +
    koniec + " Wynik: " + wynik);
    return wynik;
    }
}
class Stoper {

	private long start;
	private long stop;
	public void start(){
	start = System.currentTimeMillis();
	}
	public void stop(){
	stop = System.currentTimeMillis();
	}
	public double pobierzWynik(){
	return (stop - start) / 1000.0;
}
}




public class Zad3 {
    public static void main(String[] args) {
    
    int suma = 0;
    int[] tablicaLiczb = new int[1000];
    
    
    int[] tablicaWyników = new int[10];
    ZadanieJ[] zadania = new ZadanieJ[10];
    int podzial = tablicaLiczb.length / zadania.length;
    
    Future<Integer>[] future = new Future[10];
    Stoper stoper = new Stoper(); //stoper
    stoper.start();
    for (int i = 0; i < tablicaLiczb.length; i++) 
    {
        tablicaLiczb[i] = (int)(Math.random()*11);
    }
    ExecutorService executor = Executors.newFixedThreadPool(3);
    
     
    for (int i = 0; i < zadania.length; i++) 
    {
        zadania[i] = new ZadanieJ(tablicaLiczb, (i * podzial), ((i+1) * podzial));
         future[i] = executor.submit(zadania[i]);
        
    }
    
    
    for (int i = 0; i < zadania.length; i++) 
    {
        try {
            tablicaWyników[i] = 
            suma += future[i].get();
        } catch ( InterruptedException | ExecutionException ex) {
        System.out.println("Błąd");
        }
    }
    
    
    
    
    executor.shutdown();
    stoper.stop();
    while(!executor.isTerminated()) {}
    System.out.println("Wszystkie wątki zakończyły pracę.");
    System.out.println(suma);
    System.out.println("Czas: " + stoper.pobierzWynik());
    }
}








